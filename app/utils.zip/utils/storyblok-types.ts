export interface LinkAlternate {
  path: string;
  name?: string;
  lang: string;
}

export interface Link {
  //Numeric id of the referenced content entry
  id: number;
  //The full_slug of the content entry
  slug: string;
  //Given name of the content entry
  name: string;
  //Is this content entry a folder (true/false)
  is_folder: boolean;
  //Parent folder numeric id
  parent_id: number;
  //Is this story published (true/false)
  published: boolean;
  path?: string;
  //Numeric position value of the content entry
  position: number;
  //The uuid of the content entry
  uuid: string;
  //IS this story a startpage (true/false)
  is_startpage: boolean;
  real_path: string;
  alternates?: LinkAlternate[] | undefined;
}

export interface Story {
  name: string;
  created_at: string;
  published_at: string;
  alternates: any[];
  id: number;
  uuid: string;
  content: Content;
  slug: string;
  full_slug: string;
  default_full_slug?: string;
  sort_by_date: any;
  position: number;
  tag_list: any[];
  is_startpage: boolean;
  parent_id: number;
  meta_data: any;
  group_id: string;
  first_published_at: string;
  release_id?: string;
  lang: string;
  path?: string;
  translated_slugs: LinkAlternate[] | undefined;
}

export interface Content {
  _uid: string;
  component: string;
  _editable: string;
  [key: string]: any;
}

export interface Asset {
  id: number;
  alt?: string;
  name: string;
  focus?: string;
  title?: string;
  filename: string;
  copyright?: string;
  fieldtype: 'asset';
}

export interface MultiLink {
  id: string;
  url: string;
  linktype: 'url' | 'story';
  fieldtype: 'multilink';
  cached_url: string;
}

export type LinkTarget = '_self' | '_blank' | null;

export type LinkType = 'url' | 'story' | 'asset' | 'email';

export declare interface LinkAttributes {
  href: string;
  uuid: string | null;
  target: LinkTarget;
  linktype: LinkType;
}

export interface MultiLinkUrl extends MultiLink {
  linktype: 'url';
}

export interface MultiLinkStory extends MultiLink {
  linktype: 'story';
  story?: Story;
}

export interface NativeColorPicker {
  color: string;
  plugin: string;
  _uid: string;
}
