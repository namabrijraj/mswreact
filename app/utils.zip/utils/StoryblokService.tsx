import StoryblokClient, { RichtextInstance } from 'storyblok-js-client';
import BasePage from '@/utils/basePage';
import { GETSTORYURL, PUBLISHED, URL } from './constants';
import { slugType } from './Utils';
import { setBuildEnvironment } from './global';

type StoryblokClientGetParams = {
  version?: 'draft';
  cv?: number;
  resolve_links?: string;
  resolve_relations?: string;
  language?: string;
  dimension?: string;
  datasource?: string;
  per_page?: number;
  page?: number;
  cvFlag?: boolean;
  starts_with?: string;
};

type rootPathType = {
  [key: string]: string;
};

class StoryblokService {
  token: string;
  client: StoryblokClient;
  richTextResolver: RichtextInstance;

  constructor() {
    this.token = 'ReogF2qhza763NLudJzwFgtt'; //vMre72M9caUmmlr3yprpsgtt"; //'ReogF2qhza763NLudJzwFgtt';
    this.client = new StoryblokClient({
      accessToken: this.token,
      cache: {
        clear: 'auto',
        type: 'memory',
      },
    });
    this.richTextResolver = this.client.richTextResolver;
  }

  getStoryblokClient() {
    return this.client;
  }

  getCacheVersion() {
    return this.client.cacheVersion;
  }

  get(slug: string, params: StoryblokClientGetParams) {
    params = params || {};

    if (typeof window !== 'undefined' && typeof window.StoryblokCacheVersion !== 'undefined') {
      params.cv = window.StoryblokCacheVersion;
    }

    return this.client.get(slug, params);
  }

  getDraft(slug: string, params: StoryblokClientGetParams) {
    params = params || {};
    params.version = 'draft';
    return this.get(slug, params);
  }

  getUrl(slug: string) {
    const rootPaths: rootPathType = {
      en: 'residential/',
      de: 'privatkunden/',
      fr: 'clients-prives/',
      it: 'clienti-privati/',
    };
    let rootPath = rootPaths.en;
    Object.keys(rootPaths).forEach((element: string) => {
      if (element === window.document.documentElement.getAttribute('lang')) {
        rootPath = rootPaths[element];
      }
    });
    const finalURL: string =
      URL + window.build + '/' +
      rootPath +
      slug +
      '?language=' +
      window.document.documentElement.getAttribute('lang') +
      '&version=' +
      PUBLISHED +
      '&token=' +
      this.token;
    return finalURL;
  }

  initEditor(reactComponent: BasePage) {
    if (window.storyblok) {
      window.storyblok.init({ accessToken: this.token });
      window.storyblok.on(['change', 'published'], () => location.reload());
      window.storyblok.on('input', (event) => {
        if (event && event.story.content._uid === reactComponent.state.pageContent._uid) {
          reactComponent.setState({ pageContent: event.story.content });
        }
      });
    }
  }

  bridge() {
    return <script src='//app.storyblok.com/f/storyblok-latest.js' key='storyblok-bridge'></script>;
  }

  async getPageContent(params: slugType) {
    setBuildEnvironment();
    const data = await storyblokInstance.get(
      GETSTORYURL + window.build + '/' + params.slugName,
      {
        language: params.lang,
      }
    );
    return data;

  }
}

const storyblokInstance = new StoryblokService();

export default storyblokInstance;

export interface BlokProps {
  content: {
    _uid: string;
    component: string;
  };
  metadata?: any;
  key?: string;
  pageConfig?: any;
  property?: any;
}
