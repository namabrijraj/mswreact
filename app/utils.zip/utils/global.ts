/* Declare global variables in this file */

import { MYSDEV, MYSPREPROD, MYSPROD, MYSTEST } from './constants';
import { LinkAlternate } from './storyblok-types';

declare global {
  interface Window {
    ReactAppI18n: { [key: string]: string };
    ReactApp: { [key: string]: any };
    digitalData: any;
    dataLayer: [];
    altSlug: LinkAlternate[] | undefined;
    build: string | undefined;
  }
}

export { };

export const getStaticAssetPath = (path: string): string => {
  return '/mysunrise' + path;
};

export const getUrlParam = (param: string): string => {
  const urlParams: URLSearchParams = new URLSearchParams(window.location.search);
  return urlParams.get(param) || '';
};
export const setBuildEnvironment = () => {
  if (typeof window !== 'undefined') {
    window.build = MYSTEST;
    if (window.ReactApp.Env.build === 'mys') {
      window.build = MYSPROD;
    } else if (window.ReactApp.Env.build === 'mys-test') {
      window.build = MYSTEST;
    } else if (window.ReactApp.Env.build === 'mys-dev') {
      window.build = MYSDEV;
    } else if (window.ReactApp.Env.build === 'mys-pre-prod') {
      window.build = MYSPREPROD;
    }
  }
};

export const analyticsPathHierarchy = (url: string): any => {
  if (url) {
    url = url.replace(/\//g, ':');
    const urlArray: any[] = url.split(':');
    if (url.endsWith(':')) {
      urlArray.pop();
    }
    return urlArray.join(':');
  }
  return '';
}
