export const SBLINKS = 'cdn/links';
export const MYSUNRISEPAGESPATH = {
  en: '/residential/',
  de: '/privatkunden/',
  fr: '/clients-prives/',
  it: '/clienti-privati/',
};
