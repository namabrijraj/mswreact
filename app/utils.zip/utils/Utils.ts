import { useRouter } from 'next/router';
import { getUrlParam, setBuildEnvironment } from './global';
import { LinkAlternate } from './storyblok-types';

export const getParameterByName = (
  name: string,
  url = window.location.href.toLowerCase()
): string | null => {
  if (name) {
    name = name.toLowerCase();
    const modName = name.replace(/[[\]]/g, '\\$&');
    const regex = new RegExp('[?&]' + modName + '(=([^&#]*)|&|#|$)'),
      results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
  }
  return '';
};

export interface slugType {
  slugName: string;
  lang: string;
}

export const getSlugname = (): slugType => {
  const slug: string | string[] = useRouter().query.slug;
  const lang: string = useRouter().query.language;
  let slugName = '';

  if (typeof slug !== 'string' && slug.length > 0) {
    slugName = slug.join('/');
  } else if (typeof slug === 'string') {
    slugName = slug;
  }

  return { slugName, lang };
};

export const getRedirectUrl = (
  hashParam: string,
  locale: string,
  altSlugPaths: LinkAlternate[] | undefined
): string => {
  let selectedLocalePath: string | undefined = '';
  if (altSlugPaths) {
    selectedLocalePath = altSlugPaths.find((item) => item.lang === locale)?.path;
  }
  // eslint-disable-next-line no-console
  console.info(hashParam);
  if (selectedLocalePath) {
    const path = selectedLocalePath.replace('mysunrise/', '/mysunrise/' + locale + '/') + '.html';
    if (hashParam) {
      return path.replace('/.html', '') + hashParam;
    }
    return path.replace('/.html', '');
  }
  return '';
};

export const getRedirectLocaleUrl = (
  locale: string,
  altSlugPaths: LinkAlternate[] | undefined
): string => {
  setBuildEnvironment();
  let selectedLocalePath: string | undefined = '';
  if (altSlugPaths) {
    selectedLocalePath = altSlugPaths.find((item) => item.lang === locale)?.path;
  }
  // eslint-disable-next-line no-console

  if (selectedLocalePath) {
    const path =
      selectedLocalePath.replace('mysunrise/' + window.build + '/', '/mysunrise/' + locale + '/') +
      '.html';
    return path.replace('/.html', '') + window.sessionStorage.getItem('extra_params');
  }
  return '';
};

export const getExternalAppLocaleUrl = (params: string[]): string => {
  const out = [];
  for (let i = 0; i < params.length; i++) {
    if(!params[i])
        continue;
    const pairs = getUrlParam(params[i]);
    pairs && out.push(params[i]+ '=' +pairs);
  }
  return out.join('&').substring(out.join('&').indexOf('=')+1);
};

export const addSessionData = (): boolean => {
  setBuildEnvironment();
  const altSlugPaths = window.altSlug;
  altSlugPaths &&
    altSlugPaths.map((alt) => {
      alt.path = alt.path.replace('/' + window.build, '');
    });
  window.sessionStorage.setItem('redirect_paths', JSON.stringify(altSlugPaths));
  window.sessionStorage.setItem('hash_params', window.location.search + window.location.hash);
  return true;
};

export const addExtraQueryPath = (): boolean => {
  if (typeof window !== 'undefined') {
    window.sessionStorage.setItem('extra_params', window.location.search);
    return true;
  }
  return false;
};
