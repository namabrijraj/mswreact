import NextHead from 'next/head';
import StoryblokService from '@/utils/StoryblokService';
import Components from '@/components/index';
import React from 'react';
import { Content } from './storyblok-types';

export type BaseContext = {
  params: {
    language: string;
    slug?: string[];
  };
  preview: boolean;
};

class BasePage extends React.Component<BasePageProps, { pageContent: Content, lang: string, activePath: string }> {
  constructor(props: BasePageProps) {
    super(props);
    this.state = {
      pageContent: props.page.data.story.content,
      lang: props.language,
      activePath: props.activePath
    };
  }


  componentDidMount(): void {
    enableStoryblokEditor(this.props.isDevMode, this);
  }
  componentDidUpdate(prevProps: BasePageProps): void {
    if (
      prevProps.activePath !== this.props.activePath ||
      prevProps.language !== this.props.language
    ) {
      this.setState({
        pageContent: this.props.page.data?.story?.content,
        lang: this.props.language,
        activePath: this.props.activePath,
      });
    }
  }

  render(): JSX.Element {
    return (
      <div>
        {enableStoryblokBridge(this.props.isDevMode)}

        {Components({
          content: this.state.pageContent,
          metadata: {
            lang: this.state.lang,
            title: this.props.page.data.story.name,
            activePath: this.state.activePath
          },
        })}
      </div>
    );
  }
}

export default BasePage;

const enableStoryblokEditor = (isDevMode: boolean, page: BasePage) => {
  if (isDevMode) {
    //console.log('Enable Storyblok Editor');
    StoryblokService.initEditor(page);
  }
};

const enableStoryblokBridge = (isDevMode: boolean) => {
  if (isDevMode) {
    //console.log('Enable Storyblok Bridge');
    return <NextHead>{StoryblokService.bridge()}</NextHead>;
  }
  return;
};

export const generateStoryLocalizedBaseUrl = (language: string): string => {
  if (language === 'default') {
    return 'cdn/stories';
  }
  return `cdn/stories/${language}`;
};

export const getLanguageFromContext = (context: BaseContext): string => {
  return context.params.language;
};

export type PageProps = {
  props: {
    page: any;
    language: string;
    isDevMode: boolean;
    activePath: string;
  };
};

export type BasePageProps = {
  page: any;
  language: string;
  isDevMode: boolean;
  activePath: string;
};

export const getDefaultStaticProps = async (
  storyblokCDNStoryPath: string,
  context: BaseContext,
  language: string
): Promise<PageProps> => {
  const isContextPreviewEnabled = context.preview || false;
  const isDevMode =
    process.env.IS_DEVELOPMENT_MODE_ENABLED === 'true' ||
    isContextPreviewEnabled;
  let page = {};
  if (isDevMode) {
    page = await StoryblokService.getDraft(storyblokCDNStoryPath, {
      resolve_links: 'story',
      resolve_relations: 'referenceComponent.reference',
      language: language,
    });
  } else {
    page = await StoryblokService.get(storyblokCDNStoryPath, {
      resolve_links: 'story',
      resolve_relations: 'referenceComponent.reference',
      language: language,
    });
  }
  return {
    props: {
      page,
      language: language,
      isDevMode,
      activePath: storyblokCDNStoryPath,
    },
  };
};

export type PagePaths = {
  paths: {
    params: {
      language: string;
      slug?: string[];
    };
    locale?: string;
  }[];
  fallback: boolean;
};

export const getLanguages = (): string[] => {
  return ['default', 'en', 'de', 'fr', 'it'];
};

export const getDefaultStaticPaths = async (): Promise<PagePaths> => {

  return {
    paths: getLanguages().map((l) => ({
      params: {
        language: l
      },
    })),
    fallback: false,
  };
};
