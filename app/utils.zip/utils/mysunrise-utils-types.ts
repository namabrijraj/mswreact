import { GenericSBProps } from '@/components/index';
import { StaticSectionProps } from '@/components/general/StaticWrapper';
import { Asset, MultiLink } from './storyblok-types';

export interface StoryStaticType {
  staticSection: StaticSectionProps[];
  loadComponent?: boolean;
}

export interface BigPromoTabProps extends GenericSBProps {
  enableTeaser: boolean;
  title: string;
  subtitle: string;
  image: Asset;
  description: string;
  ctaText: string;
  ctaPath: MultiLink;
  target: string;
  promoFlagText: string;
  promoFlagValue: string
}

export interface TeaserItemProps {
  productType: string;
  title: string;
  subtitle: string;
  text: string;
  callToAction: string;
  linkPath: string;
  target: string;
  imageAlt: string;
  image: string;
}
export interface BenefitTeaserInterface {
  enableBenefitTeaser?: boolean;
  benefitTeaserImage?: Asset;
}