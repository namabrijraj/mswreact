export type LocaleID = 'en' | 'de' | 'fr' | 'it' | 'default';
