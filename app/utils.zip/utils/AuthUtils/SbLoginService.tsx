import { createContext, useContext } from 'react';
import { useEffect, useState } from 'react';
import AuthAccountQuery from 'src/graphql/AuthAccountQuery';
import GraphQL from 'src/graphql/GraphQL';
import DataLanguageService from 'src/utils/DataLanguageService';

interface AuthSchema {
  status: string;
  isLoginPage: boolean;
}

interface AuthProviderSchema {
  children: JSX.Element;
}

const AuthContext = createContext<AuthSchema | undefined>(undefined);

const AuthProvider = ({ children }: AuthProviderSchema): JSX.Element => {
  const [authData, setAuthData] = useState<AuthSchema>({
    status: 'Validating',
    isLoginPage: false,
  });

  useEffect(() => {
    const fetchAccountLogin = () => {
      GraphQL.authorize(
        {
          query: AuthAccountQuery,
          variables: {
            language: DataLanguageService.getLanguageCode().toUpperCase(),
            forceUpdate: true,
          },
        },
        (response: boolean) => {
          if (response) {
            const currentDate = new Date();
            const futureDate = new Date(currentDate.getTime() + 30 * 60000);
            setAuthData((prevState) => ({
              ...prevState,
              status: 'Authenticated',
            }));
            window.sessionStorage.setItem('auth-stamp', futureDate.toISOString());
          } else {
            window.sessionStorage.setItem('redirectUri', window.location.pathname);
            setAuthData((prevState) => ({
              ...prevState,
              status: 'UnAuthenticated',
            }));
          }
        },
        () => {
          //console.info('Error in Auth', error);
          window.sessionStorage.setItem('redirectUri', window.location.pathname);
          setAuthData((prevState) => ({
            ...prevState,
            status: 'UnAuthenticated',
          }));
        }
      );
    };
    const fetchLoginState = async () => {
      const loginIndex = window.location.href.split('/');
      if (!window.location.href.includes('/login') || (loginIndex[loginIndex.length - 1] !== 'login')) {
        const sessionAuthData = window.sessionStorage.getItem('auth-stamp'); //null
        let isUnAuthourised = true;
        if (sessionAuthData) {
          const currentDate = new Date().valueOf();
          const loggedDateTime = new Date(sessionAuthData).valueOf();
          isUnAuthourised = (loggedDateTime - currentDate) / 60000 < 0;
        }
        setAuthData((prevState) => ({ ...prevState, isLoginPage: false }));
        if (isUnAuthourised || /(?:invoice-assistant)/.test(window.location.href) || /(?:mysunrise-external-login)/.test(window.location.href)) {
          fetchAccountLogin();
        } else {
          setAuthData((prevState) => ({
            ...prevState,
            status: 'Authenticated',
          }));
        }
      } else {
        setAuthData((prevState) => ({ ...prevState, isLoginPage: true }));
      }
    };
    fetchLoginState();
  }, []);
  return <AuthContext.Provider value={authData}>{children}</AuthContext.Provider>;
};
export default AuthProvider;

export const useAuthData = (): AuthSchema | undefined => useContext(AuthContext);
