import * as React from 'react';
interface BackButtonProps {
    action: any;
    className?: string;
}
interface BackButtonState {
    hide: boolean;
}
export default class BackButton extends React.Component<BackButtonProps, BackButtonState> {
    constructor(props: BackButtonProps) {
        super(props);
        this.state = {
            hide: false
        }
    }

    componentWillMount(): void {
        if (window && window["ReactNativeWebView"] && window["ReactNativeWebView"].postMessage) {
            setTimeout(() => {
                window["ReactNativeWebView"].postMessage(JSON.stringify({ action: "BackButtonLoad", value: 1 }));
                window.addEventListener("message",(e:any)=>{
                    if(e.data && JSON.parse(e.data).action==="hideBackButton"){
                     this.setState({hide:true})
                    }
                });
                document.addEventListener("message",(e:any)=>{
                    if(e.data && JSON.parse(e.data).action==="hideBackButton"){
                     this.setState({hide:true})
                    }
                });
            }, 0)
        }
    }

    render(): React.ReactNode {
        if(this.state.hide){return <></>}
        return (<a className={this.props.className ? this.props.className : 's20-section-title__link-back'} onClick={this.props.action}>
            {this.props.children}
        </a>)
    }
}
