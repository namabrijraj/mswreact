import React, { RefObject, useEffect, useRef } from 'react';

const useOnClickOutside = <T extends HTMLElement, t>(
  setWrapperState: React.Dispatch<React.SetStateAction<t>>,
  resetValue: t,
  shouldListen = true
): RefObject<T> => {
  // returns a 'RefObject' which can be added to html tags

  /*
  'useOnClickOutside' hook takes three arguments 
    - 'setWrapperState' : a function that updates state
    - 'shouldListen' : a flag based on which click events would be listened to
    - 'resetValue' : the value to set using 'setWrapperState' when click outside 'RefObject' element is detected 
  */

  const wrapperRef: RefObject<T> = useRef<T>(null);

  useEffect(() => {
    const clickHandler = (event: MouseEvent): void => {
      if (wrapperRef.current && !wrapperRef.current.contains(<Node>event.target)) {
        setWrapperState(resetValue);
      }
    };
    // listen to 'mousedown' events based on 'shouldListen' flag change
    if (shouldListen) {
      document.addEventListener('mousedown', clickHandler);
    } else {
      document.removeEventListener('mousedown', clickHandler);
    }
    return () => {
      document.removeEventListener('mousedown', clickHandler);
    };
  }, [shouldListen, setWrapperState, resetValue]);

  return wrapperRef;
};

export default useOnClickOutside;
