import React from 'react';
import SbEditable from "storyblok-react";
import { MultiLink } from "@/utils/storyblok-types";
import { ComponentWithContentProps, GenericSBProps } from "@/components/index";
import DataLayerService from 'src/utils/DataLayer/DataLayerService';
import { DataLayerConstants } from 'src/utils/DataLayer/DataLayerConstants';
import { DataLayerGtmConstants } from 'src/utils/DataLayer/DataLayerGtmConstants';

interface HelpAndSupportSubNavLinks {
  path: MultiLink;
  text: string;
}
interface HelpAndSupportLinks {
  helpAndSupportSubNavTitle: string;
  helpAndSupportSubNavLinks: HelpAndSupportSubNavLinks[]
}

export interface HelpAndSupportProps extends GenericSBProps {
  helpAndSupportTitle: string;
  helpAndSupportLinks: HelpAndSupportLinks[];
}

const HelpAndSupport = (props: ComponentWithContentProps<HelpAndSupportProps>): JSX.Element => {
  const handleOnClick = (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>, title: string, link?: string): void => {
    DataLayerService.addEventData([
      {
        eventName: DataLayerConstants.event.FOOTER_NAVIGATION, eventType: DataLayerConstants.event.CLICK,
        eventValue: event && event.currentTarget && title + ' | ' + event.currentTarget.innerText,
        gtmInfo: { event_name: DataLayerGtmConstants.event.footer.FOOTER_NAVIGATION_CLICK, link_url: link, click_text: event.currentTarget.innerText }
      }
    ], true);
  }
  return (
    <SbEditable content={props.content}>
      <div className="s20-footer__main">
        <div className="s20-footer__inner">
          <h4 className="s20-footer__heading">{props.content.helpAndSupportTitle}</h4>
          <div className="s20-footer__container">
            {props.content.helpAndSupportLinks && props.content.helpAndSupportLinks.map((supportLinks: HelpAndSupportLinks) => (
              <div className="s20-footer__column js-collapsible"
                data-collapsible-options="{&quot;deviceMin&quot;:&quot;mobile-smallest&quot;,&quot;deviceMax&quot;:&quot;tablet-portrait&quot;}">
                <h5 className="s20-footer__title js-collapsible--toggle">{supportLinks.helpAndSupportSubNavTitle}
                  <div className="s20-footer__arrow">
                    <i className="s20-icon s20-footer__arrow-icon s20-icon--chevron-up-white"></i>
                  </div>
                </h5>
                <ul className="s20-footer__list js-collapsible--container">
                  {supportLinks.helpAndSupportSubNavLinks &&
                    supportLinks.helpAndSupportSubNavLinks.map((subNavLinks: HelpAndSupportSubNavLinks) => (
                      <li className="s20-footer__item">
                        <a className="s20-footer__link" href={subNavLinks.path.cached_url}
                          onClick={(event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => handleOnClick(event, supportLinks.helpAndSupportSubNavTitle, subNavLinks.path.cached_url)}>
                          {subNavLinks.text}
                        </a>
                      </li>
                    ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </SbEditable>
  )
}

export default HelpAndSupport
