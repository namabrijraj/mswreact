import React from "react";
import SbEditable from "storyblok-react";
import { FooterLink } from "../SbFooter";
import {
  NavigationLocale,
} from "./LocaleSelector/LocaleSelector";
import styles from "./CopyrightSection.module.scss";
import { DataLayerGtmConstants } from "src/utils/DataLayer/DataLayerGtmConstants";
import DataLayerService from "src/utils/DataLayer/DataLayerService";
import { DataLayerConstants } from "src/utils/DataLayer/DataLayerConstants";

export interface CopyrightInterface {
  copyrightText: string;
  impressumList: FooterLink[];
  localeSelector: NavigationLocale[];
  isMinimalFooter: boolean
}

const CopyRightSection = ({
  copyrightText,
  impressumList,
  isMinimalFooter
}: CopyrightInterface): JSX.Element => {
  const handleOnClick = (title?: string, link?: string): void => {
    DataLayerService.addEventData([
      {
        eventName: DataLayerConstants.event.FOOTER_NAVIGATION, eventType: DataLayerConstants.event.CLICK,
        gtmInfo: { event_name: DataLayerGtmConstants.event.footer.FOOTER_NAVIGATION_CLICK, link_url: link, click_text: title }
      }
    ], true);
  }
  return (
    <div className={`${styles['container']}`}>
    <div
      className={`s20-footer__bottom ${isMinimalFooter? `${styles['reduceFooterPadding']}` : ''
      }`}
    >
      <div className="s20-footer__inner">
        <div className={`s20-footer__copyright`}>
          © {new Date().getUTCFullYear()} {copyrightText}
        </div>

        <ul
          className={`s20-footer__bottom-list`}
        >
          {impressumList.map((impressum) => {
            return (
              <React.Fragment key={impressum._uid}>
                <SbEditable content={impressum}>
                  <li className={`s20-footer__bottom-item`}>
                    <a
                      href={impressum.url.cached_url || "#"}
                      className={`s20-footer__bottom-link`}
                      title={impressum.title}
                      onClick={() => handleOnClick(impressum.title, impressum.url.cached_url)}
                    >
                      {impressum.title}
                    </a>
                  </li>
                </SbEditable>
              </React.Fragment>
            );
          })}
         </ul>
      </div>
    </div>
    </div>
  );
};
export default CopyRightSection;
