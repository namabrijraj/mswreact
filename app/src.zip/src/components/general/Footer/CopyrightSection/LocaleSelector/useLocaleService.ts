import { DEFAULTLOCALE } from '@/utils/constants';
import { LinkAlternate } from '@/utils/storyblok-types';
import { getRedirectLocaleUrl } from '@/utils/Utils';
import { useRouter } from 'next/router';

const useLocaleService = (): {
  activeLocaleString: string;
  getLocalePath: (localeId: string) => string;
  checkActiveId: (localeId: string) => string;
} => {
  /*
  custom hook that returns
    - 'activeLocaleString': the localeID of the current page
    - 'getLocalePath(localeId)': a function that frames and returns the url path for the selected 'localeId'
    - 'checkActiveId(localeId)': a function that checks if selected 'localeId' is same as activeLocale
  */
  let activePagePath: string = '';
  const activelocaleId = useRouter().query.language;
  if (typeof window !== 'undefined') {
    activePagePath = window.location.href;
  }

  const getActiveLocale = (): string => {
    let locale = activelocaleId || DEFAULTLOCALE;
    if (typeof locale === 'string') {
      if (locale === 'default') {
        locale = DEFAULTLOCALE;
      }
      locale = locale.toUpperCase();
    } else {
      return locale[0];
    }
    return locale;
  };
  const activeLocaleString = getActiveLocale();
  const getLocalePath = (localeId: string): string => {
    let path = '';
    let altSlugPaths: LinkAlternate[] | undefined;
    if (typeof window !== 'undefined') {
      altSlugPaths = window.altSlug;
    }

    if (altSlugPaths) {
      path = getRedirectLocaleUrl(localeId, altSlugPaths);
    }

    if (path && path !== '') {
      return window.location.hash?path+window.location.hash:path;
    }
    let sLocalePath = activePagePath.replace(`/${activelocaleId}/`, `/${localeId}/`);
    if (activePagePath === sLocalePath && activelocaleId === 'default') {
      sLocalePath = '/' + localeId + activePagePath;
    }
    return sLocalePath;
  };
  const checkActiveId = (id: string): string => {
    if (id.toUpperCase() === activeLocaleString) {
      return 'active';
    }
    return '';
  };
  return { activeLocaleString, getLocalePath, checkActiveId };
};

export default useLocaleService;
