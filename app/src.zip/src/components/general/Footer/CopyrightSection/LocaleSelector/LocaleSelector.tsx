import { GenericSBProps } from "@/components/index";
import { LocaleID } from "@/utils/data-source";
import { useRouter } from "next/router";
import { useState } from "react";
import useOnClickOutside from "../../useOnClickOutside";
import useLocaleService from "./useLocaleService";

export interface NavigationLocale extends GenericSBProps {
  localeId: LocaleID;
  title: string;
}
interface LocaleSelectorSchema {
  localeSelector: NavigationLocale[];
}

const LocaleSelector = ({
  localeSelector
}: LocaleSelectorSchema): JSX.Element => {
  const [isPopUpShown, setPopUpShown] = useState(false);
  const { activeLocaleString, checkActiveId, getLocalePath } =
    useLocaleService();
  const popUpRef = useOnClickOutside<HTMLDivElement, boolean>(
    setPopUpShown,
    false,
    isPopUpShown
  );
  const getLang = useRouter().asPath;
  const pageLan = getLang.split('/');
  const lanProp = pageLan[1].toUpperCase();
  return (
    <div ref={popUpRef} className="js-flyout flyout flyout-language flyout-language--transparent flyout-language--light">
      <button
        className="flyout--trigger js-flyout--trigger"
        onClick={() => {
          setPopUpShown(!isPopUpShown);
        }}
      >
        {activeLocaleString}
        <i
          className="s20-icon s20-icon--chevron-up-bold flyout--icon"
        ></i>
      </button>
      {localeSelector.length > 0 && (
        <div className="js-flyout--container flyout--container">
          <ul className="s20-menu">
            {localeSelector.map((locale) => (
              <li className={`s20-menu__list js-track-language-change ${checkActiveId(locale.localeId)}`} key={locale._uid}>
                {locale.title !== lanProp &&
                  <a className="s20-menu__item " href={getLocalePath(locale.localeId)} onClick={() => setPopUpShown(false)} title={locale.title} >
                    {locale.title}
                  </a>
                }
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default LocaleSelector;
