import SbEditable from "storyblok-react";
import CopyRightSection from "@/components/general/Footer/CopyrightSection/CopyrightSection";
import { ComponentWithContentProps, GenericSBProps } from "@/components/index";
import { MultiLink } from "@/utils/storyblok-types";
import { NavigationLocale } from "@/components/general/Footer/CopyrightSection/LocaleSelector/LocaleSelector";
import HelpAndSupport, { HelpAndSupportProps } from "./HelpAndSupport/HelpAndSupport";

export interface FooterLink extends GenericSBProps {
  title: string;
  url: MultiLink;
  isTelephone: boolean;
}

export interface FooterSchema extends GenericSBProps {
  copyrightText: string;
  impressumList: FooterLink[];
  localeSelector: NavigationLocale[];
  helpAndSupport: HelpAndSupportProps[];
}

const SbFooter = ({
  content,
}: ComponentWithContentProps<FooterSchema>): JSX.Element => {
  return (
    <SbEditable content={content}>
      <div className='full-top-margin'></div>
      <footer
        className={`s20-footer s20-footer--mys s20-footer--dark`}
        id="footer"
      >
        <div id='subfooter'>
          {content.helpAndSupport &&
            content.helpAndSupport.map((helpAndSupportContent: HelpAndSupportProps) =>
              <HelpAndSupport key={helpAndSupportContent._uid} content={helpAndSupportContent} />
            )}
          <CopyRightSection
            copyrightText={content.copyrightText}
            impressumList={content.impressumList}
            localeSelector={content.localeSelector}
            isMinimalFooter={(content.helpAndSupport.length > 0) ? false : true}
          />
        </div>
      </footer>
    </SbEditable>
  );
};
export default SbFooter;
