import Components, {
  ComponentWithContentProps,
  GenericSBProps,
} from "@/components/index";
import { Story } from "@/utils/storyblok-types";
import SbEditable from "storyblok-react";

type referenceComponent = "referenceComponent";

interface ReferenceProps extends GenericSBProps {
  component: referenceComponent;
  reference: Story;
}

const ReferenceComponent = (
  props: ComponentWithContentProps<ReferenceProps>
): JSX.Element => (
  <SbEditable content={props.content}>
    {Components({
      content: props.content.reference.content,
      metadata: {},
      key: "",
    })}
  </SbEditable>
);

export default ReferenceComponent;
