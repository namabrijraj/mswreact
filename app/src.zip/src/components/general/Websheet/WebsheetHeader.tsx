import React, { useEffect, useState } from 'react';
import SbEditable from 'storyblok-react';
import { useRouter } from "next/router";
import storyblokInstance from "@/utils/StoryblokService";
import { NavigationLocale } from "../Footer/CopyrightSection/LocaleSelector/LocaleSelector";
import useLocaleService from '../Footer/CopyrightSection/LocaleSelector/useLocaleService';
import { getSlugname } from '@/utils/Utils';
import { GenericSBProps } from '@/components/index';
import { getStaticAssetPath, setBuildEnvironment } from '@/utils/global';
import { version } from "package.json";
interface WebsheetHeaderProps extends GenericSBProps {
  image: string,
  localeSelector: NavigationLocale[];
}

interface LocalArrayListType {
  title: string,
  localeId: string
}

const WebsheetHeader = ({ content }: WebsheetHeaderProps): JSX.Element => {
  const { getLocalePath } = useLocaleService();
  const [headerImg, setHeaderImg] = useState<string>();
  const [headerImg2x, setHeaderImg2z] = useState<string>()
  const [mylocaleSelector, setMyLocaleSelector] = useState<LocalArrayListType[]>();
  const params = getSlugname();
  const loaclArr: LocalArrayListType[] = []
  const getLang = useRouter().asPath;
  const pageLan = getLang.split('/');
  const lanProp = pageLan[1].toUpperCase();
  let localArrayList: LocalArrayListType;
  const [buildEnvCheck, setBuildEnvCheck] = useState<string | undefined>('');

  useEffect(() => {
    (async () => {
      const response = await storyblokInstance.getPageContent(params);
      response.data.story.content.header.map((item: any) => {
        setHeaderImg(item.image.filename)
        setHeaderImg2z(item.image_2x.filename)
        {
          item && item.localeSelector.map((ele: NavigationLocale) => {
            localArrayList = {
              title: ele.title,
              localeId: ele.localeId
            }
            loaclArr.push(localArrayList)
          })
        }
        setMyLocaleSelector(loaclArr);
      })
    })();
    setBuildEnvironment();
    if (typeof window !== undefined) {
      setBuildEnvCheck(window.build);
    }
  }, [])

  return (
    <>
      <SbEditable content={content}>
        <div className="header-sticky header-sticky--rigi js-header-sticky-wrapper" style={{ height: '52px' }}>
          <header className='header header--slim js-header-sticky'>
            <div className="s20-header__top" role="navigation">
              {buildEnvCheck && buildEnvCheck !== 'prod' &&
                <div className="s20-header__version-number">
                  <p>MSW - {version}</p>
                </div>
              }
            </div>
            <div className="l-center-max l-center-max-marginless">
              <div className="header__inner">
                <div className="header__left">
                  <div data-sly-unwrap>
                    <a className="header__logo" href="#" title="Sunrise">
                      {headerImg &&
                        <img
                          alt="Logo Sunrise"
                          className="header__logo-img"
                          src={headerImg}
                          srcSet= {`${headerImg} 1x, ${headerImg2x} 2x`} />
                          }
                    </a>
                  </div>
                </div>
                <div className="header__right">
                  {mylocaleSelector && <div>
                    <div className="language-select">
                      <input className="language-select__input" id="langInput" type="checkbox" />
                      <label className="language-select__label" htmlFor="langInput">
                        {lanProp}
                        <img className='language-select__arrow' src={getStaticAssetPath('/down-arrow.png')} />
                      </label>
                      <div className="language-select__overlay">
                        <label className="language-select__closing-label" htmlFor="langInput"></label>
                      </div>
                      <ul className="language-select__list">
                        {mylocaleSelector.map((locale: LocalArrayListType) => (
                          <>
                            {locale.title !== lanProp && <li className="language-select__item">
                              <a x-cq-linkchecker="valid" href={getLocalePath(locale.localeId)} data-languageselector="languageSelector">{locale.title}</a>
                            </li>}
                          </>
                        ))}
                      </ul>
                    </div>
                  </div>}
                </div>
              </div>
            </div >
          </header >
        </div >

      </SbEditable >
    </>
  )
}

export default WebsheetHeader
