import React from 'react';
import '@/assets/lib/genericIframe';
import I18n from 'src/utils/helper/I18n';
import { IframeRenderedDataProps } from '../containers/InvoiceAssistant/InvoiceAssistant';

interface GenericIframeProps extends IframeRenderedDataProps {}

const GenericIframe = (props: GenericIframeProps): JSX.Element => {
  return (
    <>
        {props &&
          <>
          <div className={`${!props.iframeProps.isHeightEnabled ? 'l-iframe no-margins' : ''}`}>
            <iframe
              className={`${
                props.iframeProps.isHeightEnabled ? '' : 'js-iframe-content-height js-iframe-bill-assistant'
              }`}
              height={`${props.iframeProps.isHeightEnabled ? props.iframeProps.height : ''}`}
              width={`${props.iframeProps.isHeightEnabled ? '100%' : ''}`}
              src={`${props.iframeProps.iFrameSrc}`} scrolling="no"
            ></iframe>
          </div>
          {!props.iframeProps.isHeightEnabled ? (
            <div
              className='s20-rotate-notification js-rotate-notification s20-rotate-notification--mys-bottom-navigation s20-rotate-notification--has-ivr-button s20-rotate-notification'
              style={{ marginBottom: '0px' }}
            >
              <div className='s20-rotate-notification__text'>
                <I18n code={'rotatebutton.text'} />
              </div>
            </div>
          ) : null}
        </>
        }
    </>
  );
};
export default GenericIframe;
