import React from 'react';
import SbEditable from 'storyblok-react';
import { Asset, MultiLink } from '@/utils/storyblok-types';
import DynamicComponent, { GenericSBProps } from '@/components/index';
import { Richtext } from 'storyblok-js-client';

export interface CarouselContentProps extends GenericSBProps {
  description: Richtext,
  endTime: string,
  expiredLabel: string,
  image: Asset,
  linkPath: MultiLink,
  linkText: string,
  target: string,
  timeLeftLabel: string,
  title: string
}

interface CarouselContainerProps extends GenericSBProps {
  productPromoTeaser: CarouselContentProps[];
}

const CarouselContainer = (props: CarouselContainerProps): JSX.Element => {

  return (
    <>
      <SbEditable content={props.content}>
        <div className="l-center-l l-center-l--extra-wide">
          <div className="l-grid">
            <div className="js-carousel-aem s20-carousel" data-settings-focus-at="center" data-settings-gap="8" data-settings-per-view="3" data-settings-start-at="0">
              <div className="s20-carousel__track" data-glide-el="track">
                <ul className="l-grid s20-carousel__slides">
                  {props.content.productPromoTeaser && props.content.productPromoTeaser.map((item: CarouselContentProps) => (
                    <DynamicComponent content={item} />
                  ))
                  }
                </ul>
              </div>
              <div className="s20-carousel__nav" data-glide-el="controls[nav]">
                {props.content.productPromoTeaser && props.content.productPromoTeaser.map((item: CarouselContentProps, index: number) => (
                  <button className="s20-carousel__nav-item" data-item={item.title} data-glide-dir={'=' + index}>
                    {index}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
        <div className="vertical_spacer x48"></div>
      </SbEditable>
    </>
  )
}

export default CarouselContainer;
