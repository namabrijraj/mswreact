interface Placeholder {
  placeHolderName: string;
}

const Placeholder = ({placeHolderName}:Placeholder): JSX.Element => {
  return (
    <div style={{
        background: '#d3d3d3',
        border: '1px dashed c-red',
        color: `${'#' + ((1<<24)*Math.random() | 0).toString(16)}`,
        fontWeight: 'bold',
        textAlign: 'center',
        padding: '12px'
      }}>
      The component {placeHolderName.toUpperCase()} has not been developed/deployed yet.
    </div>
  )
};

export default Placeholder;
