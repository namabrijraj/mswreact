import { BlokProps } from "@/utils/StoryblokService";
import DynamicComponent from "../index";

export interface StaticSectionProps {
  _uid: string;
  component: string;
  components: BlokProps;
}

const BuybackPopupComponent = ({ content }: any): JSX.Element => {
  return (
    <>
      {content.components &&
        content.components.map((item: any) => (
          <>
            <DynamicComponent content={item} />
          </>
        ))}
    </>
  );
};

export default BuybackPopupComponent;
