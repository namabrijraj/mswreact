import { Richtext } from 'storyblok-js-client';
import storyblokInstance from '@/utils/StoryblokService';
interface RichTextProp {
  content: Richtext;
}

const RichText: React.FunctionComponent<RichTextProp> = (props: RichTextProp): JSX.Element => {
  return (
    <div dangerouslySetInnerHTML={{ __html: storyblokInstance.richTextResolver.render(props.content) }}
    />
  );
};

export default RichText;