import SbEditable from "storyblok-react";
import { GenericSBProps } from "@/components/index";
import StaticWrapperComponent from "./StaticWrapper";
import { StoryStaticType } from "@/utils/mysunrise-utils-types";

interface WrapperContentProps extends GenericSBProps, StoryStaticType {}
const WrapperContainer = (props: WrapperContentProps): JSX.Element => {
	return (
		<>
			<SbEditable content={props.content} >
				<div className="l-center-m">
					<div className="s20-spacer s20-spacer--x60"> </div>
					<div className="content_box content-box content_box--w-83">
						<div className="s20-spacer s20-spacer--x60 is-hidden-mobile"></div>
						{props.content.staticSection &&
							props.content.staticSection.map((item: any) => (
								<>
									<StaticWrapperComponent content={item} />
								</>
							))}
						<div className="s20-spacer s20-spacer--x60 is-hidden-mobile"></div>
					</div>
					<div className="s20-spacer s20-spacer--x60"></div>
				</div>
			</SbEditable>
		</>
	);
};

export default WrapperContainer;
