import { GenericSBProps } from '@/components/index';
import SbEditable from 'storyblok-react';
import { NavigationLinkSchema } from '../MainNavigation';
import { RootStateOrAny, useSelector } from 'react-redux';
import { useEffect } from 'react';
import DataLayerService from 'src/utils/DataLayer/DataLayerService';
import { DataLayerConstants } from 'src/utils/DataLayer/DataLayerConstants';
import { DataLayerGtmConstants } from 'src/utils/DataLayer/DataLayerGtmConstants';
declare let window: any;
var ebill: any;
export interface SubNavigationColumnSchema extends GenericSBProps {
  title: string;
  id:string;
  disableLink: boolean;
  subNavigationItem: NavigationLinkSchema[];
}
interface SubNavigationSchema {
  content: SubNavigationColumnSchema[];
  // mainTitle: string;
}
const SubNavigation = ({ content}: SubNavigationSchema): JSX.Element => {
  useEffect(() => {
    ebill= window.sessionStorage.getItem("customertype") || '';
  });
  const account: any = useSelector((state: RootStateOrAny) => state ? state?.billsReducer.account : null);
  const data: any = useSelector((state: RootStateOrAny) => state ? state?.billsReducer.paymentRequests
  : null);
  function handleOnClick(event: React.MouseEvent<HTMLAnchorElement, MouseEvent>, item : NavigationLinkSchema): void {
    DataLayerService.addEventData([
      { eventName: DataLayerConstants.event.HEADER_MENU, eventType: DataLayerConstants.event.CLICK, eventValue: event && event.currentTarget && event.currentTarget.innerText, gtmInfo: { event_name: DataLayerGtmConstants.event.navigations.SUBNAVIGATION_CLICK, link_url: item && item.url?.cached_url, click_text: item && item.title } }
    ], true);
  }
  return (
    <>
      {content.map((subNavColumn) => (
        <SbEditable key={subNavColumn._uid} content={subNavColumn}>
          {subNavColumn.subNavigationItem.map((item) => (
            (account && account.billInfo && account.billInfo.billSettings && account.billInfo.billSettings.paymentMethod && account.billInfo.billSettings.paymentMethod === 'EBILL' && item.id === 'e_bill' && (account && account.billInfo && account.billInfo.billInfoAmount && account.billInfo.billInfoAmount.totalOutstandingAmount === 0)) || (ebill && item.id === 'e_bill' && account && account.billInfo && account.billInfo.billInfoAmount && account.billInfo.billInfoAmount.totalOutstandingAmount === 0) ? null : (account && account.billInfo && account.billInfo.billInfoAmount && account.billInfo.billInfoAmount.totalOutstandingAmount === 0 && item.id === 'pay_bill') || (data && data.length && item.id === 'pay_bill') ? null :
             <SbEditable key={subNavColumn._uid} content={subNavColumn}>
                <li className="s20-header__list-item">
                  <a className="s20-header__link s20-header__link--promo-gift" href={item && item.url.cached_url} onClick={(event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => handleOnClick(event, item )}>
                    {item.title}
                  </a>
                </li>
              </SbEditable>
          )
          )}
        </SbEditable>
        ))}
    </>
  );
};
export default SubNavigation;