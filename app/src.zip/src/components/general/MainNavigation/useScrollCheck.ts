import { useEffect, useState } from 'react';
const isElementInViewport = (_pElement: any): boolean => {
  let _window: any = window;
  let _document: any = document;
  if (_window && _document) {
    let _rect: any = _pElement.getBoundingClientRect();
    return (
      _rect.top >= 0 && _rect.left >= 0 && _rect.right <= window.innerWidth && _rect.top <= window.innerHeight
    );
  }
  return false;
}
const hasScroll = (): boolean => {
  let _window: any = window;
  let _document: any = document;
  let el = document.getElementById('body')
  if (_window && _document && el) {
    return (Math.floor(el.getBoundingClientRect().bottom) <= window.innerHeight);
  }
  return false;
}
const useScrollCheck = (): { isScrollBreak: boolean, isScrollBreakFooter: boolean, hasPageScroll: boolean } => {
  const [isScrollBreak, setIsScrollBreak] = useState(false);
  const [isScrollBreakFooter, setIsScrollBreakFooter] = useState(false);
  const [footerNav, setfooterNav] = useState<any>();
  const [hasPageScroll, setHasPageScroll] = useState(false);
  const [wrappedElement, setWrappedElement] = useState<any>();
  const handleScroll = () => {
    const position = window.pageYOffset;
    setIsScrollBreak(position >= 30);
    setIsScrollBreakFooter(isElementInViewport(footerNav));
    setHasPageScroll(hasScroll());
  };
  useEffect(() => {
    setWrappedElement(document.getElementById('body'));
    setfooterNav(document.getElementById('footer'));
    setHasPageScroll(hasScroll());
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [footerNav, wrappedElement]);
  return { isScrollBreak, isScrollBreakFooter, hasPageScroll };
};

export default useScrollCheck;