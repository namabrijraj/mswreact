import * as React from 'react';
import styles from './MswMainNavigation.module.scss';
import I18n from 'src/utils/helper/I18n';
import { ComponentWithContentProps, GenericSBProps } from '@/components/index';
import useNavService from '@/components/general/MainNavigation/useNavService';
import { useEffect, useState } from 'react';
import NavStoreProvider from '@/components/general/MainNavigation/NavContext';
import { Asset, MultiLink } from '@/utils/storyblok-types';
import SbEditable from 'storyblok-react';
import useOnClickOutside from '@/components/general/Footer/useOnClickOutside';
import storyblokInstance from '@/utils/StoryblokService';
import InfoBanner from '@/components/containers/PageProperties/InfoBanner';
import MswNewHeader from './MswNewHeader/MswNewHeader';
import Cookies from 'js-cookie';
import { HeaderConstants } from '@/src-containers/Header/HeaderConstants';
import DataLayerGtmService from 'src/utils/DataLayer/DataLayerGtmService';
import { DataLayerGtmConstants } from 'src/utils/DataLayer/DataLayerGtmConstants';
import SbTutorial from '@/components/containers/PageProperties/SbTutorial';

export interface HeaderSchema extends GenericSBProps {
  navigationItems: any;
}

export interface MswMainNavBarSchema extends GenericSBProps {
  Config: any;
  navigationItems: any[];
  header: HeaderSchema[];
  sideNavigationArrow: Asset;
  impressumList: any[];
  copyRightText: string;
  tutorial: any;
}

export interface NavigationLinkSchema extends GenericSBProps {
  id: string;
  title: string;
  url: MultiLink;
  icon: string;
}

const MswMainNavigation = ({
  content
}: ComponentWithContentProps<MswMainNavBarSchema>): JSX.Element => {
  const { activeNavLinkId, navCtx } = useNavService(content.navigationItems);
  const [shouldMount, setShouldMount] = useState(false);
  const [hour, setHour] = useState(0);
  const [langauges, setLanguages] = useState<any>([]);
  const [enableInfoBanner, setEnableInfoBanner] = useState<boolean>(false);
  const [innerWidth, setInnerWidth] = useState(typeof window !== 'undefined' ? window.innerWidth : 0);
  const ref = useOnClickOutside<HTMLDivElement, string>(
    navCtx.reset,
    '',
    navCtx.navStore.activeDeskId !== ''
  );
  const loadAnimation = typeof document !== 'undefined' && document.querySelector('#overview-page #load-page');
  const identifyPage = typeof document !== 'undefined' && document.querySelector('#overview-page');
  let previousURL = typeof window !== 'undefined' && window.location.href;

  const getHour = () => {
    const date = new Date();
    var hour = date.getHours();
    setHour(hour);
  }

  const checkForURLChanges = () => {
    const currentURL = typeof window !== undefined && window.location.href;
    if (currentURL !== previousURL) {
      setShouldMount((prevState) => !prevState)
    }
    previousURL = currentURL;
  };

  if (hour >= 5 && hour < 12)
    var greeting = I18n.translate('Dashboards.Overview.Label.GoodMorning');
  else if (hour >= 12 && hour < 17) {
    var greeting = I18n.translate('Dashboards.Overview.Label.GoodAfternoon');
  } else {
    var greeting = I18n.translate('Dashboards.Overview.Label.GoodEvening');
  }

  let userData: any = {};
  const userCookieValue: string = Cookies.get(HeaderConstants.SUNRISE_AUTH) || '',
    userDetails: { firstName: string, lastName: string, siteId: string } = userCookieValue && JSON.parse(decodeURIComponent(userCookieValue)) || {};
  if (userCookieValue && userDetails && Object.keys(userDetails).length) {
    userData = userDetails || {};
  }

  useEffect(() => {
    checkForURLChanges();
    getHour();
    setEnableInfoBanner(content.Config[0].enableInfoBanner);
    storyblokInstance.client.get('cdn/datasource_entries', {
      'datasource': 'locale-id'
    })
      .then(response => {
        setLanguages(
          response.data.datasource_entries
        )
      })

    const handleResize = () => {
      if (typeof window !== undefined)
        setInnerWidth(window.innerWidth)
    }

    if (typeof window !== undefined) {
      window.addEventListener('popstate', checkForURLChanges);
      window.addEventListener('resize', handleResize);
      return () => {
        window.removeEventListener('popstate', checkForURLChanges);
        window.removeEventListener('resize', handleResize);
      }
    };
  }, []);

  useEffect(() => {
    typeof window !== 'undefined' && window.sessionStorage.setItem('newPanelDesign', 'true');
    if (typeof document !== 'undefined' && navigator && navigator.userAgent && navigator.userAgent.indexOf('MySunriseApp') === -1) {
      if (innerWidth <= 1023) {
        document.querySelector('#overview-page')?.setAttribute('style', 'padding-left: 0px; max-width: auto')
      } else {
        document.querySelector('#overview-page')?.setAttribute('style', 'padding-left: 400px; max-width: calc(100% - 50px)');
        if (loadAnimation) {
          const loadPageStyle = (loadAnimation as HTMLElement).style;
          loadPageStyle.position = 'relative';
          loadPageStyle.top = '15rem';
        }
      }
    }
  }, [shouldMount, innerWidth, loadAnimation, identifyPage]);

  function dataLayerCheck(url: string, title: string, isFooter: boolean): void {
    DataLayerGtmService.addGtmDataLayer('', { event: DataLayerGtmConstants.event.GA_EVENT, event_name: isFooter ? DataLayerGtmConstants.event.footer.FOOTER_NAVIGATION_CLICK : DataLayerGtmConstants.event.navigations.MAINNAVIGATION_CLICK, link_url: url, click_text: title });
  }

  if (typeof window !== 'undefined' && !window.location.href.includes('login') && navigator && navigator.userAgent && navigator.userAgent.indexOf('MySunriseApp') === -1) {
    return (
      <SbEditable content={content}>
        <NavStoreProvider value={navCtx}>
          <React.Fragment>
            <div className='s20-header-sticky js-stickybox'>
              <header
                ref={ref}
                className={`s20-header js-header-s20 s20-header--mys s20-header--single-sublists`}
                style={{ transform: 'unset' }}
              >
                <div className='s20-header__main'>
                  {enableInfoBanner && <InfoBanner pageConfig={content.Config[0]} />}
                  <MswNewHeader
                    content={content}
                    langauges={langauges}
                    navCtx={navCtx}
                  />
                </div>
              </header>
            </div>
            <div className='is-hidden-mobile'>
              <div className={`${styles['side-bar']}`} id='sidebar'>
                <>
                  <div className={`${styles['heading_title']}`}>
                    {userData.firstName && userData.lastName ? `${userData.firstName.charAt(0)}${userData.lastName.charAt(0)}` : ''}
                  </div>
                  <div className={`${styles['heading-teaser__title']} hidden`}>
                    <div className={`${styles['heading-teaser__title-name']}`} data-max-characters='32'>
                      {greeting}
                      {', '}
                      {userData.firstName}
                    </div>
                    <div className={`${styles['heading-teaser__text']}`}>
                      {I18n.translate('Dashboards.RatePlan.Label.CustomerNumber')}: &nbsp;
                      <span className={`${styles['heading-teaser__link']}`}>{userData.siteId}</span>
                    </div>
                  </div>
                </>
                <div className={`${styles['scroll-button']}`}>
                  <ul className={`${styles['features-list']}`}>
                    {content.navigationItems.map((navItem: any, index: number) => {
                      if (!navItem.isBotomNavigation) {
                        return (
                          <li key={index} className={`${styles['features-item']} ${activeNavLinkId === navItem._uid ? styles.active : ''}`}>
                            <a href={navItem.url.cached_url || '/'} className={styles['feature-link']} onClick={() => dataLayerCheck(navItem.url.cached_url, navItem.title, false)}>
                              <img className={`${styles['icon-style']}`} src={navItem.icon} alt={navItem.title} />
                              <span className={`${styles['features-item-text']}`}>{navItem.title}</span>
                            </a>
                          </li>
                        );
                      }
                    })}
                  </ul>
                  <div className={`${styles['footer']}`}>
                    <ul className={`${styles['footer-features-list']}`}>
                      {content.navigationItems.map((navItem: any, index: number) => {
                        if (navItem.isBotomNavigation) {
                          return (
                            <li key={index} className={`${styles['features-item']} ${activeNavLinkId === navItem._uid ? styles.active : ''}`}>
                              <a href={navItem.url.cached_url || '/'} className={styles['feature-link']} onClick={() => dataLayerCheck(navItem.url.cached_url, navItem.title, true)}>
                                <img className={`${styles['icon-style']}`} src={navItem.icon} alt={navItem.title} />
                                <span className={`${styles['features-item-text']}`}>{navItem.title}</span>
                              </a>
                            </li>
                          )
                        }
                      })}
                    </ul>
                    <div className={`${styles['border-bottom']}`}></div>
                    <ul className={`${styles['category-list']}`}>
                      {content.impressumList.map((navItem: any) => {
                        return (
                          <li className={`${styles['category-item']}`}>
                            <a href={navItem.url.cached_url || '/'} onClick={() => dataLayerCheck(navItem.url.cached_url, navItem.title, true)}>
                              <span className={`${styles['category-item-text']}`}>{navItem.title}</span>
                            </a>
                          </li>
                        )
                      })}
                    </ul>
                    <div className={`${styles['footer__bottom']}`}>
                      <div className={`${styles['footer__inner']}`}>
                        <div className='s20-footer__copyright'>© {new Date().getFullYear()} {content.copyRightText}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </React.Fragment>
        </NavStoreProvider>
        <SbTutorial tutorialConfig={content.tutorial} />
      </SbEditable>
    );
  } else {
    return <div></div>
  }
};

export default MswMainNavigation;
