
import { SyntheticEvent } from 'react';
import { useNavStoreData } from '@/components/general/MainNavigation/NavContext';
import DataLayerGtmService from 'src/utils/DataLayer/DataLayerGtmService';
import { DataLayerGtmConstants } from 'src/utils/DataLayer/DataLayerGtmConstants';

interface MobileMenuItemSchema {
  content: any;
  activeNavLinkId: string;
}
const MobileMenuItem = ({ content, activeNavLinkId }: MobileMenuItemSchema): JSX.Element => {
  const { navStore, setActiveMobId } = useNavStoreData();
  const setId = (event: SyntheticEvent, id: string, disableClick: boolean) => {
    if (navStore && navStore.activeMobId === id) {
      //on second click of menu item reset the nav state and navigate to the page    
      //reset();
    } else {
     
      if (disableClick) {
        //on first click of menu item with sub menu, prevent navigation and set the activeId
        setActiveMobId(id);
        return event.preventDefault();
      }
      //on first click of menu item without sub menu, reset the nav state and navigate to the page
      //reset();
    }
  };

  function dataLayerCheck(event: any, content: any): void {
    DataLayerGtmService.addGtmDataLayer('', { event: DataLayerGtmConstants.event.GA_EVENT, event_name: DataLayerGtmConstants.event.navigations.MAINNAVIGATION_ICON_CLICK, link_url: content.url.cached_url, click_text: content.title });
    setId(event, content._uid, false)
  }
  
  return (
    <div className={`s20-bottom-navigation__item  ${activeNavLinkId === content._uid ? 'is-active' : ''}`}>
      {/* menu items with submenu that can be toggled */}
      <a href={content.url.cached_url || '/'} key={content._uid} 
        className={`s20-bottom-navigation__link`}
          onClick={(event) => dataLayerCheck(event, content)}
        >
        <div className={`s20-bottom-navigation__icon s20-bottom-navigation__icon--overview`}>
        <img src={content.icon} alt='' width={20} height={27} className='s20-bottom-navigation__img'/>  
		    <img src={content.mobIcon} alt='' width={20} height={27} className='s20-bottom-navigation__img-active' />  
 </div>
        <div className='s20-bottom-navigation__title' style={{textAlign: 'center'}}>
          {content.title}
        </div>
        </a>
    </div>
  );
};
export default MobileMenuItem;
