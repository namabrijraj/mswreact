import MobileMenuItem from "@/components/general/MainNavigation/MobileNavigation/MobileMenuItem/MobileMenuItem";
import { MainNavBarSchema } from "@/components/general/MainNavigation/MainNavigation";

import useNavService from "../useNavService";
import { useEffect, useState } from "react";

interface MobileNavSchema {
  key: string;
  content: MainNavBarSchema;
  activeNavLinkId: string;
}
const MobileNavigation = (props: MobileNavSchema): JSX.Element => {
  const headerContent: any = props?.content?.header[0];
  const isNewMobileNavigation: boolean = (headerContent?.component === 'mswMainNavigation') || false;
  const newMobileNav: boolean = isNewMobileNavigation && window?.innerWidth < 1024 ? true : false;
  const { activeNavLinkId } = useNavService(
    isNewMobileNavigation ? props.content.header[0].mobileBottomNavigation : props.content.header[0].navigationItems
  );
  const [hideNavigation, setHideNavigation] = useState<any>([]);
  useEffect(() => {
    window.ReactApp.Env.hideNavigation && setHideNavigation(JSON.parse(window.ReactApp.Env.hideNavigation))
  }, []);
  const navigationContents: any = isNewMobileNavigation ? headerContent?.mobileBottomNavigation : headerContent.navigationItems;
  return (
    <>
    {hideNavigation.length > 0 ?
      <div id='mobilenav'
        className='s20-bottom-navigation-wrapper js-bottom-navigation-wrapper' style={{ marginTop: 0 }}>
        <div className={`s20-bottom-navigation js-bottom-navigation ${newMobileNav ? '' : 'is-visible-tablet-portrait'} is-detached`}>
          <div className='s20-bottom-navigation__list'>
            {hideNavigation.length > 0 &&
              navigationContents?.map((navItem: any) => (
                hideNavigation.map((item: any) => {
                  if (item.hideNavUrl !== navItem.url.cached_url) {
                    return (
                      <MobileMenuItem
                        key={navItem._uid + "mobile"}
                        activeNavLinkId={activeNavLinkId}
                        content={navItem}
                      />
                    );
                  }
                })
              ))
            }
          </div>
        </div>
      </div> : null}
    </>
  );
};
export default MobileNavigation;
