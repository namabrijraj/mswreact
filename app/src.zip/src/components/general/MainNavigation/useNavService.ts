import { useRouter } from 'next/router';
import React from 'react';
import { useState } from 'react';
import { NavProviderSchema, NavState } from './NavContext';

export const initialState: NavState = {
  activeDeskId: '',
  activeMobId: '',
  isMobMenuOpen: false,
};

const useNavService = (
  navItems: any[]
): { activeNavLinkId: string; navCtx: NavProviderSchema } => {
  let activePagePath = useRouter().asPath;
  const getActiveNavLink = (): string => {
    // check current page is under help page and and identify help page link in main navigation items
    let activeLinkId = '';

    navItems.forEach((navItem) => {
      let nav = navItem.url.cached_url.replace('.html', '');
      nav = nav.replace('/mysunrise', '');
      if (activePagePath.includes(nav)) {
        activeLinkId = navItem._uid;
        return true;
      }
      return false;

    });

    return activeLinkId;
  };
  const [activeNavLinkId] = useState<string>(() => getActiveNavLink());
  //Initialising the state for the main navigation and declaring all the handlers to update the state.
  const [navStore, updateNavStore] = useState(initialState);
  //set the parent id of open desktop sub menu
  const setActiveDeskId = (id: string) => {
    updateNavStore((prevState) => ({ ...prevState, activeDeskId: id }));
  };
  //set the parent id of open mobile sub menu
  const setActiveMobId = (id: string) => {
    updateNavStore((prevState) => ({ ...prevState, activeMobId: id }));
  };
  //toggle the mobile menu open or close
  const toggleMobNav = () => {
    updateNavStore((prevState) => ({ ...prevState, isMobMenuOpen: !prevState.isMobMenuOpen }));
  };
  //reset the main navigation state
  const reset = () => {
    updateNavStore({ ...navStore, ...initialState });
  };
  //the value for navigation context
  //note : the value is memoized and it changes only on navStore state changes
  const navCtx = React.useMemo(
    () => ({
      navStore,
      setActiveDeskId,
      setActiveMobId,
      toggleMobNav,
      reset,
    }),
    [navStore]
  );

  return { activeNavLinkId, navCtx };
};

export default useNavService;
