import React from "react";
import { useNavStoreData } from "@/components/general/MainNavigation/NavContext";
import SubNavigation, { SubNavigationColumnSchema } from "../SubNavigation/SubNavigation";
import { GenericSBProps } from "@/components/index";
import { NavigationLinkSchema } from "../MainNavigation";
import DataLayerService from "src/utils/DataLayer/DataLayerService";
import { DataLayerConstants } from "src/utils/DataLayer/DataLayerConstants";
import { DataLayerGtmConstants } from "src/utils/DataLayer/DataLayerGtmConstants";

export interface NavigationItemSchema extends GenericSBProps, NavigationLinkSchema {
  subNavigation: SubNavigationColumnSchema[];
}

interface NavItemSchema {
  key: string;
  content: any;
  activeNavLinkId: string;
}

const NavigationMenuItem = ({
  content,
  activeNavLinkId,
}: NavItemSchema): JSX.Element => {
  const { navStore } = useNavStoreData();
  function handleOnClick(content: any): void {
    DataLayerService.addEventData([
      { eventName: DataLayerConstants.event.HEADER_MENU, eventType: DataLayerConstants.event.CLICK,  gtmInfo: { event_name: DataLayerGtmConstants.event.navigations.MAINNAVIGATION_CLICK, link_url: content && content.url && content.url.url, click_text: content && content.title } }
    ], true);
  }
  return (
    <>
      <div className={`s20-header__item  ${ navStore.activeDeskId === content._uid || activeNavLinkId === content._uid ? "is-active" : "" } ${content.subNavigation.length <= 0 ? 'js-header-item--no-sublist' : ''}`}>
        <a href={content.subNavigation && content.url.cached_url || "/"}
        target={`${content.isPromotion?"_blank":"_self"}`} onClick={() => handleOnClick(content)}
        className={`s20-header__link s20-header__link--main ${content.isPromotion && "s20-header__link--promo"} ${content.subNavigation.length > 0 && "js-header-main-link-s20"}`}
          data-title={content.title}
        >
        {content.title}
        </a>
      {content.subNavigation.length > 0 && 
        <div className={`s20-header__submenu`}>
            <div className="s20-header__inner">
              <div className="s20-header__container">
                <div className="s20-header__submenu-list">
                  <ul className="s20-header__list">
                    {content.subNavigation.length > 0 && (
                      <SubNavigation content={content.subNavigation}/>
                    )}
                  </ul>
                </div>
              </div>
            </div>
        </div>
      }
    </div>
    </>
  );
};
export default NavigationMenuItem;
