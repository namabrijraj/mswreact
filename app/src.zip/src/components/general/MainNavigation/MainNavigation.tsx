import { ComponentWithContentProps, GenericSBProps } from "@/components/index";
import { Asset, MultiLink } from "@/utils/storyblok-types";
import SbEditable from "storyblok-react";
import NavigationMenuItem from "@/components/general/MainNavigation/NavigationMenuItem/NavigationMenuItem";
import useOnClickOutside from "@/components/general/Footer/useOnClickOutside";
import useNavService from "./useNavService";
import NavStoreProvider from "./NavContext";
import HeaderSearch from "@/components/containers/PageProperties/HeaderSearch";
import { useEffect, useState } from "react";
import InfoBanner from "@/components/containers/PageProperties/InfoBanner";
import { setBuildEnvironment } from "@/utils/global";
import { version } from "package.json";
import storyblokInstance from "@/utils/StoryblokService";
import SbTutorial from "@/components/containers/PageProperties/SbTutorial";
import DataLayerService from '../../../../../src/utils/DataLayer/DataLayerService';
import { DataLayerConstants } from '../../../../../src/utils/DataLayer/DataLayerConstants';
import LangSelector from "@/src-components/Logout/LangSelector";
declare let window: any;

export interface HeaderSchema extends GenericSBProps {
  navigationItems: any;
  mobileBottomNavigation?: any[];
}

export interface MainNavBarSchema extends GenericSBProps {
  Config: any;
  navigationItems: any[];
  header: HeaderSchema[];
  sunriseLogoLink: MultiLink;
  searchIconLink: MultiLink;
  mySunriseLink: MultiLink;
  mySunriseTitle: string;
  sunriseLogo: Asset;
  tutorial: any;
}

export interface NavigationLinkSchema extends GenericSBProps {
  id: string;
  title: string;
  disableLink:boolean;
  isPromotion: boolean;
  url: MultiLink;
  icon: string;
}

const MainNavigation = ({
  
  content,
}: ComponentWithContentProps<MainNavBarSchema>): JSX.Element => {
  const { activeNavLinkId, navCtx } = useNavService(content.navigationItems);
  const ref = useOnClickOutside<HTMLDivElement, string>(
    navCtx.reset,
    "",
    navCtx.navStore.activeDeskId !== ""
  );
  
  const [enableInfoBanner, setEnableInfoBanner] = useState<boolean>(false);
  const [buildEnvCheck, setBuildEnvCheck] = useState<string | undefined>('');
  const [hideNavigation, setHideNavigation] = useState<any>([]);
  const [langauges, setLanguages] = useState<any>([]);
  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.sessionStorage.removeItem('newPanelDesign');
    }
    setEnableInfoBanner(content.Config[0].enableInfoBanner);
    storyblokInstance.client.get('cdn/datasource_entries', {
      "datasource": "locale-id"
    })
      .then(response => {
        setLanguages(
           response.data.datasource_entries
        )
      })
    setBuildEnvironment();
    if (typeof window !== undefined) {
      setBuildEnvCheck(window.build);
    }
  
    
    window.ReactApp.Env.hideNavigation && setHideNavigation(JSON.parse(window.ReactApp.Env.hideNavigation))
  }, []);

  function handleOnClick(event: React.MouseEvent<HTMLAnchorElement, MouseEvent>): void {
    DataLayerService.addEventData([
      { eventName: DataLayerConstants.event.HEADER_MENU, eventType: DataLayerConstants.event.CLICK, eventValue: event && event.currentTarget && event.currentTarget.innerText }
    ], true);
  }

  if (typeof window !== 'undefined' && !window.location.href.includes('login')){return (
    <SbEditable content={content}>
      <NavStoreProvider value={navCtx}>
        <div className="s20-header-sticky js-stickybox">
          <header
            ref={ref}
            className={`s20-header js-header-s20 s20-header--mys s20-header--single-sublists`}
          >
            <div className="s20-header__main">
              {enableInfoBanner && <InfoBanner pageConfig={content.Config[0]} />}
              <div className="s20-header__top" role="navigation">
                {buildEnvCheck && buildEnvCheck !== 'prod' &&
                  <div className="s20-header__version-number">
                    <p>MSW - {version}</p>
                  </div>
                }
                <div className="s20-header__inner">
                  <div className="s20-header__top-list">
                    {content.header.map((links: any) => (
                    links.headerLinks.map((item: any) => (
                        <div className="s20-header__top-item" >
                          <a className="s20-header__link"
                            href={((item.label?.toLowerCase())?.includes('cockpit')) ? (typeof (window) !== 'undefined' && window.ReactApp.Env.topHeaderCockpitUrl)
                              : (item.url.cached_url ? item.url.cached_url : '#')}
                            onClick={(event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => handleOnClick(event)} target="_blank" rel="noopener noreferrer">
                            {item.label}
                          </a>
                        </div>
                            ))))}
                    <div className="s20-header__top-item">
                      {langauges && Array.isArray(langauges) && <LangSelector isWeb={true} langauges={langauges} />}
                    </div>
                  </div>
                </div>
              </div>
              <div
                className={`s20-header__navigation js-stickybox-element-s20`}
              >
                <>
                  <div
                    className={`s20-header__inner`}
                  >
                    {/* Brand logo */}
                    <div className="s20-header__container">
                      <div className="s20-header__logo">
                        <a
                          href={content.sunriseLogoLink.cached_url || "/"}
                          onClick={navCtx.reset}
                          className={`s20-header__logo-link`}
                        >
                          <img
                            className="s20-header__logo-img"
                            alt="Logo MySunrise"
                            src={content.sunriseLogo.filename}
                          />
                        </a>
                      </div>
                      <nav
                        className={`s20-header__menu`}
                      >
                        {hideNavigation.length > 0 ?
                          (content.navigationItems.map((navItem) => (
                            hideNavigation.map((item: any) => {
                              const hideNavigationItem = (item.hideNav === 'true' || item.hideNav === true || item.hideNav === '') ? true : false
                              if (hideNavigationItem) {
                                if (item.hideNavUrl !== navItem.url.cached_url) {
                                  return (
                                    <NavigationMenuItem
                                      key={navItem._uid}
                                      content={navItem}
                                      activeNavLinkId={activeNavLinkId}
                                    />
                                  );
                                }
                              } else {
                                return (
                                  <NavigationMenuItem
                                    key={navItem._uid}
                                    content={navItem}
                                    activeNavLinkId={activeNavLinkId}
                                  />
                                );
                              }}
                            )
                          ))) :
                          (content.navigationItems.map((navItem) => {
                            return (
                              <NavigationMenuItem
                                key={navItem._uid}
                                content={navItem}
                                activeNavLinkId={activeNavLinkId}
                              />
                            );
                          }))
                        }
                      </nav>
                      {/* cta section */}
                      <div
                        className={`s20-header__cta`}
                      >
                        <HeaderSearch pageConfig={content.Config[0]} />
                      </div>
                    </div>
                  </div>
                </>
              </div>
            </div>
          </header>
        </div>
      </NavStoreProvider>
      <SbTutorial tutorialConfig={content.tutorial} />
    </SbEditable>
  );
} else {
  return  <div></div>
}
};

export default MainNavigation;


