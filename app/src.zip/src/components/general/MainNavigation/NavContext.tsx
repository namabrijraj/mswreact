import { createContext, useContext } from 'react';

interface NavProviderProps {
  children: JSX.Element;
  value: NavProviderSchema;
}
export interface NavState {
  activeDeskId?: string;
  activeMobId?: string;
  isMobMenuOpen?: boolean;
}

export interface NavProviderSchema {
  navStore: NavState;
  setActiveDeskId: (id: string) => void;
  setActiveMobId: (id: string) => void;
  toggleMobNav: () => void;
  reset: () => void;
}
//using context api to maintain main navigation state
const NavContext = createContext({} as NavProviderSchema);

//Provider for navContext
const NavStoreProvider = ({ children, value }: NavProviderProps): JSX.Element => {
  return <NavContext.Provider value={value}>{children}</NavContext.Provider>;
};
export default NavStoreProvider;

//custom hook to fetch values from navContext
export const useNavStoreData = (): {
  navStore: NavState;
  setActiveDeskId: (id: string) => void;
  setActiveMobId: (id: string) => void;
  toggleMobNav: () => void;
  reset: () => void;
} => useContext(NavContext);
