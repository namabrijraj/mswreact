import React from 'react';
import { connect } from 'react-redux';
import { version } from "package.json";
import { bindActionCreators, Dispatch, ActionCreatorsMapObject } from 'redux';
import { SbEditableContent } from 'storyblok-react';
import HeaderSearch from "@/components/containers/PageProperties/HeaderSearch";
import DataLayerService from '../../../../../../src/utils/DataLayer/DataLayerService';
import { DataLayerConstants } from '../../../../../../src/utils/DataLayer/DataLayerConstants';
import I18n from '../../../../../../src/utils/helper/I18n';
import Cookies from 'js-cookie';
import {HeaderConstants} from '../../../../../../src/containers/Header/HeaderConstants';
import DataLayerGtmService from 'src/utils/DataLayer/DataLayerGtmService';
import { DataLayerGtmConstants } from 'src/utils/DataLayer/DataLayerGtmConstants';

export interface MswNewHeaderProps {
    content: SbEditableContent,
    langauges: any,
    navCtx: any,
}

interface MswNewHeaderState {
    selectedBenefit: string[];
    innerWidth: number;
    hour:number;
    firstName: string;
    customerId: string;
}

class MswNewHeader extends React.Component<MswNewHeaderProps, MswNewHeaderState> {
    constructor(props: MswNewHeaderProps) {
        super(props);
        this.state = {
            selectedBenefit: [],
            innerWidth: (typeof window !== 'undefined') ? window.innerWidth : 0,
            hour: 0,
            firstName: '',
            customerId: '',
        };
    }

    static getDerivedStateFromProps(): any | null {
    }

    componentDidMount(): void {
      typeof window !== 'undefined' && window.addEventListener('resize', this.onViewChange);
    this.onViewChange();
    this.getHour();
    this.getUserData();
    }

    onViewChange = () => {
      if (typeof window !== 'undefined')
        this.setState({
          innerWidth: window.innerWidth
        });
      }

      handleOnClick = (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>): void => {
        DataLayerService.addEventData([
          { eventName: DataLayerConstants.event.HEADER_MENU, eventType: DataLayerConstants.event.CLICK, eventValue: event && event.currentTarget && event.currentTarget.innerText }
        ], true);
      }

      getHour = () => {
        const date = new Date();
        var hour = date.getHours();
        this.setState({
          hour
        });
       }

       getUserData = (): string => {
        let userData: string = '';
        const userCookieValue: string = Cookies.get(HeaderConstants.SUNRISE_AUTH) || '',
          userDetails: { firstName: string, siteId: string } = userCookieValue && JSON.parse(decodeURIComponent(userCookieValue)) || {};
        if (userCookieValue && userDetails && Object.keys(userDetails).length) {
            this.setState({
                firstName: userDetails.firstName || '',
                customerId: userDetails.siteId || ''
            })
        }
        return userData;
      }
      renderName(): JSX.Element | null {
        const { hour, firstName, customerId } = this.state;
        if (hour >= 5 && hour < 12)
          var greeting = I18n.translate('Dashboards.Overview.Label.GoodMorning');
        else if (hour >= 12 && hour < 17) {
          var greeting = I18n.translate('Dashboards.Overview.Label.GoodAfternoon');
        } else {
          var greeting = I18n.translate('Dashboards.Overview.Label.GoodEvening');
        }
          return (
            <>
             <div className='s20-heading-teaser s20-heading-teaser--simple s20-heading-teaser--no-box'>
                <div className='s20-heading-teaser__container'>
                  <div className='s20-heading-teaser__greeting'/>
                  <div className='s20-heading-teaser__title' style={{display: 'block'}}>
                    <div className='s20-heading-teaser__title-name' data-max-characters='32' style={{fontSize: '18px'}}>
                      {greeting}
                      {', '}
                      {firstName}
                    </div>
                    <div className='s20-heading-teaser__text' style={{marginTop: '0px', lineHeight: '20px'}}>
                      <div className='t-semi-bold'>
                        {I18n.translate('Dashboards.RatePlan.Label.CustomerNumber')}: &nbsp;
                        <span className='s20-heading-teaser__link'>
                          {customerId}
                          </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='s20-spacer s20-spacer--x8'/>
            </>
          );
      }

  handleClick = (navCtx: any, url: string): void => {
    navCtx.reset;
    DataLayerGtmService.addGtmDataLayer('', { event: DataLayerGtmConstants.event.GA_EVENT, event_name: DataLayerGtmConstants.event.navigations.MAINNAVIGATION_CLICK, link_url: url, click_text: 'logo' });
  }

    renderHeaderContent = (): JSX.Element => {
        const {content, navCtx, langauges} = this.props;
        const {innerWidth} = this.state;
        const isNewMobileHeader: boolean = (innerWidth < 751) ? true : false;
        const buildEnvCheck: string = typeof window !== 'undefined' && window.build || '';
        return (
            <div className={`s20-header__navigation js-stickybox-element-s20`}  style={isNewMobileHeader ? { display: 'flex', justifyContent: 'flex-end', width: '100%'} : {}}>
                  <div className={`s20-header__inner`}  style={(innerWidth > 850) ? {paddingLeft: '16px', width: '100%'}: {}}>
                    {/* Brand logo */}
                    <div className="s20-header__container"  style={!isNewMobileHeader ? { display: 'flex', justifyContent: 'flex-end', width: '100%'} : {}}>
                        <div className="s20-header__logo msw_new_header_primary_logo">
                        <a
                          href={content.sunriseLogoLink.cached_url || "/"}
                          className={`s20-header__logo-link`}
                          onClick={() => this.handleClick(navCtx, content.sunriseLogoLink.cached_url)}
                        >
                          {buildEnvCheck && buildEnvCheck !== '' && buildEnvCheck !== 'prod' &&
                            <div className="s20-header__version-number" style={{ width: 'max-content' }}>
                              <p>MSW - {version}</p>
                            </div>
                          }
                          <img
                            className="s20-header__logo-img msw_new_header_img"
                            alt="Logo MySunrise"
                            src={content?.sunriseLogo?.filename}
                          />
                        </a>
                      </div>
                      {(innerWidth < 1024) ? '' :
                      <>
                      <hr className='msw_new_header_inclined_line' />
                      <div className='msw_new_header_secondary_logo'>
                        <a
                          href={content.mySunriseLink.cached_url || "/"}
                          className={`s20-header__logo-link`}
                          onClick={() => this.handleClick(navCtx, content.mySunriseLink.cached_url)}
                        >
                          <img
                            className="s20-header__logo-img msw_new_header_img"
                            alt="Logo MySunrise"
                            src={content?.mysunriseLogo?.filename}
                            style={{height: '40px'}}
                          />
                        </a>
                      </div>
                      </>
                      }
                      <div className={`s20-header__cta`} >
                        <HeaderSearch pageConfig={content.Config[0]} isNewHeader={true} innerWidth={innerWidth} bottomNavigation={content?.impressumList} copyRightText={content?.copyRightText} languages={langauges?.length > 1 ? langauges : []} />
                      </div>
                    </div>
                    {(innerWidth < 1024) ? this.renderName() : ''}
                  </div>
            </div>
        )
    }

    render(): React.ReactNode {
        return (
            <React.Fragment>
                {this.renderHeaderContent()}
            </React.Fragment>
        );
    }
}

const mapStateToProps: any = ({}) => {
    return {

    };
};
const mapDispatchToProps: ((dispatch: Dispatch) => ActionCreatorsMapObject) = (dispatch) => {
    return bindActionCreators({ }, dispatch);
};

export default connect<MswNewHeaderProps>(mapStateToProps, mapDispatchToProps)(MswNewHeader);
