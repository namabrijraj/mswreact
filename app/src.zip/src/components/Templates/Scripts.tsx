import { I18NSCRIPTDE, I18NSCRIPTEN, I18NSCRIPTFR, I18NSCRIPTIT, TESTI18NSCRIPTDE, TESTI18NSCRIPTEN, TESTI18NSCRIPTFR, TESTI18NSCRIPTIT } from "@/utils/constants";

export const getTrackingScripts = (): any => {
  return (
    <>
      {/* Jquery Dependency for Analytics  */}
      <script src='https://code.jquery.com/jquery-3.6.0.min.js'></script>
      {/* Analytics Script Inclusion  */}
      {process.env.ENV === 'prod' ?
        <script src="https://assets.adobedtm.com/e9113abe4a4d/499c171a947e/launch-433edf73d66d.min.js" async></script>
        : <script src='https://assets.adobedtm.com/e9113abe4a4d/ad305b36bf00/launch-ENf2da5f2d84894c8b9a7d83b136c0a74d.min.js'
          async>
        </script>
      }
       {/* Google Tag Manager */}
       <script
        dangerouslySetInnerHTML={{
          __html: `
	          (function(w,d,s,l,i){
	          w[l]=w[l]||[];
	          w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});
            var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';
            j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
            })(window,document,'script','dataLayer','GTM-TZ48GTT');
          `
        }}
        async
      ></script>
      {/* End Google Tag Manager */}
      {/* Google Tag Manager (noscript) */}
      <noscript>
        <iframe
          src='https://www.googletagmanager.com/ns.html?id=GTM-TZ48GTT'
          height='0'
          width='0'
          style={{ display: 'none', visibility: 'hidden' }}
        ></iframe>
      </noscript>
      {/* End Google Tag Manager (noscript) */}
    </>
  );
};

export const geti18nScripts = (lang: string): any => {
  if (process.env.ENV === 'prod') {
    return (
      <>
        {lang === 'en' && <script type='text/javascript' src={I18NSCRIPTEN + '?cv=' + Date.now()}></script>}
        {lang === 'de' && <script type='text/javascript' src={I18NSCRIPTDE + '?cv=' + Date.now()}></script>}
        {lang === 'fr' && <script type='text/javascript' src={I18NSCRIPTFR + '?cv=' + Date.now()}></script>}
        {lang === 'it' && <script type='text/javascript' src={I18NSCRIPTIT + '?cv=' + Date.now()}></script>}
      </>
    );
  } else {
    return (
      <>
        {lang === 'en' && <script type='text/javascript' src={TESTI18NSCRIPTEN + '?cv=' + Date.now()}></script>}
        {lang === 'de' && <script type='text/javascript' src={TESTI18NSCRIPTDE + '?cv=' + Date.now()}></script>}
        {lang === 'fr' && <script type='text/javascript' src={TESTI18NSCRIPTFR + '?cv=' + Date.now()}></script>}
        {lang === 'it' && <script type='text/javascript' src={TESTI18NSCRIPTIT + '?cv=' + Date.now()}></script>}
      </>
    );
  }

};

export const getEnvScripts = (lang: string, props: any): any => {
  if (props !== undefined && !props.includes('kmu')) {
    if (process.env.ENV === 'dev') {
      return (
        <script type='text/javascript' src={process.env.ENV_FILE}></script>
      )
    } else {
      return (
        <>
          {lang === 'en' && <script type='text/javascript' src={process.env.ENV_FILE_EN + '?cv=' + Date.now()}></script>}
          {lang === 'de' && <script type='text/javascript' src={process.env.ENV_FILE_DE + '?cv=' + Date.now()}></script>}
          {lang === 'fr' && <script type='text/javascript' src={process.env.ENV_FILE_FR + '?cv=' + Date.now()}></script>}
          {lang === 'it' && <script type='text/javascript' src={process.env.ENV_FILE_IT + '?cv=' + Date.now()}></script>}
        </>
      );
    }
  }
  else if (props !== undefined && props.includes('kmu')) {
    if (process.env.ENV === 'dev') {
      return (
        <script type='text/javascript' src={process.env.ENV_FILE}></script>
      )
    } else {
      return (
        <>
          {lang === 'en' && <script type='text/javascript' src={process.env.ENV_KMU_EN + '?cv=' + Date.now()}></script>}
          {lang === 'de' && <script type='text/javascript' src={process.env.ENV_KMU_DE + '?cv=' + Date.now()}></script>}
          {lang === 'fr' && <script type='text/javascript' src={process.env.ENV_KMU_FR + '?cv=' + Date.now()}></script>}
          {lang === 'it' && <script type='text/javascript' src={process.env.ENV_KMU_IT + '?cv=' + Date.now()}></script>}
        </>
      );
    }
  }
};

