import { ReactChild } from "react";
import { Content } from "@/utils/storyblok-types";
import { BlokProps } from "@/utils/StoryblokService";
import Components from "@/components/index";

interface TemplateSchema extends BlokProps {
  content: Content;
  children: ReactChild;
}
const Template = ({
  content,
  metadata,
  children,
}: TemplateSchema): JSX.Element => {
  return (
    <>
      {content && content.header.length
        ? content.header.map((headerContent: Content) =>
            Components({
              content: headerContent,
              metadata,
            })
          )
        : null}
      {children && <div className="template-body">{children}</div>}
      {content && content.footer.length
        ? content.footer.map((footerContent: Content) =>
            Components({
              content: footerContent,
              metadata,
            })
          )
        : null}
    </>
  );
};

export default Template;
