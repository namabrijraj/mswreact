import Components from "@/components/index";
import SbEditable from "storyblok-react";
import { BlokProps } from "@/utils/StoryblokService";
import MobileNavigation from "../general/MainNavigation/MobileNavigation/MobileNavigation";
import React from "react";
import ChatWidgetSticky from "../containers/PageProperties/ChatWidgetSticky";
import CookieConsent from "../containers/PageProperties/CookieConsent";

interface PageProps extends BlokProps {
  content: {
    _uid: string;
    component: string;
    body: any;
    header: any;
    footer: any;
    pageProperties: any;
  };
}
const PageTemplate = ({ content, metadata }: PageProps): JSX.Element => (
  <SbEditable content={content}>
    {content.header
      ? content.header.map(
        (blok: any) =>
          content && Components({ content: blok, metadata: metadata })
      )
      : ""}
    {content.pageProperties &&
      content.pageProperties.map((blok: any) => (
        <ChatWidgetSticky content={blok} />
      ))}
    <div>
      {content.body
        ? content.body.map(
          (blok: any) =>
            content && Components({ content: blok, metadata: metadata })
        )
        : ""}
    </div>
    <CookieConsent />
    {content && content.header.length
      ? content.header.map(
        (headerContent: any) =>
          content && (
            <MobileNavigation
              content={headerContent.reference.content}
              activeNavLinkId=""
              key=""
            />
          )
      )
      : null}
    {content.footer
      ? content.footer.map(
        (blok: any) =>
          content && Components({ content: blok, metadata: metadata })
      )
      : ""}
  </SbEditable>
);
export default PageTemplate;
