import Components from "@/components/index";
import SbEditable from "storyblok-react";
import { BlokProps } from "@/utils/StoryblokService";

interface PageProps extends BlokProps {
  content: {
    _uid: string;
    component: string;
    body: any;
    header: any;
    footer: any;
  };
}
const Page = ({ content, metadata }: PageProps): JSX.Element => (
  <SbEditable content={content}>
    {content.header
      ? content.header.map(
        (blok: any) =>
          content && Components({ content: blok, metadata: metadata })
      )
      : ""}

    <div>
      {content.body
        ? content.body.map(
          (blok: any) =>
            content && Components({ content: blok, metadata: metadata })
        )
        : ""}
    </div>

    {content.footer
      ? content.footer.map(
        (blok: any) =>
          content && Components({ content: blok, metadata: metadata })
      )
      : ""}
  </SbEditable>
);
export default Page;
