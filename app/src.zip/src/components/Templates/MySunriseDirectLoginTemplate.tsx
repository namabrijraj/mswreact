import Components from '@/components/index';
import SbEditable from 'storyblok-react';
import { BlokProps } from '@/utils/StoryblokService';
import MobileNavigation from '@/components/general/MainNavigation/MobileNavigation/MobileNavigation';
import React from 'react';

interface PageProps extends BlokProps {
  content: {
    _uid: string;
    component: string;
    header: any;
    footer: any;
    body: any;
    pageTitle: string;
    metaTitle: string;
    metaDescription: string;
  };
}

const MySunriseDirectLoginTemplate = ({ content, metadata }: PageProps): JSX.Element => {

  return (
    <SbEditable content={content}>
      <div id='body'>
        {content.header
          ? content.header.map(
            (blok: any) => content && Components({ content: blok, metadata: metadata })
          )
          : ''}

        <div className={'s20-spacer s20-spacer--x24'}></div>

        <div>
          {content.body
            ? content.body.map(
              (blok: any) =>
                content &&
                Components({
                  content: blok,
                  metadata: metadata,
                })
            )
            : ''}
        </div>
        <div className='s20-spacer s20-spacer--x32'></div>
        {content.footer
          ? content.footer.map(
            (blok: any) => content && Components({ content: blok, metadata: metadata })
          )
          : ''}
        {content && content.header.length
          ? content.header.map (
            (headerContent: any) =>
              content && (
                <MobileNavigation
                  content={headerContent.reference.content}
                  activeNavLinkId=''
                  key=''
                />
              )
          )
          : null}
      </div>
    </SbEditable>
  );
};
export default MySunriseDirectLoginTemplate;
