import Components from '@/components/index';
import SbEditable from 'storyblok-react';
import { BlokProps } from '@/utils/StoryblokService';
import React, { useEffect, useRef, useState } from 'react';
import { useAuthData } from '@/utils/AuthUtils/SbLoginService';
import { getUrlParam } from '@/utils/global';
import { addExtraQueryPath, addSessionData } from '@/utils/Utils';
import MaintenanceBanner from '../containers/PageProperties/MaintenanceBanner';
import Login from '@/src-components/Login/Login';
import ProfileEditPassword, { ProfileEditPasswordProps } from '@/src-containers/Profile/ProfileEdit/ProfileEditPassword';
import ProfileExternalSuccessPassword, { ProfileExternalSuccessPasswordProps } from '@/src-containers/Profile/ProfileExternalSuccessPassword/ProfileExternalSuccessPassword';

interface PageProps extends BlokProps {
  content: {
    _uid: string;
    component: string;
    header: any;
    footer: any;
    body: any;
    pageTitle: string;
    metaTitle: string;
    metaDescription: string;
    pageProperties: any;
  };
  profileProps: ProfileEditPasswordProps,
  profileExternalProps: ProfileExternalSuccessPasswordProps
}

const MySunriseExternalLoginTemplate = ({ content, metadata, profileProps, profileExternalProps }: PageProps): JSX.Element => {
  const authData = useRef<string>();
  authData.current = useAuthData()?.status;
  const [pageConfigContent, setPageConfigContent] = useState<any>();
  let tutorials: any;
  const [headerContent, setHeaderContent] = useState<any>()
  const [showBannerComp, setShowBannerComp] = useState<any>();
  const [isUpdatePassword, setIsUpdatePassword] = useState<boolean>(false);
  const [isOTPStatus, setIsOTPStatus] = useState<boolean>(false);
  let componentList: any;

  useEffect(() => {
    addExtraQueryPath();
    // to enable debug mode for content authors
    if (getUrlParam('debugI18n')) {
      window.ReactApp.DebugI18n = true;
    }
    content.header.map((blok: any) => {
      blok.reference.content.header[0].tutorial = tutorials;
      setHeaderContent(blok);
      setPageConfigContent(blok.reference.content.header[0].Config[0]);
    });
    window.ReactApp.Env.componentsName && (componentList = window.ReactApp.Env.componentsName.split(','));
    setShowBannerComp(componentList?.map((componentList: any) => componentList.toUpperCase()));
  }, []);
  const getUpdatePassword = (value: any) => {
    setIsUpdatePassword(value);
  }
  const getOTPStatus = (value: any) => {
    setIsOTPStatus(value);
  }
  return (
    <SbEditable content={content}>
      <div id='body'>
        {headerContent ? Components({ content: headerContent, metadata: metadata }) : ''}
        {(metadata.activePath.includes('/mysunrise-external-login')) && (
          <div
            style={
              typeof window !== 'undefined' && !window.location.href.includes('mysunrise-external-login')
                ? {}
                : { display: 'flex', flex: '1' }
            }
          >
            {typeof window !== 'undefined' &&
              window.ReactApp.Env.enableMaintenanceBanner === 'true' ? (
              content.body && !showBannerComp?.includes(content.body[0].component.toUpperCase()) ? (
                content.body.map(
                  (blok: any) =>
                    content &&
                    pageConfigContent &&
                    Components({
                      content: blok,
                      metadata: metadata,
                      pageConfig: pageConfigContent,
                      property: content.pageProperties,
                    })
                )
              ) : (
                <MaintenanceBanner />
              )
            ) : content.body ? (
              content.body.map(
                (blok: any) =>
                  content &&
                  pageConfigContent &&
                  Components({
                    content: blok,
                    metadata: metadata,
                    pageConfig: pageConfigContent,
                    property: content.pageProperties,
                  })
              )
            ) : (
              ''
            )}
            {(authData.current === 'UnAuthenticated' && typeof window !== 'undefined' && !isOTPStatus) ? (
              <>
                {addSessionData() && (
                  <Login updateOTPStatus={(value: any) => getOTPStatus(value)} />
                )}
              </>
            ) : (authData.current === 'Authenticated' && typeof window !== 'undefined' || isOTPStatus) && (
              <>
                {isUpdatePassword ? <ProfileExternalSuccessPassword {...profileExternalProps} /> : <ProfileEditPassword {...profileProps} updatePassword={(value: any) => getUpdatePassword(value)} />}
              </>
            )}
          </div>
        )}
        {typeof window !== 'undefined' && !window.location.href.includes('mysunrise-external-login') ? (
          <div className='s20-spacer s20-spacer--x32'></div>
        ) : null}
        {content.footer && typeof window !== 'undefined' && !window.location.href.includes('login')
          ? content.footer.map(
            (blok: any) => content && Components({ content: blok, metadata: metadata })
          )
          : ''}
      </div>
    </SbEditable>
  );
};
export default MySunriseExternalLoginTemplate;
