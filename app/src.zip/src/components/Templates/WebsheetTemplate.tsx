import Components from '@/components/index';
import SbEditable from 'storyblok-react';
import { BlokProps } from '@/utils/StoryblokService';
import React from 'react';

interface WebsheetTempProp extends BlokProps {
  content: {
    _uid: string;
    component: string;
    header: any;
    body: any;
  };
}

const WebsheetTemplate = ({ content, metadata }: WebsheetTempProp): JSX.Element => {

  return (
    <SbEditable content={content}>
      <div id='body'>
        {content.header
          ? content.header.map(
            (blok: any) => content && Components({ content: blok, metadata: metadata })
          )
          : ''}
        <div>
          {content.body
            ? content.body.map(
              (blok: any) => content && Components({ content: blok, metadata: metadata })
            )
            : ''}
        </div>
      </div>
    </SbEditable>
  );
};
export default WebsheetTemplate;
