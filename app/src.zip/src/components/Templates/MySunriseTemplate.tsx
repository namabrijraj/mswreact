import Components from '@/components/index';
import SbEditable from 'storyblok-react';
import storyblokInstance, { BlokProps } from '@/utils/StoryblokService';
import MobileNavigation from '@/components/general/MainNavigation/MobileNavigation/MobileNavigation';
import React, { useEffect, useRef, useState } from 'react';
import ChatWidget from '../containers/PageProperties/ChatWidgetSticky';
import CookieConsent from '../containers/PageProperties/CookieConsent';
import { useAuthData } from '@/utils/AuthUtils/SbLoginService';
import RedirectComponent from '../containers/Redirect/Redirect';
import FooterBasketRecovery from '../containers/PageProperties/FooterBasketRecovery';
import PswdSecurityBanner from '../containers/PageProperties/PswdSecurityBanner';
import { getUrlParam } from '@/utils/global';
import { addExtraQueryPath, addSessionData } from '@/utils/Utils';
import ContactSticky from '../containers/PageProperties/ContactSticky';
import MaintenanceBanner from '../containers/PageProperties/MaintenanceBanner';
import SbSmartBanner from '../containers/PageProperties/SmartBanner';

interface PageProps extends BlokProps {
  content: {
    _uid: string;
    component: string;
    header: any;
    footer: any;
    body: any;
    pageTitle: string;
    metaTitle: string;
    metaDescription: string;
    pageProperties: any;
  };
}

const MySunriseTemplate = ({ content, metadata }: PageProps): JSX.Element => {
  const authData = useRef<string>();
  authData.current = useAuthData()?.status;
  const [checkBasketRecovery, setCheckBasketRecovery] = useState<boolean>(false);
  const [pageConfigContent, setPageConfigContent] = useState<any>();
  let tutorials: any;
  const [headerContent, setHeaderContent] = useState<any>()
  const [showBannerComp, setShowBannerComp] = useState<any>();
  const [redirection, setRedirection] = useState<any>();
  let componentList: any;

  useEffect(() => {
    addExtraQueryPath();
    // to enable debug mode for content authors
    if (getUrlParam('debugI18n')) {
      window.ReactApp.DebugI18n = true;
    }
    content.pageProperties.map((item: any) => {
      tutorials = item.tutorialsConfiguration;
      setCheckBasketRecovery(item.enableBasketRecovery);
    });
    content.header.map((blok: any) => {
      blok.reference.content.header[0].tutorial = tutorials;
      setHeaderContent(blok);
      setPageConfigContent(blok.reference.content.header[0].Config[0]);
    });
    window.ReactApp.Env.componentsName && (componentList = window.ReactApp.Env.componentsName.split(','));
    setShowBannerComp(componentList?.map((componentList: any) => componentList.toUpperCase()));
    storyblokInstance.client.get('cdn/stories/mysunrise/configuration/config-env')
     .then((response)=>{
        setRedirection(response.data);
      })
      
  }, []);

  useEffect(() => {
    if (window && window.location && window.location.hostname && redirection && redirection.story && redirection.story.content) {
      let host_name=window.location.hostname;
      host_name=host_name.split('.')[0];
      host_name=host_name.split('www-').length>1?host_name.split('www-')[1]:'prod';
      if (host_name && redirection.story.content[host_name] && Array.isArray(redirection.story.content[host_name]) && redirection.story.content[host_name].length) {
        if (redirection.story.content[host_name][0]["RedirectionBlock"] && Array.isArray(redirection.story.content[host_name][0]["RedirectionBlock"]) && redirection.story.content[host_name][0]["RedirectionBlock"].length) {
          redirection.story.content[host_name][0]["RedirectionBlock"].forEach((e: any) => {
            if (e.oldUrl === window.location.href) {
              window.location.href = e.newUrl
            }
          });
        }
      }
    }
  }, [redirection])

  return (
    <SbEditable content={content}>
      {authData.current === 'UnAuthenticated' && typeof window !== 'undefined' && (
        <>
          {addSessionData() && (
            <RedirectComponent url={window.ReactApp.Env.urlLoginSB} target='_self' />
          )}
        </>
      )}
      <div id='body'>
        {headerContent ? Components({ content: headerContent, metadata: metadata }) : ''}

        {content.pageProperties &&
          content.pageProperties.map((blok: any) => (
            <>
              {blok.enablePswdSecurityBanner &&
              pageConfigContent &&
              typeof window !== 'undefined' &&
              !window.location.href.includes('login') ? (
                <PswdSecurityBanner pageConfig={pageConfigContent} />
              ) : null}
              {pageConfigContent &&
                (typeof window !== 'undefined' && !window.location.href.includes('login') ? (
                  <ChatWidget content={blok} key={blok._uid} pageConfig={pageConfigContent} />
                ) : null)}
              {blok.redirect.url &&
                (typeof window !== 'undefined' && !window.location.href.includes('login') ? (
                  <RedirectComponent url={blok.redirect.url} key={blok._uid} target={'_self'} />
                ) : null)}
            </>
          ))}

        {typeof window !== 'undefined' && window.location.hash.includes('Contest') === false ? (
          <>
            {!window.location.href.includes('login') ? (
              <>
                <div className='s20-spacer s20-spacer--x40 is-hidden-mobile'></div>
                <div className='s20-spacer s20-spacer--x16 is-visible-mobile'></div>
              </>
            ) : null}
          </>
        ) : null}

        {(authData.current === 'Authenticated' || metadata.activePath.includes('/login')) && (
          <div
            style={
              typeof window !== 'undefined' && !window.location.href.includes('login')
                ? {}
                : { display: 'flex', flex: '1' }
            }
          >
            {typeof window !== 'undefined' &&
            window.ReactApp.Env.enableMaintenanceBanner === 'true' ? (
              content.body && !showBannerComp?.includes(content.body[0].component.toUpperCase()) ? (
                content.body.map(
                  (blok: any) =>
                    content &&
                    pageConfigContent &&
                    Components({
                      content: blok,
                      metadata: metadata,
                      pageConfig: pageConfigContent,
                      property: content.pageProperties,
                    })
                )
              ) : (
                <MaintenanceBanner />
              )
            ) : content.body ? (
              content.body.map(
                (blok: any) =>
                  content &&
                  pageConfigContent &&
                  Components({
                    content: blok,
                    metadata: metadata,
                    pageConfig: pageConfigContent,
                    property: content.pageProperties,
                  })
              )
            ) : (
              ''
            )}
          </div>
        )}
        {content.pageProperties &&
          content.pageProperties.map((blok: any) => (
            <>{checkBasketRecovery && <FooterBasketRecovery content={blok} />}</>
          ))}
        {typeof window !== 'undefined' && !window.location.href.includes('login') ? (
          <div className='s20-spacer s20-spacer--x32'></div>
        ) : null}
        {content.footer && typeof window !== 'undefined' && !window.location.href.includes('login')
          ? content.footer.map(
              (blok: any) => content && Components({ content: blok, metadata: metadata })
            )
          : ''}
        {typeof navigator !== 'undefined' &&
        /^((?!chrome|android).)*safari/i.test(navigator.userAgent) ? (
          <></>
        ) : (
          <SbSmartBanner />
        )}
        {content.pageProperties &&
          content.pageProperties.map((blok: any) => (
            <>
              {pageConfigContent && (
                <ContactSticky content={blok} key={blok._uid} pageConfig={pageConfigContent} />
              )}
            </>
          ))}
        {content && content.header && content.header.length
          ? content.header.map(
              (headerContent: any) =>
                content &&
                (typeof window !== 'undefined' && !window.location.href.includes('login') ? (
                  <MobileNavigation
                    content={headerContent.reference.content}
                    activeNavLinkId=''
                    key=''
                  />
                ) : (
                  <></>
                ))
            )
          : null}
         {pageConfigContent &&
        typeof window !== 'undefined' &&
        !window.location.href.includes('login') ? (
          <CookieConsent pageConfig={pageConfigContent} />
        ) : (
          <></>
        )}
      </div>
    </SbEditable>
  );
};
export default MySunriseTemplate;
