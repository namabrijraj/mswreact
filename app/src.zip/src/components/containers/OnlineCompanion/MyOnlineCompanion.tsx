import React, { useEffect, useState } from 'react';
import SbEditable from 'storyblok-react';
import { GenericSBProps } from '@/components/index';
import { getSlugname } from '@/utils/Utils';
import storyblokInstance from '@/utils/StoryblokService';
import { OnlineCompanionProps } from '@/src-components/OnlineCompanion/OnlineCompanion';
import StaticWrapperComponent, { StaticSectionProps } from '@/components/general/StaticWrapper';
import { StoryStaticType } from '@/utils/mysunrise-utils-types';
import dynamic from 'next/dynamic';
import { HashRouter as Router, Route, Switch } from 'react-router-dom';
import HardwareSelection, {
  HardwareSelectionProps,
} from '@/src-components/OnlineCompanion/InstallationGuide/HardwareSelection';
import InstallationStepsView, {
  InstallationStepsViewProps,
} from '@/src-components/OnlineCompanion/InstallationGuide/InstallationSteps/InstallationStepsView';
import PreparationStepsView, {
  PreparationStepsViewProps,
} from '@/src-components/OnlineCompanion/InstallationGuide/PreparationStepsView';
import OtoIdStepsView, { OtoIdStepsViewProps } from '@/src-components/OnlineCompanion/OtoIdSteps/OtoIdStepsView';
import PoaResubmission, {PoaResubmissionFormProps} from '@/src-components/OnlineCompanion/PoaResubmission/PoaResubmission';
import MobileOrders, { MobileOrdersProps } from '@/src-containers/Overview/MobileOrders/MobileOrders';

const OnlineCompanion = dynamic(() => import('@/src-components/OnlineCompanion/OnlineCompanion'), {
  ssr: false,
});

interface MyOnlineCompanionProps extends GenericSBProps, OnlineCompanionProps { }

const MyOnlineCompanion = (props: MyOnlineCompanionProps): JSX.Element => {
  const { content } = props;
  const [onlineCompanion, setOnlineCompanion] = useState<StoryStaticType | null>({
    staticSection: [],
    loadComponent: false,
  });
  const params = getSlugname();

  useEffect(() => {
    (async () => {
      const response = await storyblokInstance.getPageContent(params);
      response.data.story.content.body.map((item: StoryStaticType) => {
        setOnlineCompanion({
          ...item,
          staticSection: item.staticSection,
          loadComponent: true,
        });
      });
    })();
  }, []);

  return (
    <>
      <SbEditable content={content}>
        <div data-component='MyOnlineCompanion'>
          {process.browser && onlineCompanion && onlineCompanion.loadComponent && (
            <>
              {onlineCompanion.staticSection &&
                onlineCompanion.staticSection.map((staticContent: StaticSectionProps) => (
                  <StaticWrapperComponent content={staticContent} key={staticContent._uid} />
                ))}
              {process.browser && (
                <Router>
                  <Switch>
                    <Route
                      exact
                      path='/'
                      component={(props: OnlineCompanionProps) => <OnlineCompanion {...props} />}
                    />
                    <Route
                      exact
                      path='/MobileOrders/:orderId'
                      component={(props: MobileOrdersProps) => <MobileOrders { ...props} />}
                    />
                    <Route
                      exact
                      path='/MobileOrders/:orderId/PoaResubmissionForm'
                      component={(props: PoaResubmissionFormProps) => (
                        <PoaResubmission {...props} />
                      )}
                    />
                    <Route
                      exact
                      path='/ScannedData'
                      component={(props: MobileOrdersProps) => <MobileOrders { ...props} />}
                    />
                    <Route
                      exact
                      path='/HardwareSelection'
                      component={(props: HardwareSelectionProps) => (
                        <HardwareSelection {...props} />
                      )}
                    />
                    <Route
                      exact
                      path='/InstallationStepsView'
                      component={(props: InstallationStepsViewProps) => (
                        <InstallationStepsView {...props} />
                      )}
                    />
                    <Route exact path='/OtoIdStep' component={(props: OtoIdStepsViewProps) => <OtoIdStepsView {...props} />} />
                    <Route
                      exact
                      path='/PreparationStepsView'
                      component={(props: PreparationStepsViewProps) => (
                        <PreparationStepsView {...props} />
                      )}
                    />
                    <Route
                      exact
                      path='/PoaResubmissionForm'
                      component={(props: PoaResubmissionFormProps) => (
                        <PoaResubmission {...props} />
                      )}
                    />
                    <Route
                      path='*'
                      component={(props: OnlineCompanionProps) => <OnlineCompanion {...props} />}
                    />
                  </Switch>
                </Router>
              )}
            </>
          )}
        </div>
      </SbEditable>
    </>
  );
};

export default MyOnlineCompanion;
