import storyblokInstance from "@/utils/StoryblokService";
import React, { useEffect, useState } from "react";
import SbEditable from "storyblok-react";
import { GenericSBProps } from '@/components/index';
import StaticWrapperComponent, { StaticSectionProps } from "@/components/general/StaticWrapper";
import { getSlugname } from "@/utils/Utils";
import { StoryStaticType } from "@/utils/mysunrise-utils-types";

interface MobilaboUpgradeProps extends GenericSBProps { }

const MobilaboUpgrade = (props: MobilaboUpgradeProps) => {
  const { content } = props;
  const [mobilaboData, setMobilaboData] = useState<StoryStaticType | null>({
    staticSection: [],
    loadComponent: false
  });
  const params = getSlugname();
  useEffect(() => {
    (async () => {
      const response = await storyblokInstance.getPageContent(params);
      response.data.story.content.body.map((item: StoryStaticType) => {
        setMobilaboData({
          ...item,
          staticSection: item.staticSection,
          loadComponent: true
        })
      })
    })();
  }, [])
  return (
    <>
      <SbEditable content={content}>
        <div data-component="MobilaboUpgrade">
          {mobilaboData && mobilaboData.staticSection && mobilaboData.loadComponent &&
            mobilaboData.staticSection.map((staticContent: StaticSectionProps) => (
              <StaticWrapperComponent content={staticContent} />
            ))}
        </div>
      </SbEditable>
    </>
  )
}

export default MobilaboUpgrade
