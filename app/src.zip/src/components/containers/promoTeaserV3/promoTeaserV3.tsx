import React from "react";
const promoTeaserV3 = (content: any): JSX.Element => {
  return (
    <>
      {content?.content?.content?.length === 1 &&
      content?.content?.content[0].promoImage.filename === "" ? (
        <>
          <div className="s20-spacer s20-spacer--x24 is-visible-mobile"></div>
          <div className="s20-spacer s20-spacer--x40 is-hidden-mobile"></div>
          <div className="l-center-xxl l-center-sds">
          <div className="js-sameheight" data-sameheight-reset="mobile">
            {content?.content?.content.map((versionData: any) => {
              return (
                <>
                  <div className="content-teaser content-teaser--default">
                    <div className="content-teaser__content">
                      <h3 className="content-teaser__title">
                        {versionData.title}
                      </h3>
                      {versionData?.description?.content.map(
                        (descriptionData: any) => {
                          return (
                            <>
                              {descriptionData?.content.map((desc: any) => {
                                return (
                                  <div className="content-teaser__description">
                                    {desc.text}
                                  </div>
                                );
                              })}
                            </>
                          );
                        }
                      )}
                      <div className="content-teaser__button">
                        <a
                          className="s20-button"
                          href={versionData.buttonLink.url}
                        >
                          {versionData.button}
                        </a>
                      </div>
                    </div>
                  </div>
                </>
              );
            })}
          </div>
          </div>
        </>
      ) : content?.content?.content?.length === 2 &&
        content?.content?.content[0].promoImage.filename != "" ? (
        <>
          <div className="s20-spacer s20-spacer--x24 is-visible-mobile"></div>
          <div className="s20-spacer s20-spacer--x40 is-hidden-mobile"></div>
          <div className="l-center-xxl l-center-sds">
          <div className="l-grid js-sameheight" data-sameheight-reset="mobile">
            {content?.content?.content.map((versionData: any) => {
              return (
                <>
                  <div className="l-col l-1of2 l-1of1-mobile">
                    <div className="content-teaser  js-sameheight--item">
                      <div className="content-teaser__image-container content-teaser__image-container--pink">
                        <img
                          alt="Image"
                          className="content-teaser__image"
                          src={versionData.promoImage.filename}
                        />
                      </div>
                      <div className="content-teaser__content">
                        <h3 className="content-teaser__title">
                          {versionData.title}
                        </h3>
                        {versionData?.description?.content.map(
                          (descriptionData: any) => {
                            return (
                              <>
                                {descriptionData?.content.map((desc: any) => {
                                  return (
                                    <div className="content-teaser__description">
                                      {desc.text}
                                    </div>
                                  );
                                })}
                              </>
                            );
                          }
                        )}
                        <div className="content-teaser__button">
                          <a
                            className="s20-button"
                            href={versionData.buttonLink.url}
                          >
                            {versionData.button}
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              );
            })}
          </div>
          </div>
        </>
      ) : content?.content?.content?.length === 1 &&
        content?.content?.content[0].promoImage.filename != "" ? (
        <>
          {content?.content?.content.map((versionData: any) => {
            return (
              <>
                <div className="s20-spacer s20-spacer--x24 is-visible-mobile"></div>
                <div className="s20-spacer s20-spacer--x40 is-hidden-mobile"></div>
                <div className="l-center-xxl l-center-sds">
                <div className="content-teaser">
                  <div className="content-teaser__image-container content-teaser__image-container--green">
                    <img
                      alt="Image"
                      className="content-teaser__image"
                      src={versionData.promoImage.filename}
                    />
                  </div>
                  <div className="content-teaser__content">
                    <h3 className="content-teaser__title">
                      {versionData.title}
                    </h3>
                    {versionData?.description?.content.map(
                      (descriptionData: any) => {
                        return (
                          <>
                            {descriptionData?.content.map((desc: any) => {
                              return (
                                <div className="content-teaser__description">
                                  {desc.text}
                                </div>
                              );
                            })}
                          </>
                        );
                      }
                    )}
                    <div className="content-teaser__button">
                      <a
                        className="s20-button"
                        href={versionData.buttonLink.url}
                      >
                        {versionData.button}
                      </a>
                    </div>
                  </div>
                </div>
                </div>
              </>
            );
          })}
        </>
      ) : (
        ""
      )}
    </>
  );
};
export default promoTeaserV3;
