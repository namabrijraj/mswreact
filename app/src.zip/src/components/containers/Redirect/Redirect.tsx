import React, { useEffect } from "react";

interface RedirectProps  {
    url : string,
    target: string
}

const RedirectComponent =(props: RedirectProps) => {
    useEffect (() =>{
        window.open(props.url,props.target);
    },[])
    return (<div data-component="RedirectComponent"></div>)
} 

export default RedirectComponent;