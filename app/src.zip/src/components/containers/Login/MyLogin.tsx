import React, { useEffect, useState } from 'react';
import { GenericSBProps } from '@/components/index';
import SbEditable from "storyblok-react";
import Login, { LoginProps } from 'src/components/Login/Login';
import storyblokInstance from "@/utils/StoryblokService";
import StaticWrapperComponent, { StaticSectionProps } from '@/components/general/StaticWrapper';
import { getSlugname } from '@/utils/Utils';
import { StoryStaticType } from '@/utils/mysunrise-utils-types';

interface LoginFormProps extends GenericSBProps, LoginProps {}

const MyLogin = (props: LoginFormProps): JSX.Element => {
	const { content } = props;
	const [loginData, setLoginData] = useState<StoryStaticType | null>({
		staticSection: [],
		loadComponent: false
	});
	const params = getSlugname();
	useEffect(() => {
		(async () => {
			const response = await storyblokInstance.getPageContent(params);
			response.data.story.content.body.map((item: StoryStaticType) => {
				setLoginData({
						...item,
						staticSection: item.staticSection,
						loadComponent:true
					});
			});
		})();
	}, []);

	return (
		<>
			<SbEditable content={content}>
				{process.browser && loginData && loginData.loadComponent &&
					<div data-component="MyLogin" style={{ display: 'flex', flex: '1' }}>
						{loginData.staticSection &&
							loginData.staticSection.map((staticContent: StaticSectionProps) => (
								<StaticWrapperComponent content={staticContent} />
							))}
					<Login {...props} />
					</div>
				}
			</SbEditable>
		</>
	)
}

export default MyLogin;
