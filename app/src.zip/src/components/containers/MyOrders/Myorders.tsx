import React, { useEffect, useState } from 'react';
import { GenericSBProps } from '@/components/index';
import SbEditable from "storyblok-react";
import storyblokInstance from "@/utils/StoryblokService";
import { getSlugname } from '@/utils/Utils';
import { StoryStaticType } from '@/utils/mysunrise-utils-types';
import { HashRouter as Router, Route, Switch } from 'react-router-dom';
import Orders, { OrderProps } from './Orders';
import OnlineCompanion, { OnlineCompanionProps } from '@/src-components/OnlineCompanion/OnlineCompanion';
import HardwareSelection, { HardwareSelectionProps } from '@/src-components/OnlineCompanion/InstallationGuide/HardwareSelection';
import InstallationStepsView, { InstallationStepsViewProps } from '@/src-components/OnlineCompanion/InstallationGuide/InstallationSteps/InstallationStepsView';
import OtoIdStepsView, { OtoIdStepsViewProps } from '@/src-components/OnlineCompanion/OtoIdSteps/OtoIdStepsView';
import PoaResubmission, { PoaResubmissionFormProps } from '@/src-components/OnlineCompanion/PoaResubmission/PoaResubmission';
import PreparationStepsView, { PreparationStepsViewProps } from '@/src-components/OnlineCompanion/InstallationGuide/PreparationStepsView';


interface MyOrderProps extends GenericSBProps {
}

const MyOrders = (props: MyOrderProps): JSX.Element => {
	const { content } = props;
	const [myOrdersData, setMyOrdersData] = useState<StoryStaticType | null>({
		staticSection: [],
		loadComponent: false
	});
	const params = getSlugname();
	useEffect(() => {
		(async () => {
			const response = await storyblokInstance.getPageContent(params);
			response.data.story.content.body.map((item: StoryStaticType) => {
				setMyOrdersData({
					...item,
					staticSection: item.staticSection,
					loadComponent: true
				});
			});
		})();
	}, []);

	return (
		<>
			<SbEditable content={content}>
				<div data-component="Myorders">
					{myOrdersData && myOrdersData.loadComponent &&
						<>
						<Router>
								<Switch>
									<Route
										exact
										path='/'
										component={(props: OrderProps) => (
											<Orders {...props} />
										)}
									/>
									<Route
										exact
										path='/ScannedData'
										component={(props: OrderProps) => (
											<Orders {...props} />
										)}
									/>
									<Route
										exact
										path={'/:orderId'}
										component={(props: OnlineCompanionProps) => (
											<OnlineCompanion {...props} />
										)}
									/>
									<Route
										exact
										path='/OnlineCompanion'
										component={(props: OnlineCompanionProps) => (
											<OnlineCompanion {...props} />
										)}
									/>
									<Route
										exact
										path='/HardwareSelection'
										component={(props: HardwareSelectionProps) => (
											<HardwareSelection {...props} />
										)}
									/>
									<Route
										exact
										path='/InstallationStepsView'
										component={(props: InstallationStepsViewProps) => (
											<InstallationStepsView {...props} />
										)}
									/>
									<Route
										exact
										path='/OtoIdStep'
										component={(props: OtoIdStepsViewProps) => (
											<OtoIdStepsView {...props} />
										)}
									/>
									<Route
										exact
										path='/PreparationStepsView'
										component={(props: PreparationStepsViewProps) => (
											<PreparationStepsView {...props} />
										)}
									/>
									<Route
										exact
										path='/PoaResubmissionForm'
										component={(props: PoaResubmissionFormProps) => (
											<PoaResubmission {...props} />
										)}
									/>
								</Switch>
							</Router>
						</>}
				</div>
			</SbEditable>
		</>
	)
}

export default MyOrders
