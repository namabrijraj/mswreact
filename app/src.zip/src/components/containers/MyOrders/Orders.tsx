import React from 'react';
import MyNotifications, { MyNotificationsProps } from '@/src-containers/Overview/MyNotifications/MyNotifications';
import { GenericSBProps } from '@/components/index';
import MyOrderList from '@/src-components/MyOrderList/MyOrderList';

export interface OrderProps extends GenericSBProps, MyNotificationsProps {
    MyNotification: OrderProps,
}

const Orders = (props: OrderProps): JSX.Element => {
    return (
        <React.Fragment>
            <div data-component='Myorders'>
                <div className='s20-spacer s20-spacer--x40 is-hidden-mobile'></div>
                <div className='s20-spacer s20-spacer--x20 is-visible-mobile'></div>
                <MyOrderList {...props} />
                <div className='s20-spacer s20-spacer--x64 is-hidden-mobile'></div>
                <div className='s20-spacer s20-spacer--x40 is-visible-mobile'></div>
                <MyNotifications {...props} />
            </div>
        </React.Fragment>
    )
}

export default Orders;