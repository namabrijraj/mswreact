import React, { useEffect, useState } from "react";
import { HashRouter as Router, Route, Switch } from "react-router-dom";
import HomeSecurity, { HomeSecurityProps } from "@/src-containers/HomeSecurity/HomeSecurity";
import SbEditable from "storyblok-react";
import { GenericSBProps } from "@/components/index";
import storyblokInstance from "@/utils/StoryblokService";
import { getSlugname } from "@/utils/Utils";

interface HomeSecurityCheckoutProps extends GenericSBProps { }

interface HomeSecurityCheckoutConfigProps {
  dataPrivacyText: string;
  order_confirmation_image: string;
  allowed_zip_code: string;
  monthly_price: number;
  monthly_price_one_sensor: number;
  monthly_price_two_sensor: number;
  url_agbs: string;
  url_landing_page: string;
}

interface HomeSecurityCheckoutDataType {
  securityProps?: HomeSecurityCheckoutConfigProps,
  loadComponent: boolean
}

const MySunriseHomeSecurityCheckout = (dataProps: HomeSecurityCheckoutProps): JSX.Element => {
  const { content } = dataProps;
  const params = getSlugname();
  const [securityData, setSecurityData] = useState<HomeSecurityCheckoutDataType>({
    loadComponent: false
  });
  useEffect(() => {
    (async () => {
      const response = await storyblokInstance.getPageContent(params);
      response.data.story.content.body.map((itemObj: any) => {
        
        setSecurityData({
          ...itemObj,
          securityProps: {
            allowed_zip_code: itemObj.allowed_zip_code,
            monthly_price: itemObj.monthly_price,
            monthly_price_one_sensor: itemObj.monthly_price_one_sensor,
            monthly_price_two_sensor: itemObj.monthly_price_two_sensor,
            order_confirmation_image: itemObj.order_confirmation_image && itemObj.order_confirmation_image.filename,
            url_agbs: itemObj.url_agbs && itemObj.url_agbs.url,
            url_landing_page: itemObj.url_landing_page && itemObj.url_landing_page.url
          },
          loadComponent: true
        });
      });
    })();
  }, []);

  return (
    <>
      <SbEditable content={content}>
        <div data-component="HomeSecurityCheckout">
          {process.browser && securityData.loadComponent && (
            <>
              <Router>
                <Switch>
                  <Route
                    exact
                    path="/"
                    component={(props: HomeSecurityProps) => (
                      <HomeSecurity {...props} {...securityData.securityProps} />
                    )}
                  />
                  <Route
                    path="*"
                    component={(props: HomeSecurityProps) => (
                      <HomeSecurity {...props} {...securityData.securityProps} />
                    )}
                  />
                </Switch>
              </Router>
              <div className="s20-spacer s20-spacer--x60"></div>
            </>
          )}
        </div>
      </SbEditable>
    </>
  );
};

export default MySunriseHomeSecurityCheckout;
