import React, { useState } from 'react';
import { DataLayerConstants } from 'src/utils/DataLayer/DataLayerConstants';
import { DataLayerGtmConstants } from 'src/utils/DataLayer/DataLayerGtmConstants';
import DataLayerService from 'src/utils/DataLayer/DataLayerService';

const topDealsWrapper = (content: any): JSX.Element => {
  const [showStatements, setOffer] = useState('all');
  const clickEvent = (button: any) => {
    setOffer(button.value);
    DataLayerService.addEventData(
      [
        {
          eventName: DataLayerConstants.event.TOP_DEAL,
          eventType: DataLayerConstants.event.CLICK,
          eventValue: `${button.value}`,
        },
      ],
      true
    );
  };
  const clickOffer = (offercard: any, button: any) => {
    offercard?.title.map((text: any) => {
      DataLayerService.addEventData(
        [
          {
            eventName: DataLayerConstants.event.TOP_DEAL_OFFER,
            eventType: DataLayerConstants.event.CLICK,
            eventValue: `${text.text}|${button.buttonLabel}`,
            gtmInfo: { event_name: DataLayerGtmConstants.event.SELECT_PROMOTION, banner_promotion_name: text && text.text, affiliation: DataLayerGtmConstants.cart.AFFILIATION }
          },
        ],
        true
      );
      window.location.href = button.buttonLink.cached_url;
    });
  };
  return (
    <>
      <div className='s20-section-title s20-section-title--full-width s20-section-title--large'>
        <p className='s20-section-title__description'>{content.content.text}</p>
      </div>
      <div className='s20-spacer s20-spacer--x32'></div>
      <div className='alternative-selector alternative-selector--center'>
        {content?.content?.button.map((button: any, index: any) => {
          return (
            <>
              {index == 0 ? (
                <input
                  className='alternative-selector__input'
                  id={index}
                  name='selector'
                  type='radio'
                  onClick={() => clickEvent(button)}
                  value='valueOfSelector'
                  defaultChecked
                />
              ) : (
                <input
                  className='alternative-selector__input'
                  id={index}
                  name='selector'
                  type='radio'
                  onClick={() => clickEvent(button)}
                  value='valueOfSelector'
                />
              )}
              <label className='alternative-selector__label' htmlFor={index}>
                {button.label}
              </label>
            </>
          );
        })}
      </div>

      <div className='s20-spacer s20-spacer--x32'></div>
      <div className='l-center-xxl l-center-sds'>
        <div className='l-teaserrow l-teaserrow--masonry has-3'>
          {content?.content?.cards.map((cards: any) => {
            return (
              <>
                {cards?.offerCard.map((offercard: any) => {
                  return (
                    <>
                      {offercard?.offersDeals.map((deals: any) => {
                        return (
                          <>
                            {deals === showStatements ? (
                              <div className='l-teaserrow--item'>
                                <div>
                                  <div className='deal-card'>
                                    <div className='deal-card__box'>
                                      <div className='deal-card__media'>
                                        <div className='deal-card__media-placeholder'></div>
                                        <img
                                          alt='TV deals'
                                          className='deal-card__media-img'
                                          src={offercard.image.filename}
                                        />
                                      </div>
                                      <div className='deal-card__content'>
                                        <div className='deal-card__icons'>
                                          <div className='deal-card__icons-content'>
                                            {offercard?.offerIcons.map(
                                              (offerIcon: any) => {
                                                return (
                                                  <>
                                                    {offerIcon ===
                                                    DataLayerConstants.event
                                                      .TOPDEAL_MOBILE ? (
                                                      <div className='deal-card__icons-item'>
                                                        <div className='deal-card__icons-img deal-card__icons-img--mobile'></div>
                                                      </div>
                                                    ) : offerIcon ===
                                                      DataLayerConstants.event
                                                        .TOPDEAL_DEVICE ? (
                                                      <div className='deal-card__icons-item'>
                                                        <div className='deal-card__icons-img deal-card__icons-img--device'></div>
                                                      </div>
                                                    ) : offerIcon ===
                                                      DataLayerConstants.event
                                                        .TOPDEAL_INTERNET ? (
                                                      <div className='deal-card__icons-item'>
                                                        <div className='deal-card__icons-img deal-card__icons-img--internet'></div>
                                                      </div>
                                                    ) : offerIcon ===
                                                      DataLayerConstants.event
                                                        .TOPDEAL_TV ? (
                                                      <div className='deal-card__icons-item'>
                                                        <div className='deal-card__icons-img deal-card__icons-img--tv'></div>
                                                      </div>
                                                    ) : offerIcon ===
                                                      DataLayerConstants.event
                                                        .TOPDEAL_ALL ? (
                                                      <div className='deal-card__icons-item'>
                                                        <div
                                                          className={`${'deal-card__icons-img deal-card__icons-img--tv'}${'deal-card__icons-img deal-card__icons-img--internet'}${'deal-card__icons-img deal-card__icons-img--device'}${'deal-card__icons-img deal-card__icons-img--mobile'}`}
                                                        >
                                                          '
                                                        </div>
                                                      </div>
                                                    ) : (
                                                      ''
                                                    )}
                                                  </>
                                                );
                                              }
                                            )}
                                          </div>
                                        </div>
                                        {offercard?.title.map((title: any) => {
                                          return (
                                            <>
                                              <h3 className='deal-card__title'>
                                                <span className='deal-card__title-label'>
                                                  {title.text}
                                                </span>
                                              </h3>
                                            </>
                                          );
                                        })}
                                        {offercard?.description.map(
                                          (desc: any) => {
                                            return (
                                              <>
                                                {desc?.text?.content.map(
                                                  (content: any) => {
                                                    return (
                                                      <>
                                                        {content?.content.map(
                                                          (content: any) => {
                                                            return (
                                                              <>
                                                                <div className='deal-card__description'>
                                                                  <p>
                                                                    {
                                                                      content.text
                                                                    }
                                                                  </p>
                                                                </div>
                                                              </>
                                                            );
                                                          }
                                                        )}
                                                      </>
                                                    );
                                                  }
                                                )}
                                              </>
                                            );
                                          }
                                        )}
                                        <ul className='deal-card__features'>
                                          {offercard?.offersList.map(
                                            (offersList: any) => {
                                              return (
                                                <>
                                                  <li className='deal-card__features-item'>
                                                    <div className='deal-card__features-media'>
                                                      <i
                                                        className={`${
                                                          offersList.icon ===
                                                          DataLayerConstants
                                                            .event
                                                            .TOPDEAL_GIFT_iCON
                                                            ? 'deal-card__features-img deal-card__features-img--gift'
                                                            : offersList.icon ===
                                                              DataLayerConstants
                                                                .event
                                                                .TOPDEAL_NOTE_iCON
                                                            ? 'deal-card__features-img deal-card__features-img--note'
                                                            : offersList.icon ===
                                                              DataLayerConstants
                                                                .event
                                                                .TOPDEAL_DISCOUNT_iCON
                                                            ? 'deal-card__features-img deal-card__features-img--discount'
                                                            : offersList.icon ===
                                                              DataLayerConstants
                                                                .event
                                                                .TOPDEAL_ARROW_iCON
                                                            ? 'deal-card__features-img deal-card__features-img--arrow'
                                                            : ''
                                                        }`}
                                                      ></i>
                                                    </div>
                                                    {offersList?.text?.content.map(
                                                      (content: any) => {
                                                        return (
                                                          <>
                                                            <div className='deal-card__features-content'>
                                                              {content?.content.map(
                                                                (
                                                                  content: any
                                                                ) => {
                                                                  return (
                                                                    <>
                                                                      {content.marks ===
                                                                      undefined
                                                                        ? content.text
                                                                        : content?.marks.map(
                                                                            (
                                                                              marks: any
                                                                            ) => {
                                                                              return (
                                                                                <>
                                                                                  {marks.type ===
                                                                                  'bold' ? (
                                                                                    <strong>
                                                                                      {
                                                                                        content.text
                                                                                      }
                                                                                    </strong>
                                                                                  ) : (
                                                                                    <>
                                                                                      {
                                                                                        content.text
                                                                                      }
                                                                                    </>
                                                                                  )}
                                                                                </>
                                                                              );
                                                                            }
                                                                          )}
                                                                    </>
                                                                  );
                                                                }
                                                              )}
                                                            </div>
                                                          </>
                                                        );
                                                      }
                                                    )}
                                                  </li>
                                                </>
                                              );
                                            }
                                          )}
                                        </ul>

                                        {offercard?.button.map(
                                          (button: any) => {
                                            return (
                                              <>
                                                <div className='deal-card__button'>
                                                  <a
                                                    className='s20-button'
                                                    onClick={() => {
                                                      clickOffer(
                                                        offercard,
                                                        button
                                                      );
                                                    }}
                                                  >
                                                    {button.buttonLabel}
                                                    <span className='s20-button__icon s20-button__icon--after'>
                                                      <i className='s20-icon icon-fds--standard-arrow-right-white'></i>
                                                    </span>
                                                  </a>
                                                </div>
                                              </>
                                            );
                                          }
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            ) : (
                              ''
                            )}
                          </>
                        );
                      })}
                    </>
                  );
                })}
              </>
            );
          })}
        </div>
      </div>
    </>
  );
};

export default topDealsWrapper;
