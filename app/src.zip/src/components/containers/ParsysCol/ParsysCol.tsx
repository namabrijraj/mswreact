import React, { useEffect, useState } from "react";
import DynamicComponent, { GenericSBProps } from "@/components/index";
import SbEditable from 'storyblok-react'
import { Asset, MultiLink } from "@/utils/storyblok-types";
import { DataLayerConstants } from "src/utils/DataLayer/DataLayerConstants";
import DataLayerService from "src/utils/DataLayer/DataLayerService";

interface ParsysColProp extends GenericSBProps {
	size: string,
	gridContainer: GridTeaserContainerProps
}

interface GridTeaserContainerProps {
	gridTeaserContainer: GridStandardTeaser[]
}

interface GridStandardTeaser extends GenericSBProps {
	icon: Asset,
	text: string,
	title: string,
	target: string,
	linkPath: MultiLink,
	tutorialId: string,
	callToAction: string
}

const ParsysCol = (props: ParsysColProp): JSX.Element => {
	let { content } = props;
	const [gridTeaser, setGridTeaser] = useState<GridTeaserContainerProps | null>(null);
	useEffect(() => {
		DataLayerService.addEventData(
			[
			  {
				eventName: DataLayerConstants.event.ADD_NEW_PRODUCT,
				eventType: DataLayerConstants.event.VIEW,
				eventValue: DataLayerConstants.event.EVENT_DEFAULT_VALUE,
			  },
			],
			true
		  );
		content && content.gridContainer.map((item: GridTeaserContainerProps) => {
			setGridTeaser(item);
		})
	}, [])
	return (
		<>
			<SbEditable content={props.content}>
				<div data-component="ParsysCol" className={`l-center-l ${content.size == 'large' ? '' : 'l-center-l--extra-wide'}`}>
					<div className="l-grid mb-48-imp">
						<div className={`l-flexbox-row l-flexbox-row--centered l-flexbox-row--wrap`}>

							{gridTeaser &&
								gridTeaser.gridTeaserContainer.map((teaserContent: GridStandardTeaser) => (
									<> {content.size !== 'large' ? <div className={`${content.size !== 'large' ? "l-col-flexbox l-col-flexbox-1_4 l-col-flexbox-1_3--middle l-col-flexbox-even--small l-col-flexbox--min-width-280px width-100perc--mobile" : ''}`} >

										<DynamicComponent content={teaserContent} />
									</div> : <DynamicComponent content={teaserContent} />}
									</>
								))
							}
						</div>
					</div>
				</div>
				<div className={`vertical_spacer ${content.size == 'large' ? 'x48' : 'x32'}`}></div>
			</SbEditable>
		</>
	)
}
export default ParsysCol