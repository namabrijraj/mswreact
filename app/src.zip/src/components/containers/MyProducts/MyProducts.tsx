import StaticWrapperComponent, {
  StaticSectionProps,
} from "@/components/general/StaticWrapper";
import storyblokInstance from "@/utils/StoryblokService";
import { getSlugname } from "@/utils/Utils";
import React, { useEffect, useState } from "react";
import { HashRouter as Router, Route, Switch } from "react-router-dom";
import MobileMigrations, {
  MobileMigrationsProps,
} from "@/src-components/MobileMigration/MobileMigration";
import RetentionProductDetail, {
  RetentionProductDetailProps,
} from "@/src-components/Retention/RetentionProductDetail/RetentionProductDetail";
import SecurityStatistics, {
  SecurityStatisticsProps,
} from "@/src-components/SecurityStatistics/SecurityStatistics";
import WireLineMigration, {
  WireLineMigrationProps,
} from "@/src-containers/Subscription/SubscriptionTabs/Contract/WireLineMigration/WireLineMigration";
import ExtraSim, {
  ExtraSimProps,
} from "@/src-containers/Subscription/SubscriptionTabs/Sim/ExtraSim/ExtraSim";
import { SimRoutes } from "@/src-containers/Subscription/SubscriptionTabs/Sim/SimRoutes.enum";
import AddSubscription, {
  AddSubscriptionProps,
} from "@/src-containers/Subscriptions/AddSubscription/AddSubscription";
import EditSiteLevelOption, {
  EditSiteLevelOptionProps,
} from "@/src-containers/Subscriptions/SiteLevelOptions/EditSiteLevelOption/EditSiteLevelOption";
import Subscriptions, {
  SubscriptionsProps,
} from "@/src-containers/Subscriptions/Subscriptions";
import { SubscriptionsRoutes } from "@/src-containers/Subscriptions/SubscriptionsRoutes";
import SbEditable from "storyblok-react";
import { GenericSBProps } from "@/components/index";
import dynamic from "next/dynamic";
import { StoryStaticType } from "@/utils/mysunrise-utils-types";
import  EofActivation, { EofActivationProps } from "@/src-containers/Subscriptions/EofOverviewDashboard/EofActivation/EofActivation";
import EmployeeOfFirmProgram, { EmployeeOfFirmProgramProps } from "@/src-containers/Subscriptions/EofOverviewDashboard/EmployeeOfFirmProgram/EmployeeOfFirmProgram";
import ManageSIMCard, { ManageSIMCardProps } from "@/src-containers/Subscriptions/ManageSIMCard/ManageSIMCard";
import SafeSecurityOption, { SafeSecurityOptionProps } from "@/src-containers/Subscriptions/SiteLevelOptions/SafeSecurityOption/SafeSecurityOption";
import OttMigration, { OttMigrationProps } from "@/src-containers/Subscription/SubscriptionTabs/Contract/OttMigration/OttMigration";

const ESimQr = dynamic(
  () => import('@/src-containers/Subscription/SubscriptionTabs/Sim/ESimQr/ESimQr'),
  {
    ssr: false,
  }
);

interface MyProductsProps extends GenericSBProps, RetentionProductDetailProps, WireLineMigrationProps,
  ExtraSimProps, SubscriptionsProps {}

interface ProductPropTypes {
  addNewSubscriptionPage: string;
  imgPrepaidOverview: string;
  imgFeatureProduct: string;
  imgOrderEmptyRatePlan: string;
  addTvPage: string;
  addDevicePage: string;
  imgScanApp: string;
  imgForNoTv: string;
  salesPage: string;
  bannerImage:string;
  mobileSalesBanner:string;
  recommendSunriseLink:string;
  enableSalesTeaser: boolean;
  imgPreSales: string;
  hideNoSurfMsg: boolean;
}

const MyProducts = (dataProps: MyProductsProps): JSX.Element => {
  const { content } = dataProps;
  const [myProductsData, setMyProductsData] = useState<StoryStaticType | null>({
    staticSection: [],
    loadComponent: false
  });
  const [productProps, setProductProps] = useState<ProductPropTypes | null>(
    null
  );
  const params = getSlugname();
  useEffect(() => {
    setProductProps({
      addNewSubscriptionPage:
        dataProps.pageConfig.addNewSubscriptionPage.cached_url,
      imgPrepaidOverview: dataProps.pageConfig.prepaidOverviewImage.filename,
      imgFeatureProduct: dataProps.pageConfig.featureProductImage.filename,
      imgOrderEmptyRatePlan:
        dataProps.pageConfig.orderemptyrateplanimage.filename,
      addTvPage: dataProps.pageConfig.addTvPage.cached_url,
      addDevicePage: dataProps.pageConfig.addDevicePage.cached_url,
      imgScanApp: dataProps.pageConfig.imageScanApp.filename,
      imgForNoTv: dataProps.pageConfig.imageForNotTv.filename,
      salesPage: dataProps.pageConfig.salesPage.cached_url,
      bannerImage:dataProps.pageConfig.bannerImage?.filename,
      mobileSalesBanner:dataProps.pageConfig.mobileSalesBanner?.filename,
      recommendSunriseLink:dataProps.pageConfig.recommendSunriseLink?.cached_url,
      enableSalesTeaser: dataProps.pageConfig.enableSalesTeaser,
      imgPreSales: dataProps.pageConfig.salesImage.filename,
      hideNoSurfMsg: dataProps.pageConfig.hideNoSurfMsg
    });
    (async () => {
      const response = await storyblokInstance.getPageContent(params);
      response.data.story.content.body.map((item: StoryStaticType) => {
        setMyProductsData({
          ...item,
          staticSection: item.staticSection,
          loadComponent: true,
        });
      });
    })();
  }, []);

  return (
    <>
      <SbEditable content={content}>
        <div data-component="MyProducts">
          {process.browser && myProductsData && myProductsData.loadComponent && (
            <>
              <Router>
                <Switch>
                  <Route
                    exact
                    path={SubscriptionsRoutes.LEGACY_MIGRATION}
                    component={(props: MobileMigrationsProps) => (
                      <MobileMigrations {...props} {...productProps} />
                    )}
                  />
                  <Route
                    exact
                    path={SubscriptionsRoutes.PACK_MIGRATION}
                    component={(props: MobileMigrationsProps) => (
                      <MobileMigrations {...props} {...productProps} />
                    )}
                  />
                  <Route
                    exact
                    path={`/${SimRoutes.EXTRA_SIM}`}
                    component={(props: ExtraSimProps) => (
                      <ExtraSim {...props} {...productProps} />
                    )}
                  />
                  <Route
                    exact
                    path="/SecurityStatistics"
                    component={(props: SecurityStatisticsProps) => (
                      <SecurityStatistics {...props} {...productProps} />
                    )}
                  />
                  <Route
                    exact
                    path={SubscriptionsRoutes.SUBSCRIPTIONS}
                    component={(props: SubscriptionsProps) => (
                      <Subscriptions {...props} {...productProps} />
                    )}
                  />
                   <Route
                    exact
                    path={SubscriptionsRoutes.EOF_POPUP + '/:serviceId/:status' }
                    component={(props: SubscriptionsProps) => (
                      <Subscriptions {...props} {...productProps} />
                    )}
                  />
                  <Route
                    exact
                    path={SubscriptionsRoutes.EDIT_SITE_OPTIONS + "/:category"}
                    component={(props: EditSiteLevelOptionProps) => (
                      <EditSiteLevelOption {...props} {...productProps} />
                    )}
                  />
                  <Route
                    exact
                    path={SubscriptionsRoutes.EDIT_SAFE_OPTIONS + "/:category"}
                    component={(props: SafeSecurityOptionProps) => (
                      <SafeSecurityOption {...props} {...productProps} />
                    )}
                  />
                  <Route
                    exact
                    path={SubscriptionsRoutes.EOF_ACTIVATION + "/:serviceId/:status"}
                    component={(props: EofActivationProps) => (
                      <EofActivation {...props} {...productProps} />
                    )}
                  />
                  <Route
                    exact
                    path={SubscriptionsRoutes.EOF_PROGRAM}
                    component={(props: EmployeeOfFirmProgramProps) => (
                      <EmployeeOfFirmProgram {...props} {...productProps} />
                    )}
                  />
                  <Route
                    exact
                    path="/RetentionProducts"
                    component={(props: RetentionProductDetailProps) => (
                      <RetentionProductDetail {...props} {...productProps} />
                    )}
                  />
                  <Route
                    exact
                    path="/:serviceId/WireLineMigration"
                    component={(props: WireLineMigrationProps) => (
                      <WireLineMigration {...props} {...productProps} />
                    )}
                  />
                  <Route
                    exact
                    path="/:serviceId/SwitchSubscription/OttMigration/update"
                    component={(props: OttMigrationProps) => (
                      <OttMigration {...props} {...productProps} />
                    )}
                  />
                  <Route
                    exact
                    path={
                      SubscriptionsRoutes.ADD_SUBSCRIPTION + "/:ratePlanName"
                    }
                    component={(props: AddSubscriptionProps) => (
                      <AddSubscription {...props} {...productProps} />
                    )}
                  />
                  <Route
                    exact
                    path='/manageSIMCard'
                    component={(props: ManageSIMCardProps) => (
                      <ManageSIMCard {...props} {...productProps} />
                    )}
                  />
                  <Route
                    exact
                    path='/:serviceId/:ratePlanName/sim-qr-code'
                    component={ESimQr}
                />
                  <Route
                    path="*"
                    component={(props: SubscriptionsProps) => (
                      <Subscriptions {...props} {...productProps} />
                    )}
                  />
                </Switch>
              </Router>

              {myProductsData.staticSection &&
                myProductsData.staticSection.map(
                  (staticContent: StaticSectionProps) => (
                    <StaticWrapperComponent content={staticContent} />
                  )
                )}
            </>
          )}
        </div>
      </SbEditable>
    </>
  );
};
export default MyProducts;
