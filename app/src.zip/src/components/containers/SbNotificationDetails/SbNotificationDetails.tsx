import React from 'react'
import { GenericSBProps } from '@/components/index'
import NotificationDetail, { NotificationDetailProps } from '@/src-containers/Header/Notification/NotificationDetail/NotificationDetail';
import SbEditable from 'storyblok-react';

interface SbNotificationDetailsProps extends GenericSBProps, NotificationDetailProps {}

const SbNotificationDetails = (props: SbNotificationDetailsProps) => {
  const { content } = props
  return (
    <>
    <SbEditable content={content}>
				<div data-component="SbNotificationDetails">
					<NotificationDetail {...props} />
				</div>
			</SbEditable>
    </>
  )
};

export default SbNotificationDetails;
