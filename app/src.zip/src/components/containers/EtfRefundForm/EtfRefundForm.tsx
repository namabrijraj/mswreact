import React from 'react';
import { GenericSBProps } from '@/components/index';
import EtfRefund, { EtfRefundProps } from '@/src-containers/Overview/EtfRefund/EtfRefund';
import SbEditable from 'storyblok-react';

interface EtfRefundFormProps extends GenericSBProps, EtfRefundProps {}

const EtfRefundForm = (props: EtfRefundFormProps): JSX.Element => {
	const { content } = props;

	return (
		<>
			<SbEditable content={content}>
				<div data-component="EtfRefundForm">
				<EtfRefund {...props} />
				</div>
			</SbEditable>
		</>
	)
}

export default EtfRefundForm
