import React, { useEffect, useState } from "react";
import { GenericSBProps } from "@/components/index";
import SbEditable from "storyblok-react";
import SmsSender, {
  SmsSenderProps,
} from "@/src-containers/Overview/SmsSender/SmsSender";

interface PropsSmsSender extends GenericSBProps, SmsSenderProps {}

const SbMySmsSender = (props: PropsSmsSender): JSX.Element => {
  const { content } = props;
  const [smsSenderPlaceholderPage, setSmsSenderPlaceholderPage] = useState<string>('');
  useEffect(() => {
    setSmsSenderPlaceholderPage(
      props.pageConfig.smsSenderPlaceholderPage.cached_url
    );
  }, []);

  return (
    <>
      <SbEditable content={content}>
        <div data-component="SmsSender">
          <SmsSender {...{ ...props, smsSenderPlaceholderPage }} />
        </div>
      </SbEditable>
    </>
  );
};

export default SbMySmsSender;
