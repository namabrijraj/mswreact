import React, { useEffect, useState } from 'react';
import SbEditable from 'storyblok-react';
import { GenericSBProps } from '@/components/index';
import { StoryStaticType } from '@/utils/mysunrise-utils-types';
import { getSlugname } from '@/utils/Utils';
import storyblokInstance from '@/utils/StoryblokService';
import StaticWrapperComponent, { StaticSectionProps } from '@/components/general/StaticWrapper';

interface TestTeaserProps extends GenericSBProps { }

const TestTeaser = (props: TestTeaserProps): JSX.Element => {
  const { content } = props;
  const [testTeaserData, setTestTeaserData] = useState<StoryStaticType | null>({
    staticSection: [],
    loadComponent: false
  })
  const params = getSlugname();

  useEffect(() => {
    (async () => {
      const response = await storyblokInstance.getPageContent(params);
      response.data.story.content.body.map((item: StoryStaticType) => {
        setTestTeaserData({
          ...item,
          staticSection: item.staticSection,
          loadComponent: true
        })
      })
    })();
  }, [])


  return (
    <>
    <SbEditable content={content}>
        <div data-component="Test Teaser">
          {testTeaserData && testTeaserData.staticSection && testTeaserData.loadComponent &&
            testTeaserData.staticSection.map((staticContent: StaticSectionProps) => (
              <StaticWrapperComponent content={staticContent} />
            ))}
        </div>
      </SbEditable>
    </>
  )
}

export default TestTeaser
