import React, { useEffect, useState } from "react";
import { GenericSBProps } from "@/components/index";
import Prepaid, {
  PrepaidProps,
} from "@/src-containers/Overview/Prepaid/Prepaid";
import SbEditable from "storyblok-react";
import storyblokInstance from "@/utils/StoryblokService";
import { Route, HashRouter as Router, Switch } from "react-router-dom";
import Topup, {
  TopupProps,
} from "@/src-containers/Overview/Prepaid/Topup/Topup";
import { getSlugname } from "@/utils/Utils";

interface PrepaidOverview extends GenericSBProps, PrepaidProps, TopupProps {
  field: string;
}

interface PrepaidOverviewProps {
  thresholdLimitOptions: string;
  thresholdAmountOptions: string;
  addNewSubscriptionPage: string;
  loadComponent: boolean;
}

interface PrepaidPropTypes {
  thresholdLimit: PrepaidOverview[];
  thresholdAmount: PrepaidOverview[];
}

const PrepaidOverview = (props: PrepaidOverview): JSX.Element => {
  const { content } = props;
  const [prepaidOverviewData, setPrepaidOverviewData] = useState<PrepaidOverviewProps | null>(null);
  let newProductUrl: string = ''
  const params = getSlugname();
  useEffect(() => {
    newProductUrl = props.pageConfig && props.pageConfig.addNewSubscriptionPage.cached_url;
    (async () => {
      const response = await storyblokInstance.getPageContent(params);
      response.data.story.content.body.map((item: PrepaidPropTypes) => {
        let ThresholdLimit: string = "";
        let ThresholdAmount: string = "";
        item.thresholdLimit.forEach((value: PrepaidOverview) => {
          ThresholdLimit = ThresholdLimit.concat(value.field + ",");
        });
        item.thresholdAmount.forEach((value: PrepaidOverview) => {
          ThresholdAmount = ThresholdAmount.concat(value.field + ",");
        });
        setPrepaidOverviewData({
          ...item,
          thresholdLimitOptions: ThresholdLimit.replace(/,\s*$/, ""),
          thresholdAmountOptions: ThresholdAmount.replace(/,\s*$/, ""),
          addNewSubscriptionPage: newProductUrl,
          loadComponent: true,
        });
      });
    })();
  }, []);
  return (
    <>
      <SbEditable content={content}>
        <div data-component="PrepaidOverview">
          {process.browser && prepaidOverviewData && prepaidOverviewData.loadComponent && (
            <Router>
              <Switch>
                <Route
                  exact
                  path="/TopUpPrepaid/:serviceId"
                  component={(props: TopupProps) => (
                    <Topup {...props} {...prepaidOverviewData} />
                  )}
                />
                <Route
                  exact
                  path="/TopUpPrepaid"
                  component={(props: TopupProps) => (
                    <Topup {...props} {...prepaidOverviewData} />
                  )}
                />
                <Route
                  exact
                  path="/"
                  component={(props: PrepaidProps) => (
                    <Prepaid {...props} {...prepaidOverviewData} />
                  )}
                />
                <Route
                  path="*"
                  component={(props: PrepaidProps) => (
                    <Prepaid {...props} {...prepaidOverviewData} />
                  )}
                />
              </Switch>
            </Router>
          )}
        </div>
      </SbEditable>
    </>
  );
};

export default PrepaidOverview;
