import WebSheetSimTransfer, { WebSheetSimTransferProps } from "@/src-containers/WebSheet/WebSheetSimTransfer/WebSheetSimTransfer"
import SbEditable from "storyblok-react"
import { GenericSBProps } from "@/components/index"
import React, { useEffect, useState } from "react"
import storyblokInstance from "@/utils/StoryblokService"
import StaticWrapperComponent, { StaticSectionProps } from "@/components/general/StaticWrapper"
import { getSlugname } from "@/utils/Utils"
import { StoryStaticType } from "@/utils/mysunrise-utils-types"
import { Asset, MultiLink } from "@/utils/storyblok-types"

interface SimTransfer {
  esimToEsimImage: Asset;
  physicalToEsimImage: Asset;
  termsAndConditionsLink: MultiLink;
}

interface WebsheetSimProps extends GenericSBProps, WebSheetSimTransferProps { }

interface SimTransferContent extends StoryStaticType {
  loadComponent: boolean
}

const SbWebsheetSimTransfer = (props: WebsheetSimProps): JSX.Element => {
  const { content } = props;
  const [simTransferData, setSimTransferData] = useState<SimTransferContent | null>({
    staticSection: [],
    loadComponent: false
  });
  const [websheetProps, setWebsheetProps] = useState<any>();
  const params = getSlugname();
  useEffect(() => {
    (async () => {
      const response = await storyblokInstance.getPageContent(params);
      response.data.story.content.body.map((item: any) => {
        item.websheetSimTransfer.forEach((items: SimTransfer) => {
          setWebsheetProps({
            imgEsimToEsim: items.esimToEsimImage.filename,
            imgPhysicalToEsim: items.physicalToEsimImage.filename,
            termsAndConditions: items.termsAndConditionsLink.cached_url
          })
        })
        setSimTransferData({
          ...item,
          staticSection: item.staticSection,
          loadComponent: true
        })
      })
    })();
  }, [])
  return (
    <SbEditable content={content}>
      <div data-component="WebsheetSimTransfer">
        {simTransferData && simTransferData.loadComponent &&
          <>
            {simTransferData.staticSection && simTransferData.staticSection.map((staticContent: StaticSectionProps) => (
              <StaticWrapperComponent content={staticContent} />
            ))}
          {websheetProps &&
            <WebSheetSimTransfer {...{ ...props, ...websheetProps }} />
            }
          </>
        }
      </div>
    </SbEditable>
  )
}
export default SbWebsheetSimTransfer
