import React, { useEffect, useState } from 'react';
import SbEditable from 'storyblok-react';
import { GenericSBProps } from '@/components/index';
import StaticWrapperComponent, { StaticSectionProps } from '@/components/general/StaticWrapper';
import storyblokInstance from '@/utils/StoryblokService';
import { getSlugname } from '@/utils/Utils';
import { StoryStaticType } from '@/utils/mysunrise-utils-types';

interface MyAddNewProduct extends GenericSBProps {}

const AddNewProduct = (props: MyAddNewProduct): JSX.Element => {
  const { content } = props;
  const [newProductContent, setNewProductContent] = useState<StoryStaticType | null>({
    staticSection: [],
    loadComponent: false
  });
  const params = getSlugname();

  useEffect(() => {
    (async () => {
      const response = await storyblokInstance.getPageContent(params);
      response.data.story.content.body.map((item: StoryStaticType) => {
        setNewProductContent({
          ...item,
          staticSection: item.staticSection,
          loadComponent : true
        })
      })
    })();
  }, [])
  return (
    <>
      <SbEditable content={content}>
        <>
          {newProductContent && newProductContent.staticSection && newProductContent.loadComponent &&
            newProductContent.staticSection.map((staticContent: StaticSectionProps) => (
              <StaticWrapperComponent content={staticContent} />
            ))}
        </>
      </SbEditable>
    </>
  )
}

export default AddNewProduct;
