import React from 'react'
import { GenericSBProps } from '@/components/index';
import UploadForm, { UploadFormProps } from '@/src-containers/Overview/UploadForm/UploadForm';
import SbEditable from 'storyblok-react';

interface UploadForm extends GenericSBProps, UploadFormProps {}

const SbUploadForm = (props: UploadForm): JSX.Element => {
  const { content } = props
  return (
    <>
      <SbEditable content={content}>
        <div data-component="UploadForm">
        <UploadForm {...props} />
        </div>
      </SbEditable>
    </>
  )
}

export default SbUploadForm
