import { GenericSBProps } from "@/components/index";
import MyVouchers, { MyVouchersProps } from "@/src-containers/Overview/MyVouchers/MyVouchers";
import SbEditable from "storyblok-react";

interface MyVoucherProps extends GenericSBProps, MyVouchersProps {}

const MyVoucher = (props: MyVoucherProps): JSX.Element => {
  const { content } = props
  return (
    <>
      <SbEditable content = {content}>
        <div data-component="DiscountVouchers">
          <MyVouchers {...props} />
        </div>
      </SbEditable>
    </>
  )
}
export default MyVoucher