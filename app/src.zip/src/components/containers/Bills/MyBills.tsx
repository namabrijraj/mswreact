import * as React from 'react';
import { GenericSBProps } from '@/components/index';
import dynamic from 'next/dynamic';
import { useEffect, useState } from 'react';
import { HashRouter as Router, Route, Switch } from 'react-router-dom';
import Bills, { BillsProps } from '@/src-containers/Bills/Bills';
import { BillsPayOutstandingProps } from '@/src-containers/Bills/BillsPayOutstanding/BillsPayOutstanding';
import PartialPaymentAgreement, {
  PartialPaymentAgreementProps,
} from '@/src-containers/Bills/PartialPaymentAgreement/PartialPaymentAgreement';
import ProfileEditBillingAddress, {
  ProfileEditBillingAddressProps,
} from '@/src-containers/Profile/ProfileEditBillingAddress/ProfileEditBillingAddress';
import SbEditable from 'storyblok-react';
import { getStaticAssetPath } from '@/utils/global';
import BillsSettings, {
  BillsSettingsProps,
} from '@/src-containers/Bills/BillsSettings/BillsSettings';
import EbillRegistration, { EbillRegistrationProps } from '@/src-containers/Bills/EbillRegistration/EbillRegistration';
import TransactionStatement, { TransactionStatementProps } from '@/src-containers/Bills/TransactionStatement/TransactionStatement';
const BillsPayOutstanding = dynamic(
  () => import('@/src-containers/Bills/BillsPayOutstanding/BillsPayOutstanding'),
  {
    ssr: false,
  }
);
interface MyProps extends GenericSBProps {}

interface MyBillsConfigProps {
  imgPaid: string;
  cardIcon: string;
  gPay: string;
  twintPay: string;
  applePay: string;
  payPal: string;
  paySlip: string;
  qrBillIcon: string;
  imgEbillLogoNegative: string;
  imgPaymentThankyou: string;
  imgOverallSuccessMail: string;
  imgSwissCrossForQrcode: string;
  ebillHelpPage: string;
  ppaTerms: string;
  bbfPpaTerms: string;
  billingAssistantPage: string;
  faqList: any;
  enableBillsFaq: boolean;
  billsFaqLink: string;
  billsFaqIcon: string;
}

const MyBills = (props: MyProps): JSX.Element => {
  const { content } = props;
  const [billsData, setBillsData] = useState<MyBillsConfigProps | null>(null);

  useEffect(() => {
    const billsPageConfigData: MyBillsConfigProps = {
      imgPaid: props.pageConfig?.amountPaidImage?.filename,
      imgEbillLogoNegative: props.pageConfig?.negativeEbillLogoImage?.filename,
      imgPaymentThankyou: props.pageConfig?.paymentThankyouImage?.filename,
      imgOverallSuccessMail: props.pageConfig?.overallSuccessMailImage?.filename,
      imgSwissCrossForQrcode: getStaticAssetPath('/qrcode.png'),
      ebillHelpPage: props.pageConfig?.ebillHelpPage?.cached_url,
      ppaTerms: props.pageConfig?.ppaTermsLink?.filename,
      bbfPpaTerms: props.pageConfig?.bbfPpaTermsLink?.filename,
      billingAssistantPage: props.pageConfig?.billingAssistantPage?.cached_url,
      faqList: props.pageConfig?.faqList,
      billsFaqIcon: props.pageConfig?.billsFaqIcon?.filename,
      billsFaqLink: props.pageConfig?.billsFaqLink?.cached_url,
      enableBillsFaq: props.pageConfig?.enableBillsFaq,
      gPay: props.pageConfig?.gpayIcon?.filename,
      cardIcon: props.pageConfig?.cardIcon?.filename,
      twintPay: props.pageConfig?.twintIcon?.filename,
      payPal: props.pageConfig?.paypalIcon?.filename,
      paySlip: props.pageConfig?.payslipIcon?.filename,
      qrBillIcon: props.pageConfig?.qrBillIcon?.filename,
      applePay: props.pageConfig?.applePay?.filename
    };
  setBillsData(billsPageConfigData);
  }, []);

  return (
    <>
      <SbEditable content={content}>
        <div data-component='MyBills'>
          {process.browser && (
            <>
              <Router>
                <Switch>
                  <Route exact path='/'
                    component={(dataProps: BillsProps) => <Bills {...dataProps} {...billsData} />}
                  />
                  <Route exact path='/PaymentMethod'
                    component={(dataProps: BillsSettingsProps) => (
                      <BillsSettings {...dataProps} {...billsData} />
                    )}
                  />
                  <Route exact path='/PayOpenAmounts'
                    component={(dataProps: BillsPayOutstandingProps) => (
                      <BillsPayOutstanding {...dataProps} {...billsData} />
                    )}
                  />
                  <Route exact path='/PayOpenAmounts/:overlay'
                    component={(dataProps: BillsPayOutstandingProps) => (
                      <BillsPayOutstanding {...dataProps} {...billsData} />
                    )}
                  />
                  <Route exact path='/OverlayPartialPaymentAgreement'
                    component={(dataProps: PartialPaymentAgreementProps) => (
                      <PartialPaymentAgreement {...dataProps} {...billsData} />
                    )}
                  />
                  <Route path='/BillingAddress'
                    component={(dataProps: ProfileEditBillingAddressProps) => (
                      <ProfileEditBillingAddress {...dataProps} {...billsData} />
                    )}
                  />
                  <Route path='/BillsSettings'
                    component={(dataProps: BillsSettingsProps) => (
                      <BillsSettings {...dataProps} {...billsData} />
                    )}
                  />
                  <Route path='/EbillRegistration'
                    component={(dataProps: EbillRegistrationProps) => (
                      <EbillRegistration {...dataProps} {...billsData} />
                    )}
                  />
                  <Route path='/BillsSettings/:overlay'
                    component={(dataProps: BillsSettingsProps) => 
                      <BillsSettings {...dataProps} {...billsData} />
                    } 
                  />
                  <Route path='/TransactionStatement'
                    component={(dataProps: TransactionStatementProps) => <TransactionStatement {...dataProps}  {...billsData} />}
                  />
                  <Route path='/TransactionStatement/:overlay'
                    component={(dataProps: TransactionStatementProps) => <TransactionStatement {...dataProps}  {...billsData} />}
                  />
                  <Route path='/:overlay' exact
                    component={(dataProps: BillsProps) => <Bills {...dataProps} {...billsData} />}
                  />
                  <Route path='*'
                    component={(dataProps: BillsProps) => <Bills {...dataProps} {...billsData} />}
                  />
                </Switch>
              </Router>
            </>
          )}
        </div>
      </SbEditable>
    </>
  );
};
export default MyBills;
