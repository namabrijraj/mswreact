import React, { useEffect, useState } from 'react';
import SbEditable from 'storyblok-react';
import { GenericSBProps } from '@/components/index';
import storyblokInstance from '@/utils/StoryblokService';
import WebSheetMngAccount, { WebSheetMngAccountProps } from 'src/containers/WebSheet/WebSheetMngAccount';
import StaticWrapperComponent, { StaticSectionProps } from '@/components/general/StaticWrapper';
import { getSlugname } from '@/utils/Utils';
import { StoryStaticType } from '@/utils/mysunrise-utils-types';

interface ManageAccountProps extends GenericSBProps, WebSheetMngAccountProps {}

export interface TokenProps {
  tokenUrl: string,
  type: string
}

const WebsheetManageAccount = (props: ManageAccountProps): JSX.Element => {
  const { content } = props;
  const [manageAccountData, setManageAccountData] = useState<StoryStaticType | null>({
    staticSection: [],
    loadComponent: false
  });
  const params = getSlugname();
  const [mngactProp, setMngactProp] = useState<TokenProps | null>(null)

  useEffect(() => {
    (async () => {
      const response = await storyblokInstance.getPageContent(params);
      response.data.story.content.body.map((item: StoryStaticType) => {
          setManageAccountData({
            ...item,
            staticSection: item.staticSection,
            loadComponent: true
          });
      });
    })();
    setMngactProp({
      tokenUrl: window.location.origin + window.location.pathname,
      type: 'widget'
    })
  }, []);

  return (
    <>
      <SbEditable content={content}>
        <>
          {manageAccountData && manageAccountData.loadComponent &&
            <>
            {manageAccountData.staticSection &&
              manageAccountData.staticSection.map((staticContent: StaticSectionProps) => (
                  <StaticWrapperComponent content={staticContent} />
                ))}
              <WebSheetMngAccount {...{ ...props, ...mngactProp }} />
            </>
            }
        </>
      </SbEditable>
    </>
  )
}

export default WebsheetManageAccount;
