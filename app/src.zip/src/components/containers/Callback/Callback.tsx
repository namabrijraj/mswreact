import React from 'react';
import { GenericSBProps } from '@/components/index'
import SbEditable from "storyblok-react";
import CreateCallback, { CreateCallbackProps } from '@/src-containers/Overview/CreateCallback/CreateCallback';

interface CallbackProps extends GenericSBProps, CreateCallbackProps {}

const CallbackComp = (props: CallbackProps): JSX.Element => {
	const { content } = props
	return (
		<>
			<SbEditable content={content}>
				<div data-component="Callback">
					<CreateCallback {...props} />
				</div>
			</SbEditable>
		</>
	)
}

export default CallbackComp
