import storyblokInstance from '@/utils/StoryblokService';
import React, { useEffect, useState } from 'react';
import SbEditable from 'storyblok-react';
import { GenericSBProps } from '@/components/index';
import GenericIframe from '@/components/general/GenericIframe';
import { getSlugname } from '@/utils/Utils';
import { MultiLink } from '@/utils/storyblok-types';
import DataLayerService from '../../../../../src/utils/DataLayer/DataLayerService';
import {DataLayerConstants} from '../../../../../src/utils/DataLayer/DataLayerConstants';
import {MessageInfo} from '@/src-model/client/DataLayer/DataLayer';
import DataLayerGtmService from 'src/utils/DataLayer/DataLayerGtmService';
import { DataLayerGtmConstants } from 'src/utils/DataLayer/DataLayerGtmConstants';

interface InvoiceAssistantProps extends GenericSBProps {
  data: object;
  digitalData?: EventValueData;
}

interface EventValueData {
  eventValue: string,
  payNowBtn?: string,
  eventAction: string,
  eventType?: string,
  message?: MessageInfo
}

interface IframeType {
  height: number;
  isHeightEnabled: boolean;
  iFrameSrc: string;
}
interface IframeitemType {
  height: number;
  enableHeight: boolean;
  iFrameSrc: MultiLink;
}
interface ItemType {
  iframe: IframeitemType[];
}
export interface IframeRenderedDataProps {
  iframeProps: IframeType;
  loadcomponent: boolean;
}
interface IframePostMsgData {
  eventInfo: {
    eventAction: string,
    eventValue: string,
    timeStamp: string | Date,
    type: string,
  }
}
export interface IframePostMsg {
  digitalData: IframePostMsgData;
}
const InvoiceAssistant = (props: InvoiceAssistantProps) => {
  let { content } = props;
  let iframeData: IframeType;
  const [iframeRenderedData, setIframeRenderedData] = useState<IframeRenderedDataProps | null>(
    null
  );
  const params = getSlugname();
  function messageHandler (data: InvoiceAssistantProps) {
      const dataSet: (boolean | any) = data?.digitalData ? {...data} || {digitalData: null} : false;
      const isDataLayer: (boolean) = dataSet?.digitalData || false;
      if (isDataLayer) {
        const setEventName: string = data?.digitalData?.eventAction || '';
        const setDataValue: string = data?.digitalData?.eventValue || '';
        const setPayNowBtn: string = data?.digitalData?.payNowBtn || '';
        const setEventType: string = data?.digitalData?.eventType || DataLayerConstants.event.CLICK;
        const setDataMsg: MessageInfo | undefined  = data?.digitalData?.message;
        DataLayerService.addEventData([{ eventName: setEventName, eventType: setEventType, eventValue: setDataValue || '', gtmInfo: DataLayerGtmService.DataLayerFnBillingAssistance(setEventName, setDataValue, setPayNowBtn) }], true);
      if (setDataMsg) {
        DataLayerService.addMessageData(setDataMsg, true)
      }
        if (setDataValue && setDataValue.indexOf(DataLayerGtmConstants.bill.DOWNLOAD_PDF) > -1) {
          DataLayerGtmService.addGtmDataLayer('', { event: DataLayerGtmConstants.event.GA_EVENT, event_name: DataLayerGtmConstants.event.ctaClick.CTA_TEXT_CLICK, link_url: '#', click_text: setEventName, headline: setDataValue });
        }
      }
  }
  useEffect(() => {
    (async () => {
      const response = await storyblokInstance.getPageContent(params);
      response.data.story.content.body.map((item: ItemType) => {
        item.iframe &&
          item.iframe.map((iframeItem: IframeitemType) => {
            iframeData = {
              height: iframeItem.height,
              isHeightEnabled: iframeItem.enableHeight,
              iFrameSrc: window.ReactApp.Env.invoiceAssistantAppUrl,
            };
          });
        setIframeRenderedData({
          iframeProps: iframeData,
          loadcomponent: true,
        });
      });
    })();
  }, []);
  useEffect(() => {
    window.addEventListener('message', function (e){
      messageHandler(e.data);
    });

    return () => {
      removeEventListener('message', function (){
        messageHandler
      })
    }
  }, [])
  return (
    <>
      <SbEditable content={content}>
        <div data-component='InvoiceAssistant'>
          {iframeRenderedData && iframeRenderedData.loadcomponent && (
            <GenericIframe { ...iframeRenderedData } />
          )}
        </div>
      </SbEditable>
    </>
  );
};
export default InvoiceAssistant;
