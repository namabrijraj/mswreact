import { GenericSBProps } from "@/components/index";
import SbEditable from "storyblok-react"
import React, { useEffect, useState } from "react";
import storyblokInstance from "@/utils/StoryblokService";
import StaticWrapperComponent, { StaticSectionProps } from "@/components/general/StaticWrapper";
import { getSlugname } from "@/utils/Utils";
import { StoryStaticType } from "@/utils/mysunrise-utils-types";

interface CdProps extends GenericSBProps {}

const Cd1 = (props: CdProps): JSX.Element => {
	const { content } = props;
	const [cd1Data, setCd1Data] = useState<StoryStaticType|null>({
		staticSection: [],
		loadComponent: false
	});
	const params = getSlugname();
	useEffect(() => {
		(async () => {
			const response = await storyblokInstance.getPageContent(params);
			response.data.story.content.body.map((item: StoryStaticType) => {
					setCd1Data({
						...item,
						staticSection: item.staticSection,
						loadComponent : true
					})
			})
		})();
	}, [])

	return (
		<>
			<SbEditable content={content}>
				<div data-component="Cd1">
				{cd1Data && cd1Data.loadComponent &&
					cd1Data.staticSection &&
					cd1Data.staticSection.map((staticContent: StaticSectionProps) => (
						<StaticWrapperComponent
							content={staticContent}
							key={staticContent._uid}
						/>
					))}
					</div>
			</SbEditable>
		</>
	)
}
export default Cd1;
