import React, { useEffect, useState } from "react";
import { HashRouter as Router, Route, Switch } from "react-router-dom";
import Profile, { ProfileProps } from "@/src-containers/Profile/Profile";
import ProfileEditPassword, {
  ProfileEditPasswordProps,
} from "@/src-containers/Profile/ProfileEdit/ProfileEditPassword";
import {
  ProfileEditAddressProps,
} from "@/src-containers/Profile/ProfileEditAddress/ProfileEditAddress";
import ProfileEditAddress from "@/src-containers/Profile/ProfileEditAddress/ProfileEditAddress";
import ProfileEditBillingAddress, {
  ProfileEditBillingAddressProps,
} from "@/src-containers/Profile/ProfileEditBillingAddress/ProfileEditBillingAddress";
import {
  ProfileEditPersonalDataProps,
  ProfileEditPersonalData,
} from "@/src-containers/Profile/ProfileEditPersonalData/ProfileEditPersonalData";
import ProfilePrivacySettings, {
  ProfilePrivacySettingsProps,
} from "@/src-containers/Profile/ProfilePrivacySettings";
import Relocation, {
  RelocationProps,
} from "@/src-containers/Profile/Relocation/Relocation";
import UpdateAddress, {
  UpdateAddressProps,
} from "@/src-containers/Profile/Relocation/UpdateAddress/UpdateAddress";
import SbEditable from "storyblok-react";
import { GenericSBProps } from "@/components/index";
import storyblokInstance from "@/utils/StoryblokService";
import { Asset, MultiLink } from "@/utils/storyblok-types";
import { getSlugname } from "@/utils/Utils";

interface MyProfileProps extends GenericSBProps { }

interface ImageSliderProps {
  title: string;
  description: string;
  type: string;
  imageUrl: string;
  videoUrl: string;
  linkText: string;
  linkPath: string;
}

interface MyProfileConfigProps {
  imgRelocation: string;
  imgMail: string;
  imgBill: string;
  imgPrivacy: string;
  imgMailFailure: string;
  imgPayingBills: string;
  imgDummyPassword: string;
  dataPrivacyText: string;
  dataPrivacyUrl: string;
  cookiesAdministrationText: string;
  cookiesAdministrationUrl: string;
  imgBanner: string;
  showPrivacySection: boolean;
  relocationTermsConditionUrl: string;
  imgScanApp: string;
  otoIdImage: string;
  otoIdLink: string;
  imgSlider?: ImageSliderProps[];
  enablePegaCallback: boolean;
  workgroup: string;
}

interface ProfileState {
  title: string;
  description: string;
  type: string;
  imageAsset: Asset;
  videoAsset: MultiLink;
  dataPrivacyButtonText: string;
  dataPrivacyLinkPath: MultiLink;
}

interface ProfileDataType {
  profileProps?: MyProfileConfigProps,
  loadComponent: boolean
}

const MyProfile = (dataProps: MyProfileProps): JSX.Element => {
  const { content } = dataProps;
  const imageArray: ImageSliderProps[] = [];
  const params = getSlugname();
  const [profileData, setProfileData] = useState<ProfileDataType>({
    loadComponent: false,
  });
  let profilePageConfigData: MyProfileConfigProps;
  let imageSelect: ImageSliderProps;

  useEffect(() => {
    profilePageConfigData = {
      workgroup: dataProps.pageConfig.workgroup,
      imgRelocation: dataProps.pageConfig.relocationIcon.filename,
      imgMail: dataProps.pageConfig.mailIcon.filename,
      enablePegaCallback: dataProps.pageConfig.enablePegaCallback,
      imgBill: dataProps.pageConfig.billIcon.filename,
      imgPrivacy: dataProps.pageConfig.privacyIcon.filename,
      imgMailFailure: dataProps.pageConfig.failureMailIcon.filename,
      imgPayingBills: dataProps.pageConfig.billsPaymentImage.filename,
      imgDummyPassword: dataProps.pageConfig.dummyPasswordImage.filename,
      dataPrivacyText: dataProps.pageConfig.dataPrivacyText,
      dataPrivacyUrl: dataProps.pageConfig.dataPrivacyUrl.cached_url,
      cookiesAdministrationText:
        dataProps.pageConfig.cookiesAdministrationText,
      cookiesAdministrationUrl:
        dataProps.pageConfig.cookiesAdministrationUrl.cached_url,
      imgBanner: dataProps.pageConfig.imageBannerPath.filename,
      showPrivacySection: dataProps.pageConfig.showPrivacySection,
      relocationTermsConditionUrl:
        dataProps.pageConfig.relocationTermsConditionsUrl.cached_url,
      imgScanApp: dataProps.pageConfig.imageScanApp.filename,
      otoIdImage: dataProps.pageConfig.otoidimage.filename,
      otoIdLink: dataProps.pageConfig?.otoIdLink?.cached_url
    };
    (async () => {
      const response = await storyblokInstance.getPageContent(params);
      response.data.story.content.body.map((itemObj: any) => {
        itemObj &&
          itemObj.Images.map((item: ProfileState) => {
            imageSelect = {
              title: item.title,
              description: item.description,
              type: item.type,
              imageUrl: item.imageAsset.filename,
              videoUrl: item.videoAsset.cached_url,
              linkText: item.dataPrivacyButtonText,
              linkPath: item.dataPrivacyLinkPath.cached_url,
            }
            imageArray.push(imageSelect);
            });
        setProfileData({
          ...itemObj,
          profileProps: {
            ...profilePageConfigData,
            imgSlider: imageArray,
            thumbnailVideoUrl: itemObj.relocationVideo?.cached_url,
            thumbnailImageUrl: itemObj.relocationThumbnail?.filename
          },
          loadComponent: true,
        });
      });
    })();
  }, []);

  return (
    <>
      <SbEditable content={content}>
      <div data-component="MyProfile"
            style={
              typeof window !== 'undefined' && !window.location.href.includes('?login')
                ? {}
                : { display: 'flex', flex: '1' }
            }
          >
          {process.browser && profileData.loadComponent && (
            <>
              <Router>
                <Switch>
                  <Route
                    exact
                    path="/"
                    component={(props: ProfileProps) => (
                      <Profile {...props} {...profileData.profileProps} />
                    )}
                  />
                  <Route
                    path="/BillingAddress"
                    component={(props: ProfileEditBillingAddressProps) => (
                      <ProfileEditBillingAddress
                        {...props}
                        {...profileData.profileProps}
                      />
                    )}
                  />
                  <Route
                    path="/ChangePassword"
                    component={(props: ProfileEditPasswordProps) => (
                      <ProfileEditPassword
                        {...props}
                        {...profileData.profileProps}
                      />
                    )}
                  />
                  <Route
                    path="/Relocation"
                    component={(props: RelocationProps) => (
                      <Relocation {...props} {...profileData.profileProps} />
                    )}
                  />
                  <Route
                    path="/UpdateAddress"
                    component={(props: UpdateAddressProps) => (
                      <UpdateAddress {...props} {...profileData.profileProps} />
                    )}
                  />
                  <Route
                    path="/EditPrivacySettings"
                    component={(props: ProfilePrivacySettingsProps) => (
                      <ProfilePrivacySettings
                        {...props}
                        {...profileData.profileProps}
                      />
                    )}
                  />
                  <Route
                    path="/EditPersonalData"
                    component={(props: ProfileEditPersonalDataProps) => (
                      <ProfileEditPersonalData
                        {...props}
                        {...profileData.profileProps}
                      />
                    )}
                  />
                  <Route
                    path="/ScannedPersonalData"
                    component={(props: ProfileEditPersonalDataProps) => (
                      <ProfileEditPersonalData
                        {...props}
                        {...profileData.profileProps}
                      />
                    )}
                  />
                  <Route
                    path="/EditAddress"
                    component={(props: ProfileEditAddressProps) => (
                      <ProfileEditAddress
                        {...props}
                        {...profileData.profileProps}
                      />
                    )}
                  />
                  <Route
                    path="*"
                    component={(props: ProfileProps) => (
                      <Profile {...props} {...profileData.profileProps} />
                    )}
                  />
                </Switch>
              </Router>
              {window.location.href.includes('?login')?<></>:<div className="s20-spacer s20-spacer--x60"></div>}
            </>
          )}
        </div>
      </SbEditable>
    </>
  );
};

export default MyProfile;
