import React from 'react';
import { GenericSBProps } from '@/components/index';
import SbEditable from 'storyblok-react';
import EmployeeOfFirmAcceptance, { EmployeeOfFirmAcceptanceProps } from '@/src-components/EmployeeOfFirm/EmployeeOfFirmAcceptance';

interface EmployeeDiscountProps extends GenericSBProps, EmployeeOfFirmAcceptanceProps {}

const EmployeeDiscount = (props: EmployeeDiscountProps): JSX.Element => {
	const { content } = props;
	return (
		<>
			<SbEditable content={content}>
				<div data-component="EmployeeDiscount">
				<EmployeeOfFirmAcceptance {...props} />
				</div>
			</SbEditable>
		</>
	)
}

export default EmployeeDiscount