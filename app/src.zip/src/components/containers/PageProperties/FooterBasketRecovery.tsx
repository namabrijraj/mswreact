import React from "react"
import BasketRecovery, { BasketRecoveryProps } from "@/src-components/BasketRecovery/BasketRecovery"

interface FooterBasketRecoveryProps {
  content: BasketRecoveryProps;
}

const FooterBasketRecovery = (props: FooterBasketRecoveryProps): JSX.Element => {

  return (
    <div data-component="FooterBasketRecovery">
      <BasketRecovery {...props.content} />
    </div>
  )
}
export default FooterBasketRecovery