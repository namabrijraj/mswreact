import React, { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';

const Tutorials = dynamic(() => import('@/src-components/Tutorials/Tutorials'), {
  ssr: false,
});

interface TutorialSteps {
  title: string;
  content: string;
  target: string;
  position?: string;
  positionMob?: string;
}

const SbTutorial = (props: any) => {
  const [tutorialDetails, setTutorialDetails] = useState<any>();
  const [isValid, setIsValid] = useState<boolean>(false);
  let pageId: string;
  const current: any = new Date();
  useEffect(() => {
    let tutorialArray: TutorialSteps[] = [];
    if (props?.tutorialConfig !== undefined) {
      props.tutorialConfig?.map((steps: any) => {
        const componentId =
          steps.aemcomponentid === '' ? steps.componentid : '#' + steps.aemcomponentid;
        let startTime = new Date(steps.starttime);
        let endTime = new Date(steps.expirytime);
        if (current.getTime() > startTime.getTime() && current.getTime() < endTime.getTime()) {
          let stepObj = {
            title: steps.title,
            content: steps.description,
            target: componentId,
            position: steps.position ? steps.position : '',
            positionMob: steps.positionMob ? steps.positionMob : ''
          };
          tutorialArray.push(stepObj);
        }
      });
    }

    pageId = document.title.toLowerCase();
    if (tutorialArray.length > 0) {
      setIsValid(true);
    }
    setTutorialDetails({
      tutorialSteps: tutorialArray,
      tutorialPageId: pageId,
    });
  }, []);
  return (
    <>
      {tutorialDetails && isValid && (
        <div
          data-component='Tutorial'
          data-prop-tutorial-page-id={tutorialDetails.tutorialPageId}
          data-prop-tutorial-steps={JSON.stringify(tutorialDetails.tutorialSteps)}
        >
          <Tutorials {...tutorialDetails} />
        </div>
      )}
    </>
  );
};
export default SbTutorial;
