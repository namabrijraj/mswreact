import { setCookie, showAndHideCookieBanner } from "@/assets/lib/cookie-utils";
import { useEffect, useState } from "react";

const PswdSecurityBanner = (props: any) => {
  const [pswdSecurityBannerIcon, setPswdSecurityBannerIcon] =
    useState<string>("");
  const [pswdSecurityBannerText, setPswdSecurityBannerText] =
    useState<string>("");
  const [pswdSecurityBannerButtonText, setPswdSecurityBannerButtonText] =
    useState<string>("");
  useEffect(() => {
    {
      props.pageConfig &&
      setPswdSecurityBannerIcon(props.pageConfig.pwdsecuritybannericon.filename);
      setPswdSecurityBannerText(props.pageConfig.pwdsecuritybannertext);
      setPswdSecurityBannerButtonText(props.pageConfig.pwdsecuritybannerbutton);
    }
  }, []);
  return (
    <div
      data-component="PswdSecurityBanner"
      className="s20-notification-banner js-header_alert is-active s20-notification-banner--light"
      id="banner-notification"
      style={{ display: "none" }}
    >
      {showAndHideCookieBanner(
        "pswd-security-banner-closed",
        "banner-notification"
      )}
      <div className="s20-notification-banner__inner">
        <div className="s20-notification-banner__container">
          <img
            className="s20-notification-banner__title-icon"
            src={pswdSecurityBannerIcon}
          />
          <div
            className="s20-notification-banner__message"
            dangerouslySetInnerHTML={{ __html: pswdSecurityBannerText }}
          ></div>
          <div className="s20-notification-banner__button">
            <button
              className="s20-button s20-button--secondary"
              type="button"
              onClick={() =>
                setCookie(
                  "pswd-security-banner-closed",
                  "true",
                  "banner-notification",
                  "2147483647"
                )
              }
            >
              {pswdSecurityBannerButtonText}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default PswdSecurityBanner;
