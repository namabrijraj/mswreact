import { setCookie, showAndHideCookieBanner } from "@/assets/lib/cookie-utils";
import React, { useEffect, useState } from "react";

interface InfoBannerProps {
  enableInfoBanner: boolean;
  infoBannerType: string;
  infoBannerHeading: string;
  infoBannerCookieText: string;
  infoBannerLearnMoreText: string;
  infoBannerLearnMoreUrl: string;
  infoBannerCookieExpiry: string;
}

const InfoBanner = (props: any) => {
  const [infoBannerState, setInfoBannerState] = useState<InfoBannerProps>({
    enableInfoBanner: false,
    infoBannerType: "",
    infoBannerHeading: "",
    infoBannerCookieText: "",
    infoBannerLearnMoreText: "",
    infoBannerLearnMoreUrl: "",
    infoBannerCookieExpiry: "",
  });
  useEffect(() => {
    setInfoBannerState({
      enableInfoBanner: props.pageConfig.enableInfoBanner,
      infoBannerType: props.pageConfig.infoBannerType,
      infoBannerHeading: props.pageConfig.infoBannerHeading,
      infoBannerCookieExpiry: props.pageConfig.infoBannerCookieExpiry,
      infoBannerCookieText: props.pageConfig.infoBannerCookieText,
      infoBannerLearnMoreText: props.pageConfig.infoBannerLearnMoreText,
      infoBannerLearnMoreUrl:
        props.pageConfig.infoBannerLearnMoreUrl.cached_url,
    });
  }, []);
  return (
    <div data-component="InfoBanner">
      {process.browser && infoBannerState.enableInfoBanner && (
        <div className="s20-header__notification">
          <div
            id="infoBanner-notification"
            className={`is-active s20-notification-banner ${
              infoBannerState.infoBannerType === "alert"
                ? "s20-notification-banner--error"
                : ""
            }`}
            style={{ display: "none" }}
          >
            {showAndHideCookieBanner("info_banner", "infoBanner-notification")}
            <div className="s20-notification-banner__inner">
              <div className="s20-notification-banner__container">
                <div className="s20-notification-banner__message">
                  <div className="s20-notification-banner__title">
                    {infoBannerState.infoBannerHeading
                      ? infoBannerState.infoBannerHeading
                      : "Title update"}
                  </div>
                  {infoBannerState.infoBannerCookieText}
                  <a
                    className="link"
                    href={
                      infoBannerState.infoBannerLearnMoreUrl
                        ? infoBannerState.infoBannerLearnMoreUrl
                        : "#"
                    }
                  >
                    {infoBannerState.infoBannerLearnMoreText
                      ? infoBannerState.infoBannerLearnMoreText
                      : "Text link"}
                  </a>
                </div>
                <div className="s20-notification-banner__cta">
                  <i
                    className="s20-icon s20-icon--close s20-notification-banner__icon"
                    onClick={() =>
                      setCookie(
                        "info_banner",
                        "dismiss",
                        "infoBanner-notification",
                        `${infoBannerState.infoBannerCookieExpiry}`
                      )
                    }
                  ></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default InfoBanner;
