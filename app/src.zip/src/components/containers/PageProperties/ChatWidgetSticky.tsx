import { GenericSBProps } from "@/components/index";
import SelfCareCallback, { SelfCareCallbackProps } from "@/src-components/SelfCareCallback/SelfCareCallback";
import { getUrlParam } from "@/utils/global";
import React, { useEffect, useState } from "react";
import SbEditable, { SbEditableContent } from "storyblok-react";

interface ChatWidgetStickyProps
  extends GenericSBProps,
  SelfCareCallbackProps {
  content: SbEditableContent;
}

const ChatWidget = (props: any): JSX.Element => {
  const { content }: ChatWidgetStickyProps = props;
  const [ChatWidgetState, setChatWidgetState] =
    useState<ChatWidgetStickyProps | null>();
  const [redirectFromIvr, setRedirectFromIvr] = useState<boolean>(false);
  const [shortDelay, setShortDelay] = useState<string>("");
  const [longDelay, setLongDelay] = useState<string>("");
  const [showOldUi, setShowOldUi] = useState<boolean>(false);
  useEffect(() => {
    setShortDelay(props.pageConfig.short);
    setLongDelay(props.pageConfig.long);
    setShowOldUi(props.pageConfig.showoldui);
    let ChatWidget: any = {};
    let Duration =
      props.content.disableChatWidget === "Short" ? shortDelay : longDelay;
    getUrlParam("fromVIVR") !== "" && setRedirectFromIvr(true);
    ChatWidget["isOldUi"] = showOldUi;
    ChatWidget["callbackTime"] =
      props.content.disableChatWidget === "Immediate" ? "0" : Duration;
    setChatWidgetState(ChatWidget);
  }, []);

  return (
    <>
      <SbEditable content={content}>
        <div
          data-component="ChatWidget"
          data-prop-integration-id={content.integrationId}
          data-prop-app-id={content.appId}
        >
          {redirectFromIvr && !props.content.hideChatWidget && (
            <SelfCareCallback {...{ ...props, ...ChatWidgetState }} />
          )}
        </div>
      </SbEditable>
    </>
  );
};
export default ChatWidget;
