import { useEffect } from "react"
const SmartBanner = require('@/assets/lib/smartbanner');

const SbSmartBanner = () => {
	useEffect(() => {
		new SmartBanner()
	}, [])
	return (
		<></>
	)
}
export default SbSmartBanner