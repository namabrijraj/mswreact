import { GenericSBProps } from '@/components/index';
import ContactOptionsSticky, {
  ContactOptionsStickyProps,
} from '@/src-components/ContactOptionsSticky/ContactOptionsSticky';
import { MAILTO, TEL } from '@/utils/constants';
import React, { useEffect, useState } from 'react';
import SbEditable from 'storyblok-react';

interface ContactStickyProps extends GenericSBProps, ContactOptionsStickyProps {}
interface StickyComponentProps {
  integrationId: string;
  appId: string;
  mainChatId: string;
  chatId: string;
  phoneNumber: string;
  phoneLink: string;
  shopsUrl: string;
  helpUrl: string;
  emailLink: string;
  email: string;
  delay: string;
  enableChat: boolean;
  ivrUrl: string;
  legalDisclaimer: string;
  callbackImage: string;
  enablePegaCallback: boolean;
}

const ContactSticky = (props: any): JSX.Element => {
  const { content, pageConfig }: ContactStickyProps = props;
  const [ContactStickyState, setContactStickyState] = useState<StickyComponentProps>();
  const [disableChat, setDisableChat] = useState<string>('');
  useEffect(() => {
    let chatProps = {
      enablePegaCallback: pageConfig.enablePegaCallback ? pageConfig.enablePegaCallback : '',
      callbackImage: pageConfig.callbackImage ? pageConfig.callbackImage.filename : '',
      helpUrl: props.content.disableHelpLink ? window.ReactApp.Env.helpLink : props.content.helpLink?.cached_url,
      ivrUrl: props.content.disableIvrLink ? window.ReactApp.Env.ivrLink : props.content.ivrLink?.cached_url,
      disableContactOptionsSticky: props.content.disableContactOptionsSticky === 'Inherit' ?
        window.ReactApp.Env.disableContactOptionsSticky : props.content.disableContactOptionsSticky,
      disablePhoneNumber: props.content.disablePhoneNumber === 'Inherit' ?
        window.ReactApp.Env.disablePhoneNumber : props.content.disablePhoneNumber,
      disableEmail: props.content.disableEmail === 'Inherit' ?
        window.ReactApp.Env.disableEmail : props.content.disableEmail,
      disableShopsLink: props.content.disableShopsLink === 'Inherit' ?
        window.ReactApp.Env.disableShopsLink : props.content.disableShopsLink,
      disableHelpLink: props.content.disableHelpLink === 'Inherit' ?
        window.ReactApp.Env.disableHelpLink : props.content.disableHelpLink,
      disableIvrLink: props.content.disableIvrLink === 'Inherit' ?
        window.ReactApp.Env.disableIvrLink : props.content.disableIvrLink,
      enableChat: props.content.enableChat === 'Inherit' ?
        window.ReactApp.Env.enableChat : props.content.enableChat,
      phoneNumber: props.content.disablePhoneNumber === 'Inherit' ? window.ReactApp.Env.phoneNumber
        : props.content.phoneNumber,
      phoneLink: props.content.disablePhoneNumber === 'Inherit' ? TEL + window.ReactApp.Env.phoneNumber
        : TEL + props.content.phoneNumber,
      email: props.content.disableEmail ? window.ReactApp.Env.email : props.content.email,
      emailLink: props.content.disableEmail === 'Inherit' ? MAILTO + window.ReactApp.Env.email
        : MAILTO + props.content.email,
      shopsUrl: props.content.disableShopsLink ? window.ReactApp.Env.shopsLink : props.content.shopsLink?.cached_url,
    };
    setDisableChat(chatProps.disableContactOptionsSticky);
    setContactStickyState({
      integrationId: window.ReactApp.Env.integrationId,
      appId: window.ReactApp.Env.appId,
      mainChatId: window.ReactApp.Env.mainChatId,
      chatId: window.ReactApp.Env.chatId,
      delay: window.ReactApp.Env.delay,
      enableChat: !!chatProps.enableChat,
      phoneNumber: chatProps.disablePhoneNumber === 'false' ? chatProps.phoneNumber : '',
      phoneLink: chatProps.disablePhoneNumber === 'false' ? chatProps.phoneLink : '',
      email: chatProps.disableEmail === 'false' ? chatProps.email : '',
      emailLink: chatProps.disableEmail === 'false' ? chatProps.emailLink : '',
      shopsUrl: chatProps.disableShopsLink === 'false' ? chatProps.shopsUrl : '',
      helpUrl: chatProps.disableHelpLink === 'false' ? chatProps.helpUrl : '',
      ivrUrl: chatProps.disableIvrLink === 'false' ? chatProps.ivrUrl : '',
      callbackImage: chatProps.callbackImage,
      enablePegaCallback: chatProps.enablePegaCallback,
      legalDisclaimer: window.ReactApp.Env.disclaimerLink
    });
  }, []);

  return (
    <>
      <SbEditable content={content}>
        <div
          data-component='ContactOptionsSticky'
          data-prop-integration-id={ContactStickyState && ContactStickyState.integrationId}
          data-prop-app-id={ContactStickyState && ContactStickyState.appId}
        >
          {disableChat === 'false' && ContactStickyState && (
            <ContactOptionsSticky {...{ ...props, ...ContactStickyState }} />
          )}
        </div>
      </SbEditable>
    </>
  );
};
export default ContactSticky;
