import Header, { HeaderProps } from "@/src-containers/Header/Header";
import React, { useEffect, useState } from "react";

const HeaderSearch = (props: any) => {
  const [searchProps, setSearchProps] = useState<HeaderProps>();
  const [languageProps, setLanguageProps] = useState<any>();
  let flyoutList: any = {}, pagesLink: any = {};
  let mobileNavList: any = [], items: any;
  useEffect(() => {
    props.pageConfig &&
      props.pageConfig.loginFlyoutGroupLinks &&
      Array.isArray(props.pageConfig.loginFlyoutGroupLinks) &&
      props.pageConfig.loginFlyoutGroupLinks.length &&
      props.pageConfig.loginFlyoutGroupLinks.map((configItems: any) => {
        items = []
        flyoutList["groupName"] = configItems.groupText
        flyoutList["groupHref"] = configItems.groupLink.cached_url
        configItems.loginFlyoutPageList.map((pageList: any) => {
          pagesLink['name'] = pageList.linkText
          pagesLink['href'] = pageList.linkPath.cached_url
          pagesLink['image'] = pageList?.profileIcon?.filename
          pagesLink['isDesktopView'] = pageList?.isDesktopMenu
          items.push(pagesLink)
          flyoutList["items"] = items
          pagesLink = {}
        })
        mobileNavList.push(flyoutList)
        flyoutList = {}
      })
    setSearchProps({
      disableSearch: props.pageConfig.disablesearch,
      searchPagePath: props.pageConfig.searchpagepath.cached_url,
      maxSearchResults: parseInt(props.pageConfig.maxsearchresults),
      menu: mobileNavList
    });
  }, []);

  useEffect(() => {
    setLanguageProps({
      language: props.languages
    })
  }, [props.languages])
  return (
    <div data-component="HeaderSearch">
      <Header {...{ ...props, ...searchProps, ...languageProps }} />
    </div>
  );
};
export default HeaderSearch;
