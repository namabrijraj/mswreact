import I18n from "src/utils/helper/I18n";

const Backtoivr = () => {

	return (
		<div data-component="backtoivr" data-component-title={I18n.translate('backtoivr')} className="s20-link-bar is-hidden">
			<a id="ivr-assistant" className="s20-link-bar__link" >{I18n.translate('backtoivr')}</a>
		</div>
	)
}
export default Backtoivr;