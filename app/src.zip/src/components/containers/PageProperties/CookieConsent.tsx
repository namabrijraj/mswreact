import { useEffect, useState } from "react";
import { setCookie, showAndHideCookieBanner } from "@/assets/lib/cookie-utils";

interface CookieProps {
  learnMoreUrl: string;
  learnMoreText: string;
  cookieText: string;
  cookieImage: string;
  cookieButtonText: string
}

const CookieConsent = (props: any): JSX.Element => {
  const [cookieConsentState, setCookieConsentState] = useState<CookieProps | null>(null);
  useEffect(() => {
    setCookieConsentState({
      learnMoreUrl: props.pageConfig.learnmorelinkurl.cached_url,
      learnMoreText: props.pageConfig.learnmore,
      cookieText: props.pageConfig.cookietext,
      cookieImage: props.pageConfig.cookieImage.filename,
      cookieButtonText: props.pageConfig.dismisstext
    });
    showAndHideCookieBanner("cookieconsent_status", "cookieBanner-gdpr");
  }, []);
  return (
    <div
      id="cookieBanner-gdpr"
      data-component="CookieConsent"
      className="s20-sticky-bar-wrapper js-stickybox s20-sticky-bar-wrapper--cookie"
      data-settings-position="bottom"
      style={{ display: "none" }}
    >
      <div className="s20-cookie-banner js-stickybox--element s20-cookie-banner--sticky">
        <div className="s20-cookie-banner__container">
          {cookieConsentState && 
          <div className="s20-cookie-banner__media">
            <img
              alt=""
              src={cookieConsentState.cookieImage}
              className="s20-cookie-banner__img"
            />
          </div>}
          <div className="s20-cookie-banner__content">
            <div className="s20-cookie-banner__text richtext">
              {cookieConsentState && (
                <div className="cookie_banner">
                  <p>{cookieConsentState.cookieText}</p>
                </div>
              )}
              {cookieConsentState && (
                <a
                  aria-label="learn more about cookies"
                  className="t-bold"
                  href={cookieConsentState.learnMoreUrl}
                  target="_blank"
                >
                  {cookieConsentState.learnMoreText}
                </a>
              )}
            </div>
            {cookieConsentState && 
            <div className="s20-cookie-banner__cta">
              <button
                className="s20-button s20-button--secondary s20-button--small s20-cookie-banner__button"
                type="button"
                onClick={() =>
                  setCookie(
                    "cookieconsent_status",
                    "dismiss",
                    "cookieBanner-gdpr",
                    "1"
                  )
                }
              >
                {cookieConsentState.cookieButtonText}
              </button>
            </div>}
          </div>
        </div>
      </div>
    </div>
  );
};
export default CookieConsent;
