import React, { useEffect, useState } from "react";

interface MaintenanceBannerProps {
  maintenanceBannerHeading: string;
  maintenanceBannerText: string;
  maintenanceBannerLearnMoreText: string;
  maintenanceBannerLearnMoreUrl: string;
}

const MaintenanceBanner = (): any => {
  const [maintenanceBannerState, setMaintenanceBannerState] = useState<MaintenanceBannerProps | null>(null);
  const [enableMaintenanceBanner, setEnableMaintenanceBanner] = useState<string>('false');
  useEffect(() => {
    setEnableMaintenanceBanner(window.ReactApp.Env.enableMaintenanceBanner)
    setMaintenanceBannerState({
      maintenanceBannerHeading: window.ReactApp.Env.maintenanceBannerHeading,
      maintenanceBannerText: window.ReactApp.Env.maintenanceBannerText,
      maintenanceBannerLearnMoreText: window.ReactApp.Env.maintenanceBannerLearnMoreText,
      maintenanceBannerLearnMoreUrl: window.ReactApp.Env.maintenanceBannerLearnMoreUrl,
    });
  }, []);
  if (enableMaintenanceBanner === 'true') {
    return (
      <div data-component="MaintenanceBanner">
        {process.browser && enableMaintenanceBanner && maintenanceBannerState && (
          <div className="s20-header__notification">
            <div
              id="maintenanceBanner-notification"
              className={`is-active s20-notification-banner s20-notification-banner--error`}
            >
              <div className="s20-notification-banner__inner">
                <div className="s20-notification-banner__container">
                  <div className="s20-notification-banner__message">
                    <div className="s20-notification-banner__title">
                      {maintenanceBannerState.maintenanceBannerHeading
                        ? maintenanceBannerState.maintenanceBannerHeading
                        : "Title update"}
                    </div>
                    {maintenanceBannerState.maintenanceBannerText}
                    <a
                      className="link"
                      href={
                        maintenanceBannerState.maintenanceBannerLearnMoreUrl
                          ? maintenanceBannerState.maintenanceBannerLearnMoreUrl
                          : "#"
                      }
                    >
                      {maintenanceBannerState.maintenanceBannerLearnMoreText
                        ? maintenanceBannerState.maintenanceBannerLearnMoreText
                        : "Text link"}
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }
  else {
    return null;
  }
};
export default MaintenanceBanner;
