import React from "react"
import { HashRouter as Router, Route, Switch } from "react-router-dom"
import DeepLinksSelector, { DeepLinksSelectorProps } from "@/src-containers/DeepLinks/DeepLinksSelector/DeepLinksSelector"
import DeepLinks, { DeepLinksProps } from "@/src-containers/DeepLinks/DeepLinks"

const SbDeeplinks = (): JSX.Element => {
  return(
    <div data-component="Deeplinks"> 
    {process.browser && 
        <Router>
          <Switch>
            <Route exact path='/' component={(props: DeepLinksProps) => <DeepLinks {...props} />} />
            <Route exact path='/:overlay/:section?/:serviceId?'
              component={(props: DeepLinksSelectorProps) => <DeepLinksSelector {...props} />} />
            <Route path='*' component={DeepLinks} />
          </Switch>
        </Router>
    }
    </div>
  )
}
export default SbDeeplinks