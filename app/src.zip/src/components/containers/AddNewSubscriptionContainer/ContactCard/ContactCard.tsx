import React from "react";
import { SubscriptionsConstants } from "src/containers/Subscriptions/SubscriptionsConstants";
import DataLayerService from 'src/utils/DataLayer/DataLayerService';
import { DataLayerConstants } from 'src/utils/DataLayer/DataLayerConstants';

const ContactCard = (card: any): JSX.Element => {
  const onHandleClickTeaser = (cards: any): void => {
    cards.title === DataLayerConstants.event.SALES_HOTLINE?
    DataLayerService.addEventData(
      [
        {
          eventName: DataLayerConstants.event.SALES_POPUP,
          eventType: DataLayerConstants.event.CLICK,
          eventValue: `${cards.title}`,
        },
      ],
      true):cards.title === DataLayerConstants.event.FIND_SHOP ?
      DataLayerService.addEventData(
        [
          {
            eventName: DataLayerConstants.event.SALES_POPUP,
            eventType: DataLayerConstants.event.CLICK,
            eventValue: `${cards.title}`,
          },
        ],
        true):''

    if (SubscriptionsConstants.MOBILE_SCBCRIPTION_ICON === cards.contactOption) {
      window.open(`tel:${cards.phoneNumber}`, "_self");
    } else {
      window.location.href = cards.link.url;
    }
  };


  return (
    <>
      {card?.card?.content?.content?.bloks.map((item: any) => {
        return (
          <div className="s20-chat-widget__content">
            <ul className="s20-chat-widget__list">
              {item?.cards.map((cards: any) => {
                return (
                  <li className="s20-chat-widget__list-item">
                    <a
                      onClick={() => onHandleClickTeaser(cards)}
                      className="s20-chat-widget__option  s20-chat-widget__option--has-icon"
                    >
                      <span className="s20-chat-widget__option-figure">
                        <i
                          className={`${
                            cards?.contactOption == SubscriptionsConstants.MOBILE_SCBCRIPTION_ICON
                              ? "s20-icon s20-chat-widget__option-icon s20-icon--landline-outline-grey-light"
                              : cards?.contactOption == SubscriptionsConstants.INTERNET_SCBCRIPTION_ICON
                              ? "s20-icon s20-chat-widget__option-icon s20-icon--shop-building-white"
                              : null
                          }`}
                        ></i>
                      </span>
                      <span className="s20-chat-widget__option-title">
                        {cards.title}
                      </span>
                      {cards?.description?.content.map((content: any) => {
                        return (
                          <span className="s20-chat-widget__option-description">
                            {content?.content.map((description: any) => {
                              return description.text;
                            })}
                          </span>
                        );
                      })}
                    </a>
                  </li>
                );
              })}
            </ul>
          </div>
        );
      })}

      <div className="s20-spacer s20-spacer--x40 is-visible-mobile"></div>
      <div className="s20-spacer s20-spacer--x64 is-hidden-mobile"></div>
    </>
  );
};

export default ContactCard;
