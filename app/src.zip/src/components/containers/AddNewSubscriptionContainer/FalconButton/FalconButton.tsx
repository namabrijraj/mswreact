import React from 'react';
import DataLayerService from 'src/utils/DataLayer/DataLayerService';
import { DataLayerConstants } from 'src/utils/DataLayer/DataLayerConstants';
import I18n from 'src/utils/helper/I18n';
import DataLanguageService from 'src/utils/DataLanguageService';
import { DataLayerGtmConstants } from 'src/utils/DataLayer/DataLayerGtmConstants';
import DataLayerGtmService from 'src/utils/DataLayer/DataLayerGtmService';
interface FalconButtonProps {
  content?: any
}
export class FalconButton extends React.Component<FalconButtonProps> {
  constructor(props: FalconButtonProps) {
    super(props);
  }

  onHandleSaleshotline = (phoneNumber: string): void => {
    DataLayerService.addEventData(
      [
        {
          eventName: DataLayerConstants.event.SALES_POPUP,
          eventType: DataLayerConstants.event.CLICK,
          eventValue: DataLayerConstants.event.SALES_HOTLINE,
        },
      ],
      true
    );
    DataLayerGtmService.dataLayerGtm(DataLayerGtmConstants.event.SALES_HOTLINE, DataLayerGtmService.getGtmData(DataLayerGtmConstants.event.GA_EVENT, DataLayerGtmConstants.event.SALES_HOTLINE))
    window.open(`tel:${phoneNumber}`, '_self');
  };
  onHandleAddoption = (): void => {
    DataLayerService.addEventData(
      [
        {
          eventName: DataLayerConstants.event.OVERVIEW_ADDOPTIONS,
          eventType: DataLayerConstants.event.CLICK,
          eventValue: DataLayerConstants.event.Add_Options,
        },
      ],
      true)
    window.location.href = `${window.ReactApp.Env.urlDeeplink}#/ManageOptions`;
  }
  onHandleFindshop = (): void => {
    DataLayerService.addEventData(
      [
        {
          eventName: DataLayerConstants.event.SALES_POPUP,
          eventType: DataLayerConstants.event.CLICK,
          eventValue: DataLayerConstants.event.FIND_SHOP,
          gtmInfo: { event_name: DataLayerGtmConstants.event.FIND_A_SHOP, link_url: `${window.ReactApp.Env.urlShopAssets}/${DataLanguageService.getLanguageCode()}/${I18n.translate('SubscriptionsRatePlan.FindShop.Link')}`, click_text: I18n.translate('SubscriptionsRatePlan.Findshop.Title') }
        },
      ],
      true
    );
    let FindShop = I18n.translate('SubscriptionsRatePlan.FindShop.Link');
    let url = `${window.ReactApp.Env.urlShopAssets
      }/${DataLanguageService.getLanguageCode()}/${FindShop}`;
    window.open(url, '_blank');
  };

  getCardDetails = (card: any) => {
    const isPhoneNumber: boolean = card?.phoneNumber ? true : false;
    const cardDescription: string = card?.description?.content[0]?.content[0]?.text || '';
    return (
      <li className='s20-chat-widget__list-item'>
        <a href={isPhoneNumber ? `tel:${card?.phoneNumber}` : ''}
          onClick={() => isPhoneNumber ? this.onHandleSaleshotline(card?.phoneNumber) : this.onHandleFindshop()}
          className='s20-chat-widget__option  s20-chat-widget__option--has-icon'
        >
          <span className='s20-chat-widget__option-figure'>
            <i className={`s20-chat-widget__option-icon icon-fds ${isPhoneNumber ? 'icon-fds--standard-phone-grey-light-mask' : 'icon-fds--standard-building-sme-mask'}`} />
          </span>
          <span className='s20-chat-widget__option-title'>
            {card?.title}
          </span>
          <span className='s20-chat-widget__option-description'>
            {cardDescription}
          </span>
        </a>
      </li>
    )
  }

  renderFalconButton = (): JSX.Element => {
    const { content } = this.props;
    const cards: object[] = content?.content?.bloks[0]?.cards;
    return (
      <>
        <div className='s20-spacer s20-spacer--x16'></div>
        <div className='l-center-xxl l-center-sds'>
          <div className='s20-form-item s20-form-item--buttons'>
            <div className='l-center-s'>
              <div className='s20-chat-widget'>
                <ul className='s20-chat-widget__list'>
                  {cards.map((card: object) => {
                    return (
                      this.getCardDetails(card)
                    )
                  })}
                </ul>
              </div>
            </div>
            <div className='s20-spacer s20-spacer--x16' />
            <div className='s20-spacer s20-spacer--x32 is-visible-mobile' />
            <div className='s20-spacer s20-spacer--x64 is-hidden-mobile' />
            <div className='l-center-xxl l-center-sds'>
              <div className='s20-promo-teaser s20-promo-teaser--slim-option s20-promo-teaser--option'>
                <a
                  className='s20-promo-teaser__anchor'
                  onClick={() => this.onHandleAddoption()}
                ></a>
                <div className='s20-promo-teaser__container'>
                  <div className='s20-promo-teaser__prepend-icon s20-icon s20-icon--add-circle' />
                  <div className='s20-promo-teaser__content'>
                    <div className='s20-promo-teaser__title'>
                      <h3 className='s20-teaser-title s20-teaser-title--regular s20-teaser-title--small'>
                        <I18n code='SubscriptionsRatePlan.Title.Subscription.Teaser.Option' />
                      </h3>
                      <div className='s20-promo-teaser__tooltip' />
                    </div>
                    <div className='s20-promo-teaser__text'>
                      <I18n code='SubscriptionsRatePlan.Label.Subscription.Teaser.Option' />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    )
  }

  render(): React.ReactNode {
    return (
      <React.Fragment>
        {this.renderFalconButton()}
      </React.Fragment>
    );
  }
}