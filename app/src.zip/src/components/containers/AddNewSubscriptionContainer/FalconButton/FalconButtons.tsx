import SbEditable, { SbEditableContent } from "storyblok-react";
import { FalconButton } from "./FalconButton";
import React from "react";

const FalconButtons = (content: SbEditableContent): JSX.Element => {
    return (
        <>
            <SbEditable content={content}>
                <div data-component="FalconButton">
                    <FalconButton
                        content={content} />
                </div>
            </SbEditable>
        </>
    );
};

export default FalconButtons;