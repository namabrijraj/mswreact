import React from "react";

const FalconTitle = (content: any): JSX.Element => {
  const pageTitle: string = content?.metadata?.title?.toLowerCase() || '';
  return (
    <>
      {pageTitle.includes('my benefits') ? '' :
        <><div className="s20-spacer s20-spacer--x40 is-visible-mobile" />
      <div className="s20-spacer s20-spacer--x64 is-hidden-mobile"/>
      </>}
      <div className="l-center-xxl l-center-sds">
      <div className="s20-section-title s20-section-title--full-width s20-section-title--large">
        <h2 className="s20-section-title__heading">{content.content.text}</h2>
      </div>
      </div>
    </>
  );
};

export default FalconTitle;
