import React from "react";
import {SubscriptionsConstants} from 'src/containers/Subscriptions/SubscriptionsConstants';
import DataLayerService from 'src/utils/DataLayer/DataLayerService';
import { DataLayerConstants } from 'src/utils/DataLayer/DataLayerConstants';
import { DataLayerGtmConstants } from "src/utils/DataLayer/DataLayerGtmConstants";

const AddNewSubscriptionContainer = (content: any): JSX.Element => {
  const renderCard=(title: string,data:any,item:any): void =>{
    window.location.href=data.link.url;
    (item.uniqueSbId === SubscriptionsConstants.ADDPRODUCT_MOBILE)?
    DataLayerService.addEventData(
      [
        {
          eventName: DataLayerConstants.event.ADDPRODUCT_MOBILE,
          eventType: DataLayerConstants.event.CLICK,
          eventValue: `${title}`,
          gtmInfo: { event_name: DataLayerGtmConstants.event.add_product.MOBILE, link_url: data.link.url, click_text: title }
        },
      ],
      true)
      :(item.uniqueSbId === SubscriptionsConstants.ADDPRODUCT_INTERNET)?
      DataLayerService.addEventData(
        [
          {
            eventName: DataLayerConstants.event.ADDPRODUCT_INTERNET,
            eventType: DataLayerConstants.event.CLICK,
            eventValue: `${title}`,
            gtmInfo: { event_name: DataLayerGtmConstants.event.add_product.WIN, link_url: data.link.url, click_text: title }
          },
        ],
        true)
      :''
  }
  return (
    <>
    <div className="l-center-xxl l-center-sds">
      <div className="product-caregory">
        {content?.content.map((item: any) => {
          return (
            <div className="product-caregory__item">
               <div className={`${(item.uniqueSbId == SubscriptionsConstants.ADDPRODUCT_MOBILE)?`product-caregory__item-bg product-caregory__item-bg--${item.backgroundGradient}`:(item.uniqueSbId == SubscriptionsConstants.ADDPRODUCT_INTERNET)?`product-caregory__item-bg product-caregory__item-bg--${item.backgroundGradient}`:''}`}>
                <div className="product-caregory__item-title t-strong">
                  {item.title}
                </div>
              </div>
              <div className="product-caregory__cards">
                {item?.subCards?.length > 0 &&
                  item?.subCards?.map((data: any) => (
                    <div className="product-caregory__card">
                      <a
                        className="product-caregory__card-link"
                        onClick={()=>renderCard(data.title,data,item)}
                      ></a>

                      <div className={`${(data.enablePromoIcon == true) ? "product-caregory__card-icon product-caregory__card-icon--discount" : ''}`}>
                        <img src={data?.icon?.filename} />
                      </div>

                      <div className="product-caregory__card-title t-strong">
                        {data?.title}
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          );
        })}
      </div>
      </div>
    </>
  );
};
export default AddNewSubscriptionContainer;
