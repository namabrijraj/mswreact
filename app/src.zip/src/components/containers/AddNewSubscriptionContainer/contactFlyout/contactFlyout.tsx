import React from "react";
import ContactCard from "../ContactCard/ContactCard";

const contactFlyout = (content: any): JSX.Element => {
  return (
    <>
      <div className="overlay"></div>
      <div className="popup__container">
        <div className="popup js-popup">
          <div className="popup-message-box popup-message-box--no-padding">
            <div className="l-text-left">
              <div className="s20-chat-widget js-chat-widget s20-chat-widget--chat">
                <div className="s20-chat-widget__box js-chat-widget__box">
                  <div className="s20-chat-widget__head">
                    {content?.content?.content?.bloks.map((bloks: any) => {
                      return (
                        <h5 className="s20-chat-widget__head-title">
                          {bloks.title}
                        </h5>
                      );
                    })}
                    <div className="s20-chat-widget__head-description"></div>
                    <button className="s20-chat-widget__close js-popup__close" onClick={content.renderContactCard}>
                      <span className="is-visuallyhidden">
                        Close chat widget
                      </span>
                    </button>
                  </div>
                  <div className="s20-chat-widget__content">
                    <ContactCard card={content} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="s20-spacer s20-spacer--x40 is-visible-mobile"></div>
      <div className="s20-spacer s20-spacer--x64 is-hidden-mobile"></div>
    </>
  );
};

export default contactFlyout;
