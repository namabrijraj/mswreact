import React from "react";

const FalconDescription = (content: any): JSX.Element => {
  return (
    <>
      <div className="s20-spacer s20-spacer--x8"></div>
      {content.content.text.content.map((content: any) => {
        return content?.content.map((falcondescription: any) => {
          return (
            <div className="l-center-xxl l-center-sds">
            <div className="richtext richtext--grey font-s-16-imp richtext-center">
              {falcondescription.text}
            </div>
            </div>
          );
        });
      })}
    </>
  );
};
export default FalconDescription;
