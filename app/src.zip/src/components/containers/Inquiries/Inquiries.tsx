import { GenericSBProps } from "@/components/index";
import storyblokInstance from "@/utils/StoryblokService";
import { getSlugname } from "@/utils/Utils";
import React, { useEffect, useState } from "react";
import MyInquiries, { MyInquiriesProps } from "@/src-containers/Overview/MyInquiries/MyInquiries";
import { DataCaseConfig, DataContent } from "@/src-model/client/InquiriesResponse";
import SbEditable from "storyblok-react";
import { StoryStaticType } from "@/utils/mysunrise-utils-types";
import { History } from 'history';
import I18n from 'src/utils/helper/I18n';
import BackButton from "@/components/general/BackButton/BackButton";
import DataLayerGtmService from "src/utils/DataLayer/DataLayerGtmService";
import { DataLayerGtmConstants } from "src/utils/DataLayer/DataLayerGtmConstants";

interface InquiryProps extends GenericSBProps, MyInquiriesProps { }

interface SBInquiriesProp {
  caseConfig: DataCaseConfig,
  caseType: string,
  hideCloseCaseSection: boolean
}

interface MyInquiryProps {
  caseList: DataContent[],
  caseType: string,
  hideCaseSection: boolean,
  history:History
}

interface InquiryType extends StoryStaticType {
  inquiries: SBInquiriesProp[]
}

const Inquiries = (props: InquiryProps): JSX.Element => {
  const { content } = props;
  const [myInquiryData, setMyInquiryData] = useState<InquiryType | null>(null);
  const [activeOpenTab, setActiveTab] = useState<boolean>(true);
  const params = getSlugname();
  useEffect(() => {
    (async () => {
      const response = await storyblokInstance.getPageContent(params);
      response.data.story.content.body.map((item: any) => {
        let MyInquiriesprops: SBInquiriesProp[] = [];
        let InquiriesList: SBInquiriesProp;
        let DataContentArr: DataContent[] = [];
        let cases: DataCaseConfig;
        item.inquiries.length > 0 &&
          item.inquiries.map((inquiry: MyInquiryProps) => {
            DataContentArr = [];
            inquiry.caseList.forEach((caseItem: DataContent) => {
              DataContentArr.push(caseItem);
              cases = {
                dataContent: DataContentArr
              }
              InquiriesList = {
                caseType: inquiry.caseType,
                hideCloseCaseSection: inquiry.hideCaseSection,
                caseConfig: cases
              }
            })
            MyInquiriesprops.push(InquiriesList);
            setMyInquiryData({
              ...item,
              inquiries: MyInquiriesprops,
              loadComponent: true
            })
          })
      })
    })();
  }, [])

  function switchTab(): void {
    DataLayerGtmService.addGtmDataLayer('', {
      event: DataLayerGtmConstants.event.GA_EVENT, event_name: DataLayerGtmConstants.event.bills.PAYMENT_NOTIFICATION_MY_REQUEST_POPUP,
      selection: !activeOpenTab ? I18n.translate('MyInquiries.Case.Open') : I18n.translate('MyInquiries.Case.Closed')
    });
    setActiveTab(!activeOpenTab);
  }

  const handleBack = () => {
    history.back();
  };

  return (
    <>
      <SbEditable content={content}>
        <div data-component='Inquiries'>
          <div className='l-center-xxl'>
            <div className='s20-section-title s20-section-title--full-width s20-section-title--darker'>
              {' '}
              <h2 className='s20-section-title__heading'>
                {' '}
               <BackButton  action={handleBack}><I18n code='MyOrderList.Label.Button.Back' /></BackButton>
                {I18n.translate('MyInquiries.Header.Title')}
              </h2>
              <div className='vertical_spacer x32'></div>
            </div>
            <div className='s20-spacer s20-spacer--x8'></div>
            <div className='richtext richtext-center'>
              {I18n.translate('MyInquiries.Header.Content')}
            </div>
            <div className='s20-spacer s20-spacer--x52 is-hidden-mobile'></div>
            <div className='s20-spacer s20-spacer--x36 is-visible-mobile'></div>
            <div className='l-center-m'>
              <div className='tabs_nav_v2 js-tabs_nav no-margin tabs_nav_v2-default tabs_nav_v2-default--full-width tabs_nav_v2-default--left'>
                <ul className='tabs_nav_v2--list js-tabs_nav--list'>
                  <li role='presentation' style={{ width: '50%' }}>
                    <a
                      className={
                        activeOpenTab ? 'tabs_nav_v2--link is-active' : 'tabs_nav_v2--link'
                      }
                      id='tab-0'
                      onClick={() => switchTab()}
                    >
                      <span className='tabs_nav_v2--link--inner'>
                        <span className='tabs_nav_v2--link--inner--content'>
                          <span className='tabs_nav_v2--link--title'>
                            {I18n.translate('MyInquiries.Case.Open')}
                          </span>
                        </span>
                      </span>
                    </a>
                  </li>
                  <li style={{ width: '50%' }}>
                    <a
                      className={
                        activeOpenTab ? 'tabs_nav_v2--link' : 'tabs_nav_v2--link is-active'
                      }
                      id='tab-1'
                      onClick={() => switchTab()}
                    >
                      <span className='tabs_nav_v2--link--inner'>
                        <span className='tabs_nav_v2--link--inner--content'>
                          <span className='tabs_nav_v2--link--title'>
                            {I18n.translate('MyInquiries.Case.Closed')}
                          </span>
                        </span>
                      </span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div className='s20-spacer s20-spacer--x40 is-hidden-mobile'></div>
            <div className='s20-spacer s20-spacer--x24 is-visible-mobile'></div>
            <div className='l-center-m'>
              {myInquiryData &&
              myInquiryData.inquiries &&
              myInquiryData.loadComponent &&
              myInquiryData.inquiries?.length >= content.inquiries.length ? (
                <MyInquiries
                  {...{
                    ...props,
                    ...{ inquiryDetails: myInquiryData.inquiries, activeOpenTab: activeOpenTab },
                  }}
                />
              ) : (
                <></>
              )}
            </div>
          </div>
        </div>
      </SbEditable>
    </>
  );
}
export default Inquiries
