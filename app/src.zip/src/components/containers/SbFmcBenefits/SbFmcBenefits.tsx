import React, { useEffect, useState } from 'react';
import { GenericSBProps } from "@/components/index";
import { HashRouter as Router, Switch, Route } from 'react-router-dom';
import EditFmcBenefits, { EditFmcBenefitsProps } from '@/src-components/FmcBenefits/EditFmcBenefits/EditFmcBenefits';
import FmcBenefitsOverview, { FmcBenefitsOverviewProps } from '@/src-components/FmcBenefits/FmcBenefitsOverview/FmcBenefitsOverview';
import SbEditable from 'storyblok-react';
import StaticWrapperComponent, { StaticSectionProps } from '@/components/general/StaticWrapper';
import storyblokInstance from '@/utils/StoryblokService';
import { getSlugname } from '@/utils/Utils';
import { StoryStaticType } from '@/utils/mysunrise-utils-types';

interface FmcBenefitsProps extends GenericSBProps, EditFmcBenefitsProps,
  FmcBenefitsOverviewProps {
  FmcBenefits: FmcBenefitsProps
}

const SbFmcBenefits = (dataProps: FmcBenefitsProps): JSX.Element => {
  const { content } = dataProps;
  const [fmcBenefitsData, setFmcBenefitsData] = useState<StoryStaticType | null>({
    staticSection: [],
    loadComponent: false
  });
  const params = getSlugname();
  useEffect(() => {
    (async () => {
      const response = await storyblokInstance.getPageContent(params);
      response.data.story.content.body.map((item: StoryStaticType) => {
        setFmcBenefitsData({
          ...item,
          staticSection: item.staticSection,
          loadComponent: true
        });
      });
    })();
  }, []);

  return (
    <>
      <SbEditable content={content}>
        <div data-component="FmcBenefits">
          {fmcBenefitsData && fmcBenefitsData.staticSection &&
            fmcBenefitsData.staticSection.map((staticContent: StaticSectionProps) => (
              <StaticWrapperComponent content={staticContent} />
            ))}

          {process.browser && fmcBenefitsData && fmcBenefitsData.loadComponent &&
            <Router>
              <Switch>
                <Route exact path='/:category' component={(props: EditFmcBenefitsProps) => <EditFmcBenefits {...props} />} />
                <Route path='*' component={(props: FmcBenefitsOverviewProps) => <FmcBenefitsOverview {...props} />} />
              </Switch>
            </Router>}
        </div>
      </SbEditable>
    </>
  )
}

export default SbFmcBenefits;
