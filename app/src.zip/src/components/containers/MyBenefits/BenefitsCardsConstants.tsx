
export interface Map<T> {
    [key: string]: T;
  }

  export enum BenefitsOffersConstants {
    TV_BENEFIT= 'TV XL Benefit',
    SMART_WI_FI_BENEFITS = 'Smart WiFi Benefit',
    SUNRISE_UP_BENEFIT= 'Sunrise Up Benefit',
    FAMILY_UPGRADE = 'We Benefit family calls eu&us',
    SIM_CARD = 'SimCard',
  }

  export enum BenefitsCardsType {
    MULTI_MOBILE_DISCOUNT = 'Multi Mobile Discount',
    UP_BENEFIT_DISCOUNT = 'Up Benefit discount',
    FAMILY_CALL_UPGRADE = 'Family Call upgrade',
    MOBILE_DATA_EXTRA_SIM = 'Mobile Data - Extra SIM',
    SMART_WI_FI = 'Smart Wi-Fi - Connect Pods',
    FREE_TV_UPGRADE = 'Free TV Upgrade',
    RECOMMENDATION_REWARD = 'Recommendation reward',
    SUNRISE_MOMENTS = 'Sunrise Moments',
    MOBILE_SPEED_UPGRADE = 'Mobile speed upgrade',
    MOBILE_POSTPAID = 'MOBILE_POSTPAID'
  }

  export enum BenefitsOfferIconType {
    TOPDEAL_MOBILE = 'mobile',
    TOPDEAL_DEVICE = 'devices',
    TOPDEAL_INTERNET = 'internet',
    TOPDEAL_TV = 'tv',
    TOPDEAL_ALL = 'all',
    TOPDEAL_FREETV = 'freeTV',
    TOPDEAL_MOMENTS = 'moments',
    TOPDEAL_REWARD = 'reward',
  }

  export enum BenefitsDescriptionIcon {
    TOPDEAL_GIFT = 'gift',
    TOPDEAL_NOTE = 'note',
    TOPDEAL_DISCOUNT = 'discount',
    TOPDEAL_ARROW = 'arrow',
    TOPDEAL_FREETV = 'freeTV',
    TOPDEAL_INFO = 'info',
    TOPDEAL_REWARD = 'reward',
    TOPDEAL_MOMENTS = 'moments',
    TOPDEAL_TICKET = 'ticket',
    TOPDEAL_WIFI = 'wifi',
    TOPDEAL_MULTI_MOBILE = 'multimobile',
    TOPDEAL_CALL = 'call',
    TOPDEAL_WATCH = 'watch',
    TOPDEAL_SIM = 'sim',
    TOPDEAL_MOBILE = 'mobile'
  }