import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators, Dispatch, ActionCreatorsMapObject } from 'redux';
import { SbEditableContent } from 'storyblok-react';
import { FmcBenefitsResponse } from '../../../../../src/model/client/Subscription/FmcBenefitsResponse';
import { fetchFmcBenefits } from '../../../../../src/components/FmcBenefits/FmcBenefitsAction';
import { Query, Account } from '../../../../../src/model/types.d';
import { fetchDashboard } from '../../../../../src/containers/Overview/Dashboards/DashboardsAction';
import { Title, MainTextDescription, TextMark, OfferDescription, OfferListDescription, Content, ButtonLink, OfferCard, OfferCards, BenefitsService } from './BenefitsCardsService';
import I18n from 'src/utils/helper/I18n';
import { Loader } from '../../../../../src/components/Loader/Loader';
import { LoaderType } from '../../../../../src/components/Loader/LoaderType.enum';
import { DataLayerGtmConstants } from 'src/utils/DataLayer/DataLayerGtmConstants';
import DataLayerGtmService from '../../../../../src/utils/DataLayer/DataLayerGtmService';
import {fetchSubscriptions} from '../../../../../src/containers/Subscriptions/SubscriptionsAction';

export interface BenefitsCardsProps {
    content: SbEditableContent,
    fmcBenefits?: FmcBenefitsResponse[],
    fetchFmcBenefits?: () => void,
    fetchDashboard?: () => void;
    dashboardsData?: Query;
    fetchSubscriptions?: () => void;
    account?: Account;
}

interface BenefitsCardsState {
    selectedBenefit: string[];
    showDropDownList: boolean;
    benefitsStatus: number;
    isLoading: boolean;
}

class BenefitsCards extends React.Component<BenefitsCardsProps, BenefitsCardsState> {
    constructor(props: BenefitsCardsProps) {
        super(props);
        this.state = {
            selectedBenefit: [],
            showDropDownList: false,
            benefitsStatus: 0,
            isLoading: true
        };
    }

    static getDerivedStateFromProps(nextProps: BenefitsCardsProps, prevState: BenefitsCardsState): any | null {
        if (!!nextProps.dashboardsData && !!nextProps.fmcBenefits && prevState.isLoading) {
            return { isLoading: false }
        }
        return null
    }

    componentDidMount(): void {
        const { fetchFmcBenefits, dashboardsData, fetchDashboard, account, fetchSubscriptions } = this.props;
        if (!dashboardsData && fetchDashboard) {
            fetchDashboard();
        }
        if (fetchFmcBenefits) {
            fetchFmcBenefits();
        }
        if (!account && fetchSubscriptions) {
            fetchSubscriptions();
        }
    }

    clickEvent = (option: string) => {
        const { selectedBenefit } = this.state;
        let selectedCard: string[] = selectedBenefit;
        if (!!option && !selectedBenefit.includes(option)) {
            selectedCard.push(option)
        } else if (selectedBenefit.includes(option)) {
            selectedCard = selectedCard.filter((card: string) => card !== option)
        };
        DataLayerGtmService.addGtmDataLayer('', {
          event: DataLayerGtmConstants.event.GA_EVENT,
          event_name: DataLayerGtmConstants.benefitsOption.FILTER_BENEFITS,
          click_text: selectedCard.join('|')
        });
        this.setState({ selectedBenefit: selectedCard })
    };

    showBoldContent = (textDescription: MainTextDescription) => {
        if (!!textDescription?.marks) {
            return (
                textDescription?.marks.map((mark: TextMark) => {
                    return (
                        <>
                            {mark?.type ===
                                'bold' ? (
                                <strong style={{ fontWeight: 'bold' }}>
                                    {
                                        textDescription.text
                                    }
                                </strong>
                            ) : textDescription.text}
                        </>
                    )
                })
            )
        } else {
            return (textDescription.text)
        }
    }

    showContentFeatures = (card: OfferCard) => {
        return (
            <ul className='deal-card__features'>
                {card?.offersList.map((offersList: OfferListDescription) => {
                    const offerListIcon: string = BenefitsService.getOfferIconClass(offersList.icon) || '';
                    return (
                        <li className='deal-card__features-item'>
                            <div className='deal-card__features-media'>
                                <i className={offerListIcon} />
                            </div>
                            {offersList?.text?.content.map((content: Content) => {
                                return (
                                    <div className='deal-card__features-content'>
                                        {content?.content.map((text: MainTextDescription) => {
                                            return (
                                                this.showBoldContent(text)
                                            );
                                        }
                                        )}
                                    </div>
                                );
                            }
                            )}
                        </li>
                    );
                }
                )}
            </ul>
        )
    }

    benefitCardAction = (card: OfferCard): JSX.Element | null => {
        const { fmcBenefits, dashboardsData, account } = this.props;
        const buttonName: string = card?.button[0]?.buttonLabel || '';
        const cardLink: ButtonLink = card?.button[0]?.buttonLink;
        const redirectingLink: string = BenefitsService.getRedirectingLinks(card?.offerType, cardLink, fmcBenefits, dashboardsData, account);
        const cardName: string = card?.title[0].text || '';
        if (redirectingLink !== '') {
            return (
                <div className='deal-card__button'>
                    <a className='s20-button s20-button--text' onClick={() => this.triggerRedirectionAnalytics(redirectingLink, cardName)}>{buttonName}
                        <span className='s20-button__icon s20-button__icon--after'>
                            <i className='s20-icon icon-fds--standard-chevron-right-red' />
                        </span>
                    </a>
                </div>
            )
        }
        return null
    }

    generalBenefitsDescription = (card: OfferCard) => {
        return (
            <div className='deal-card__customer deal-card__customer-not-subscribed'>
                {card?.benefitsDescription?.map((desc: OfferDescription) => {
                    return (<>
                        <div className='deal-card__customer-icon'>
                            <i className={desc?.icon?.filename} />
                        </div>
                        {desc?.text?.content?.map((content: Content) => {
                            return (
                                <div className='deal-card__customer-msg'>
                                    {content?.content?.map((desciption: MainTextDescription) => {
                                        return (
                                            this.showBoldContent(desciption)
                                        );
                                    })}
                                </div>
                            )
                        })}
                    </>)
                })}
            </div>
        )
    }

    getBenefitsContent = (card: OfferCard) => {
        return (
            <div className='deal-card__content'>
                <div className='deal-card__icons'>
                    <div className='deal-card__icons-content'>
                        {card?.offerIcons.map((offerIcon: string) => {
                            const dealCardImg: string = BenefitsService.renderImageClassName(offerIcon) || '';
                            return (
                                <div className='deal-card__icons-item'>
                                    <div className={dealCardImg} />
                                </div>
                            );
                        }
                        )}
                    </div>
                </div>
                {card?.title?.map((title: Title) => {
                    return (
                        <h3 className='deal-card__title'>
                            <span className='deal-card__title-label'>
                                {title.text}
                            </span>
                        </h3>
                    )
                })}
                {card?.description?.map((desc: OfferDescription) => {
                    return (<>
                        {desc?.text?.content?.map((content: Content) => {
                            return (
                                <div className='deal-card__description'>
                                    {content?.content?.map((desciption: MainTextDescription) => {
                                        return (
                                            <p>{desciption?.text || ''}</p>
                                        )
                                    })}
                                </div>
                            )
                        })}
                    </>)
                })}
                {this.showContentFeatures(card)}
                {this.generalBenefitsDescription(card)}
                {this.benefitCardAction(card)}
            </div>

        )
    }

    showBenefitCards = (card: OfferCard, highlightedTags:string[]): JSX.Element => {
        const benefitsTags: string[] = card?.BenefitsTags?.split(',');
        return (
            <div className='l-teaserrow--item'>
                <div className='deal-card deal-card--active'>
                    <div className='deal-card__box'>
                        <div className='deal-card__media'>
                            <div className='deal-card__media-placeholder' />
                            <img className='deal-card__media-img' src={card.image.filename} />
                        </div>
                        {this.getBenefitsContent(card)}
                        <div className='deal-card__footer'>
                            {benefitsTags?.map((benefitsOption: string) => {
                                return (
                                    <div className={`s20-product-status s20-product-status--small s20-product-status--no-icon s20-product-status--secondary ${highlightedTags.includes(benefitsOption) ? 's20-product-status--discount' : 's20-product-status--free'}`}>{benefitsOption}
                                    </div>
                                )
                            })}
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    setDropDownList = () => {
        const { showDropDownList } = this.state;
        this.setState({ showDropDownList: !showDropDownList })
    }

    triggerRedirectionAnalytics = (redirectionUrl: string, title: string) => {
        return (
        DataLayerGtmService.addGtmDataLayer('', {
          event: DataLayerGtmConstants.event.GA_EVENT,
          event_name: DataLayerGtmConstants.event.SELECT_PROMOTION,
          banner_promotion_name: title
        }),
        window.open(`${redirectionUrl}`, '_self')
        )
    }

    setBenefitStatus = (filterTitle: string, index: number, ) => {
        DataLayerGtmService.addGtmDataLayer('', {
          event: DataLayerGtmConstants.event.GA_EVENT,
          event_name: DataLayerGtmConstants.event.TAB_CLICK,
          click_text: filterTitle
        });
        this.setState({ benefitsStatus: index })
    }

    renderBenefitsPage = (): JSX.Element => {
        const { content, fmcBenefits, account } = this.props;
        const { selectedBenefit, showDropDownList, benefitsStatus } = this.state;
        const benefitsHeaders: string[] = content?.content?.benefitsHeaders?.split(',');
        const benefitsFilterList: string[] = content?.content?.BenefitsFilterList?.split(',');
        const highlightedTags: string[] = content?.content?.HighlightedTags?.split(',');
        return (
            <div className='l-center-xxl l-center-sds'>
                <div className='l-center-xl'>
                    <div className='tabs_nav_v2 js-tabs_nav tabs_nav_v2-default'>
                        <ul className='tabs_nav_v2--list js-tabs_nav--list'>
                            {benefitsHeaders?.map((filterTitle: string, index: number) => {
                                return (
                                    <li role='presentation'>
                                        <a className={`tabs_nav_v2--link ${benefitsStatus === index ? 'is-active' : ''}`} onClick={() => this.setBenefitStatus(filterTitle,index)} id='tab-0'>
                                            <span className='tabs_nav_v2--link--inner'>
                                                <span className='tabs_nav_v2--link--inner--content'>
                                                    <span className='tabs_nav_v2--link--title'>
                                                        {filterTitle}
                                                    </span>
                                                </span>
                                            </span>
                                        </a>
                                    </li>
                                )
                            })}
                        </ul>
                    </div>
                </div>
                <div className='s20-spacer s20-spacer--x40' />
                <div className='filter-chips'>
                    <div className='filter-chips__field-container'>
                        <div className={`filter-chips__field ${showDropDownList ? 'is-active' : ''} ${selectedBenefit.length > 0 ? 'filter-chips__field--has-selected-values' : ''}`} onClick={() => this.setDropDownList()}>
                            <div className='filter-chips__field-label'>
                                <I18n code='BenefitsCards.Filter.Label' />
                            </div>
                            <div className='filter-chips__field-value'>
                                {selectedBenefit.toString()}
                            </div>
                        </div>
                        <div className='filter-chips__list'>
                            {benefitsFilterList?.map((Option: string) => {
                                const isItemSelected: boolean = selectedBenefit?.some((benefit: string) => benefit === Option);
                                return (
                                    <div className={`filter-chips__list-item ${isItemSelected ? 'is-checked' : ''}`} data-option-value={Option}
                                        onClick={() => this.clickEvent(Option)}>
                                        {Option}
                                    </div>
                                )
                            })}
                        </div>
                    </div>
                    {/* js-filter-chips__chips js-filter-chips__chip-item*/}
                    <div className='filter-chips__chips'>
                        {selectedBenefit?.map((benefitCard: string) => {
                            return (
                                <div className='filter-chips__chip-item' onClick={() => this.clickEvent(benefitCard)}>
                                    {benefitCard}
                                </div>
                            )
                        })}
                    </div>
                    <div className='s20-spacer s20-spacer--x32' />
                    <div className='l-teaserrow l-teaserrow--masonry has-3' >
                        {content?.content?.OfferCard.map((offercard: OfferCards) => {
                            const activatedBenefits: OfferCard[] = BenefitsService.getActivationBenefits(offercard, fmcBenefits, true, account);
                            const unactivatedBenefits: OfferCard[] = BenefitsService.getActivationBenefits(offercard, fmcBenefits, false, account);
                            const eligibleBenefits: OfferCard[] = BenefitsService.getEligibleBenefits(fmcBenefits, offercard);
                            const benefits: OfferCard[] = (benefitsStatus === 2) ? activatedBenefits : (benefitsStatus === 1) ? unactivatedBenefits : eligibleBenefits;
                            const benefitCards: OfferCard[] = benefits?.filter((benefitCard: OfferCard) => selectedBenefit.length > 0 ?
                                    BenefitsService.getBenefitsCards(benefitCard, selectedBenefit) : eligibleBenefits);
                            if (benefitCards.length > 0) {
                                return (<>
                                    {benefitCards.map((card: OfferCard) => {
                                        return (
                                            this.showBenefitCards(card,highlightedTags)
                                        )
                                    })}
                                </>)
                            } else {
                                return (
                                    <div>
                                        <h2>
                                            <I18n code='BenefitsCards.EmptyBenefits.Label' />
                                        </h2>
                                    </div>
                                )
                            }
                        })}
                    </div>
                </div>
            </div>
        )
    }

    render(): React.ReactNode {
        const { isLoading } = this.state;
        if (isLoading) {
            return <>
                <div className='s20-spacer s20-spacer--x40' />
                <Loader height={200} type={LoaderType.LIGHT} />
            </>
        }
        return (
            <React.Fragment>
                {this.renderBenefitsPage()}
            </React.Fragment>
        );
    }
}

const mapStateToProps: any = ({ fmcBenefitsReducer, dashboardsReducer, subscriptionsReducer }: any) => {
    return {
        fmcBenefits: fmcBenefitsReducer.fmcBenefits,
        dashboardsData: dashboardsReducer.dashboardsData,
        account: subscriptionsReducer.account,

    };
};
const mapDispatchToProps: ((dispatch: Dispatch) => ActionCreatorsMapObject) = (dispatch) => {
    return bindActionCreators({ fetchFmcBenefits, fetchDashboard, fetchSubscriptions }, dispatch);
};

export default connect<BenefitsCardsProps>(mapStateToProps, mapDispatchToProps)(BenefitsCards);
