import { BenefitsCardsType, BenefitsOffersConstants, BenefitsOfferIconType, BenefitsDescriptionIcon } from "./BenefitsCardsConstants";
import { FmcBenefitsResponse } from '../../../../../src/model/client/Subscription/FmcBenefitsResponse'
import { Query, Service, Optional, Account } from '../../../../../src/model/types.d';
import { Asset } from "@/utils/storyblok-types";

export interface OfferCards {
    offerCard: OfferCard[];
}
export interface OfferCard {
    benefitOptions: string[];
    BenefitsTags: string;
    image: Image;
    offerIcons: string[];
    title: Title[];
    description: OfferDescription[];
    offersList: OfferListDescription[];
    button: Button[];
    offerType: string;
    benefitsDescription: OfferDescription[];
}

export interface Button {
    buttonLabel: string;
    buttonLink: ButtonLink;
}

export interface ButtonLink {
    cached_url: string;
}

export interface OfferListDescription {
    icon: string;
    text: TextContent;
}

export interface OfferDescription {
    icon: Asset;
    text: TextContent;
}

export interface TextContent {
    content: Content[];
}

export interface Content {
    content: MainTextDescription[];
}

export interface MainTextDescription {
    text: string;
    marks: TextMark[];
}

export interface TextMark {
    type: string;
}

export interface Title {
    text: string;
}
export interface Image {
    filename: string;
}

class BenefitsCardsService {

    renderImageClassName = (offerIcon: string): string | null => {
        if (offerIcon === BenefitsOfferIconType.TOPDEAL_MOBILE) {
            return (
                'deal-card__icons-img deal-card__icons-img--mobile'
            )
        } else if (offerIcon === BenefitsOfferIconType.TOPDEAL_DEVICE) {
            return (
                'deal-card__icons-img deal-card__icons-img--device'
            )
        } else if (offerIcon === BenefitsOfferIconType.TOPDEAL_INTERNET) {
            return (
                'deal-card__icons-img deal-card__icons-img--internet'
            )
        } else if (offerIcon === BenefitsOfferIconType.TOPDEAL_TV) {
            return (
                'deal-card__icons-img deal-card__icons-img--tv'
            )
        } else if (offerIcon === BenefitsOfferIconType.TOPDEAL_FREETV) {
            return (
                'deal-card__icons-img deal-card__icons-img--tv-xl'
            )
        } else if (offerIcon === BenefitsOfferIconType.TOPDEAL_MOMENTS) {
            return (
                'deal-card__icons-img deal-card__icons-img--up-benefit'
            )
        } else if (offerIcon === BenefitsOfferIconType.TOPDEAL_REWARD) {
            return (
                'deal-card__icons-img deal-card__icons-img--reward'
            )
        } else if (offerIcon === BenefitsOfferIconType.TOPDEAL_ALL) {
            return (
                'deal-card__icons-img deal-card__icons-img--tv deal-card__icons-img deal-card__icons-img--internet deal-card__icons-img deal-card__icons-img--device deal-card__icons-img deal-card__icons-img--mobile'
            )
        } else {
            return null
        }
    }

    getOfferIconClass = (offerIcon: string): string | null => {
        if (offerIcon === BenefitsDescriptionIcon.TOPDEAL_GIFT) {
            return (
                'deal-card__features-img deal-card__features-img--gift'
            )
        } else if (offerIcon === BenefitsDescriptionIcon.TOPDEAL_NOTE) {
            return (
                'deal-card__features-img deal-card__features-img--note'
            )
        } else if (offerIcon === BenefitsDescriptionIcon.TOPDEAL_DISCOUNT) {
            return (
                'deal-card__features-img deal-card__features-img--discount'
            )
        } else if (offerIcon === BenefitsDescriptionIcon.TOPDEAL_ARROW) {
            return (
                'deal-card__features-img deal-card__features-img--arrow'
            )
        } else if (offerIcon === BenefitsDescriptionIcon.TOPDEAL_FREETV) {
            return (
                'deal-card__icons-img deal-card__icons-img--tv-xl'
            )
        } else if (offerIcon === BenefitsDescriptionIcon.TOPDEAL_REWARD) {
            return (
                'deal-card__icons-img deal-card__icons-img--reward'
            )
        } else if (offerIcon === BenefitsDescriptionIcon.TOPDEAL_MOMENTS) {
            return (
                'deal-card__icons-img deal-card__icons-img--up-benefit'
            )
        } else if (offerIcon === BenefitsDescriptionIcon.TOPDEAL_INFO) {
            return (
                's20-icon s20-icon--info-circle-outline-dark-grey'
            )
        } else if (offerIcon === BenefitsDescriptionIcon.TOPDEAL_WIFI) {
            return (
                'deal-card__features-img deal-card__features-img--wifi-up'
            )
        } else if (offerIcon === BenefitsDescriptionIcon.TOPDEAL_TICKET) {
            return (
                'deal-card__features-img deal-card__features-img--ticket'
            )
        } else if (offerIcon === BenefitsDescriptionIcon.TOPDEAL_MULTI_MOBILE) {
            return (
                'deal-card__features-img deal-card__features-img--mobile-up-multi'
            )
        } else if (offerIcon === BenefitsDescriptionIcon.TOPDEAL_CALL) {
            return (
                'deal-card__features-img deal-card__features-img--phone-call'
            )
        } else if (offerIcon === BenefitsDescriptionIcon.TOPDEAL_WATCH) {
            return (
                'deal-card__features-img deal-card__features-img--watch-device'
            )
        } else if (offerIcon === BenefitsDescriptionIcon.TOPDEAL_SIM) {
            return (
                'deal-card__features-img deal-card__features-img--sim-cards'
            )
        } else if (offerIcon === BenefitsDescriptionIcon.TOPDEAL_MOBILE) {
            return (
                'deal-card__features-img deal-card__features-img--mobile-device'
            )
        } else {
            return null
        }
    }

    isBenefitEligible = (benefits: FmcBenefitsResponse, isBenefitInstalled: boolean): boolean => {
        const isEligible: boolean = benefits?.products?.some((product: any) => product.benefitInstalled === isBenefitInstalled) || (benefits.maxAllowed > benefits.alreadyUsed) || false;
        return isEligible
    }

    isBenefitEligibleUninstalled = (benefits: FmcBenefitsResponse, isBenefitInstalled: boolean): boolean => {
        const isEligible: boolean = benefits?.products?.some((product: any) => product.benefitInstalled === isBenefitInstalled) && (benefits.maxAllowed > benefits.alreadyUsed) || false;
        return isEligible
    }

    isInstalledBenefit = (offerDetails: FmcBenefitsResponse[] | undefined, benefitName: string): boolean => {
        const isEligible: boolean = offerDetails?.some((benefits: FmcBenefitsResponse) => benefits.name === benefitName && benefits?.products?.some((product: any) => !!product.benefitInstalled)) || false;
        return isEligible
    }

    getActivationBenefits = (offerCards: OfferCards, offerDetails: FmcBenefitsResponse[] | undefined, isActivated: boolean, subscriptionAccount: Account | undefined) => {
        let activatedBenefits: OfferCard[] = [];
        const isMobileRatePlan: boolean = subscriptionAccount?.services?.some((service: Optional<Service>) => service?.ratePlans?.some((ratePlan: any) => ratePlan.type === BenefitsCardsType.MOBILE_POSTPAID) && service?.slaveServices?.some((slaveService: any) => slaveService?.simCard?.__typename === BenefitsOffersConstants.SIM_CARD)) || false;
        const isMobileDiscount: boolean = subscriptionAccount?.services?.some((service: Optional<Service>) => service?.ratePlans?.some((ratePlan: any) => !!ratePlan.discount && ratePlan.type === BenefitsCardsType.MOBILE_POSTPAID)) || false;

        offerCards?.offerCard.forEach((offerCard: OfferCard) => {
            const isFamilyBenefitEligible: boolean = this.isInstalledBenefit(offerDetails, BenefitsOffersConstants.FAMILY_UPGRADE);
            const isSmartBenefitEligible: boolean = this.isInstalledBenefit(offerDetails, BenefitsOffersConstants.SMART_WI_FI_BENEFITS);
            const isUpBenefitActivated: boolean = this.isInstalledBenefit(offerDetails, BenefitsOffersConstants.SUNRISE_UP_BENEFIT);
            const isTvBenefitActivated: boolean = this.isInstalledBenefit(offerDetails, BenefitsOffersConstants.TV_BENEFIT);
            const isUpBenefitEligible: boolean = offerDetails?.some((benefits: FmcBenefitsResponse) => benefits.name === BenefitsOffersConstants.SUNRISE_UP_BENEFIT && !isUpBenefitActivated && this.isBenefitEligibleUninstalled(benefits, false)) || false;
            const isTvBenefitEligible: boolean = offerDetails?.some((benefits: FmcBenefitsResponse) => benefits.name === BenefitsOffersConstants.TV_BENEFIT && !isTvBenefitActivated && this.isBenefitEligibleUninstalled(benefits, false)) || false;
            if (offerCard?.offerType === BenefitsCardsType.MULTI_MOBILE_DISCOUNT && ((isActivated && isMobileDiscount) || (!isActivated && !isMobileDiscount))) {
                activatedBenefits.push(offerCard)
            }
            if (offerCard?.offerType === BenefitsCardsType.MOBILE_DATA_EXTRA_SIM && ((isActivated && isMobileRatePlan) || (!isActivated && !isMobileRatePlan))) {
                activatedBenefits.push(offerCard)
            }
            if (offerCard?.offerType === BenefitsCardsType.FAMILY_CALL_UPGRADE && ((isActivated && isFamilyBenefitEligible) || (!isActivated && !isFamilyBenefitEligible))) {
                activatedBenefits.push(offerCard)
            }
            if (offerCard?.offerType === BenefitsCardsType.SMART_WI_FI && ((isActivated && isSmartBenefitEligible) || (!isActivated && !isSmartBenefitEligible))) {
                activatedBenefits.push(offerCard)
            }
            if (offerCard?.offerType === BenefitsCardsType.UP_BENEFIT_DISCOUNT && ((isActivated && isUpBenefitActivated) || (!isActivated && isUpBenefitEligible))) {
                activatedBenefits.push(offerCard)
            }
            if (offerCard?.offerType === BenefitsCardsType.FREE_TV_UPGRADE && ((isActivated && isTvBenefitActivated) || (!isActivated && isTvBenefitEligible))) {
                activatedBenefits.push(offerCard)
            }
        })
        return activatedBenefits;
    }

    getEligibleBenefits = (benefitsDetail: FmcBenefitsResponse[] | undefined, offerCards: OfferCards): OfferCard[] => {
        let eligibleBenefits: OfferCard[] = [];
        const isUpBenefitEligible: boolean = benefitsDetail?.some((benefits: FmcBenefitsResponse) => benefits.name === BenefitsOffersConstants.SUNRISE_UP_BENEFIT && this.isBenefitEligible(benefits, true)) || false;
        const isTvBenefitEligible: boolean = benefitsDetail?.some((benefits: FmcBenefitsResponse) => benefits.name === BenefitsOffersConstants.TV_BENEFIT && this.isBenefitEligible(benefits, true)) || false;
        if (!!benefitsDetail) {
            offerCards?.offerCard.forEach((offerCard: OfferCard) => {
                const upBenefitCardName: boolean = offerCard?.offerType === BenefitsCardsType.UP_BENEFIT_DISCOUNT;
                const tvCardName: boolean = offerCard?.offerType === BenefitsCardsType.FREE_TV_UPGRADE;
                const isReadOnlyTeaserEligible: boolean = (upBenefitCardName && isUpBenefitEligible) || (tvCardName && isTvBenefitEligible);
                if (!(upBenefitCardName || tvCardName) || isReadOnlyTeaserEligible) {
                    eligibleBenefits.push(offerCard)
                }
            })
        }
        return eligibleBenefits
    }


    getRedirectingLinks = (offerCard: string, buttonlink: ButtonLink, offerDetails: FmcBenefitsResponse[] | undefined, dashboardsData: Query | undefined, subscriptionAccount: Account | undefined): string => {
        const redirectingUrl: string[] = buttonlink?.cached_url.toString().split(',');
        const isUpMultiMobileEnabler = dashboardsData?.account?.services?.some((service: Optional<Service>) => service?.isUpMultiMobileEnabler) || false;
        if (offerCard === BenefitsCardsType.MULTI_MOBILE_DISCOUNT) {
            if (isUpMultiMobileEnabler) {
                return redirectingUrl[0]
            }
            return redirectingUrl[1]
        } else if (offerCard === BenefitsCardsType.MOBILE_DATA_EXTRA_SIM) {
            const isMobileRatePlan: boolean = subscriptionAccount?.services?.some((service: Optional<Service>) => service?.ratePlans?.some((ratePlan: any) => ratePlan?.type === BenefitsCardsType.MOBILE_POSTPAID)) || false;
            const isSimInstalled: boolean = isMobileRatePlan && subscriptionAccount?.services?.some((service: Optional<Service>) => service?.slaveServices?.some((slaveService: any) => slaveService?.simCard?.__typename === BenefitsOffersConstants.SIM_CARD)) || false;
            if (isMobileRatePlan) {
                if (isSimInstalled) {
                return redirectingUrl[0]
                }
                return redirectingUrl[2]
            }
            return redirectingUrl[1]
        } else if (offerCard === BenefitsCardsType.FAMILY_CALL_UPGRADE && offerDetails) {
            return this.getEligibilityUrl(offerDetails, BenefitsOffersConstants.FAMILY_UPGRADE, redirectingUrl);
        } else if (offerCard === BenefitsCardsType.SMART_WI_FI && offerDetails) {
            return this.getEligibilityUrl(offerDetails, BenefitsOffersConstants.SMART_WI_FI_BENEFITS, redirectingUrl);
        } else if (offerCard === BenefitsCardsType.RECOMMENDATION_REWARD || offerCard === BenefitsCardsType.SUNRISE_MOMENTS) {
            return redirectingUrl[0]
        } else if (offerCard === BenefitsCardsType.FREE_TV_UPGRADE || offerCard === BenefitsCardsType.UP_BENEFIT_DISCOUNT) {
            return ''
        }
        return ''
    }

    getEligibilityUrl = (offerDetails: FmcBenefitsResponse[], benefitName: string, redirectingUrl: string[]) => {
        const isInstalledUserEligible: boolean = offerDetails?.some((benefits: FmcBenefitsResponse) => benefits.name === benefitName && this.isBenefitEligible(benefits, true))
        const isUninstalledUserEligible: boolean = offerDetails?.some((benefits: FmcBenefitsResponse) => benefits.name === benefitName && this.isBenefitEligible(benefits, false))
        if (isInstalledUserEligible || isUninstalledUserEligible) {
            const eligibleUrl: string = isInstalledUserEligible ? redirectingUrl[0] : redirectingUrl[2];
            return eligibleUrl
        }
        return redirectingUrl[1]

    }

    getBenefitsCards = (benefitCard: OfferCard, selectedBenefit: string[]) => {
        const benefitsTags: string[] = benefitCard?.BenefitsTags.split(',');
        return benefitsTags?.some((options: string) => selectedBenefit.includes(options))
    }
}

export const BenefitsService: BenefitsCardsService = new BenefitsCardsService();