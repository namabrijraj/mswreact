import BenefitsCards from "./BenefitsCards";
import React from "react";
import SbEditable, { SbEditableContent } from "storyblok-react";

const benefitsTypes = (content: SbEditableContent): JSX.Element => {

  return (
    <>
      <SbEditable content={content}>
        <div data-component="MyBenefits">
          <BenefitsCards
          content={content} />
        </div>
      </SbEditable>
    </>
  );
};

export default benefitsTypes;