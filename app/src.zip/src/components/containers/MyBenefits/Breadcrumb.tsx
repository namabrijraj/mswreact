import React from "react";

const Breadcrumb = (content: any): JSX.Element => {
    const url: string = content?.content?.backNavigation?.cached_url || '';
    return (
        <nav className='s20-breadcrumbs' style={{background: 'none'}}>
            <div className='s20-breadcrumbs__container'>
                <ul className='s20-breadcrumbs__list' >
                    <li className='s20-breadcrumbs__item s20-breadcrumbs__item--only-item' >
                        <a className='s20-breadcrumbs__item--link' onClick={() => window.open(`${url}`, '_self')}>{content?.content?.breadcrumbName || ''}</a>
                    </li>
                </ul>
            </div>
        </nav>
    );
};
export default Breadcrumb;