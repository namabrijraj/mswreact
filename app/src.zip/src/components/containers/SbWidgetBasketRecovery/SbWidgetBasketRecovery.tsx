import SbEditable  from "storyblok-react";
import { GenericSBProps } from "@/components/index";
import WidgetBasketRecovery, { BasketRecoveryProps } from "@/src-components/BasketRecovery/WidgetBasketRecovery";
import React from "react";

interface WidgetBasketRecoveryProps extends GenericSBProps, BasketRecoveryProps {}

const SbWidgetBasketRecovery = (props: WidgetBasketRecoveryProps): JSX.Element => {
  const { content } = props;
  const teaserIcon = props.content.icon;

  return (
    <>
      <SbEditable content={content}>
        <div data-component="WidgetBasketRecovery">
          <WidgetBasketRecovery {...{ ...props, ...teaserIcon}} />
        </div>
      </SbEditable>
    </>
  );
};

export default SbWidgetBasketRecovery;