import React, { useEffect, useState } from 'react';
import { GenericSBProps } from '@/components/index';
import WebSheet, { WebSheetProps } from 'src/containers/WebSheet/WebSheet';
import SbEditable from "storyblok-react";
import storyblokInstance from "@/utils/StoryblokService";
import StaticWrapperComponent, { StaticSectionProps } from '@/components/general/StaticWrapper';
import { getSlugname } from '@/utils/Utils';
import { TokenProps } from '../WebsheetManageAccount/WebsheetManageAccount';
import { StoryStaticType } from '@/utils/mysunrise-utils-types';

interface DeviceActivate extends GenericSBProps, WebSheetProps {}

const DeviceActivation = (props: DeviceActivate): JSX.Element => {
	const { content } = props;
	const [deviceActivationContent, setDeviceActivationContent] = useState<StoryStaticType | null>({
		staticSection: [],
		loadComponent: false
	});
	const [mngactProp, setMngactProp] = useState<TokenProps | null>(null)
	const params = getSlugname();
	useEffect(() => {
		(async () => {
			const response = await storyblokInstance.getPageContent(params);
			response.data.story.content.body.map((item: StoryStaticType) => {
					setDeviceActivationContent({
						...item,
						staticSection: item.staticSection,
						loadComponent: true
					});

			});
		})();
		setMngactProp({
			tokenUrl: window.location.origin + window.location.pathname,
			type: 'widget'
		})
	}, []);

	return (
		<>
			<SbEditable content={content}>
				<div data-component="DeviceActivation">
					{deviceActivationContent && deviceActivationContent.loadComponent &&
						<>
							<WebSheet {... { ...props, ...mngactProp }} />
						{deviceActivationContent.staticSection &&
							deviceActivationContent.staticSection.map((staticContent: StaticSectionProps) => (
									<StaticWrapperComponent content={staticContent} />
								))
							}
						</>
					}

				</div>
			</SbEditable>
		</>
	)
}

export default DeviceActivation
