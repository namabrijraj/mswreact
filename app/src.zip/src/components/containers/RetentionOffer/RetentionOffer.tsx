import React, { useEffect, useState } from 'react';
import { GenericSBProps } from '@/components/index';
import storyblokInstance from '@/utils/StoryblokService';
import RetentionProductDetail, { RetentionProductDetailProps } from 'src/components/Retention/RetentionProductDetail/RetentionProductDetail';
import SbEditable from 'storyblok-react';
import StaticWrapperComponent, { StaticSectionProps } from '@/components/general/StaticWrapper';
import { getSlugname } from '@/utils/Utils';
import { StoryStaticType } from '@/utils/mysunrise-utils-types';

interface RetentionOfferProps extends GenericSBProps, RetentionProductDetailProps { }

const RetentionOffer = (props: RetentionOfferProps): JSX.Element => {
	const { content } = props;
	const [retentionData, setRetentionData] = useState<StoryStaticType | null>({
		staticSection: [],
		loadComponent: false
	});
	const params = getSlugname();

	useEffect(() => {
		(async () => {
			const response = await storyblokInstance.getPageContent(params);
			response.data.story.content.body.map((item: StoryStaticType) => {
				setRetentionData({
					...item,
					staticSection: item.staticSection,
					loadComponent: true
				});
			});
		})();
	}, []);

	return (
		<>
			<SbEditable content={content}>
				<div data-component="RetentionOffer">
					{retentionData && retentionData.loadComponent &&
						<>
							{retentionData.staticSection &&
								retentionData.staticSection.map((staticContent: StaticSectionProps) => (
									<StaticWrapperComponent content={staticContent} />
								))}
							<RetentionProductDetail {...props} />
						</>}
				</div>
			</SbEditable>
		</>
	)
}

export default RetentionOffer
