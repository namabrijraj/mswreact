import SbEditable from 'storyblok-react';
import { GenericSBProps } from '@/components/index';
import React, { useEffect, useState } from 'react';
import storyblokInstance from '@/utils/StoryblokService';
import { Route, HashRouter as Router, Switch } from 'react-router-dom';
import NotFound from '@/src-components/NotFound/NotFound';
import MobileMigrations, {
  MobileMigrationsProps,
} from '@/src-components/MobileMigration/MobileMigration';
import SecurityStatistics, {
  SecurityStatisticsProps,
} from '@/src-components/SecurityStatistics/SecurityStatistics';
import ConnectionTest, {
  ConnectionTestProps,
} from '@/src-containers/Subscription/ConnectionTest/ConnectionTest';
import ConnectionTestProcess, {
  ConnectionTestProcessProps,
} from '@/src-containers/Subscription/ConnectionTest/ConnectionTestProcess/ConnectionTestProcess';
import Subscription, { SubscriptionProps } from '@/src-containers/Subscription/Subscription';
import ManageBlockingSettings from '@/src-containers/Subscription/SubscriptionTabs/BlockingSettings/ManageBlockingSettings/ManageBlockingSettings';
import ChangeOwner, {
  ChangeOwnerProps,
} from '@/src-containers/Subscription/SubscriptionTabs/Contract/ChangeOwner/ChangeOwner';
import ChangeOwnerRCtoBC, {
  ChangeOwnerRCtoBCProps,
} from '@/src-containers/Subscription/SubscriptionTabs/Contract/ChangeOwner/ChangeOwnerRCtoBC/ChangeOwnerRCtoBC';
import ChangeUser, {
  ChangeUserProps,
} from '@/src-containers/Subscription/SubscriptionTabs/Contract/ChangeUser/ChangeUser';
import SingleSwitchSubscription, {
  SingleSwitchSubscriptionProps,
} from '@/src-containers/Subscription/SubscriptionTabs/Contract/SingleSwitchSubscription/SingleSwitchSubscription';
import SubscriptionConverter, {
  SubscriptionConverterProps,
} from '@/src-containers/Subscription/SubscriptionTabs/Contract/SubscriptionConverter/SubscriptionConverter';
import WireLineMigration, {
  WireLineMigrationProps,
} from '@/src-containers/Subscription/SubscriptionTabs/Contract/WireLineMigration/WireLineMigration';
import OverlayCostControl from '@/src-containers/Subscription/SubscriptionTabs/CostControlSettings/OverlayCostControl/OverlayCostControl';
import CostsView, {
  CostsViewProps,
} from '@/src-containers/Subscription/SubscriptionTabs/Costs/CostsView/CostsView';
import AddInsuranceOption from '@/src-containers/Subscription/SubscriptionTabs/HardwareAccessories/AddInsuranceOption/AddInsuranceOption';
import BuyHardwareReservationStatus from '@/src-containers/Subscription/SubscriptionTabs/HardwareAccessories/BuyHardware/BuyHardwareReservationStatus/BuyHardwareReservationStatus';
import BuyHardwareFlow from '@/src-containers/Subscription/SubscriptionTabs/HardwareAccessories/BuyHardware/BuyHardwareStepper/BuyHardwareFlow';
import DevicePlanExtension, {
  DevicePlanExtensionProps,
} from '@/src-containers/Subscription/SubscriptionTabs/HardwareAccessories/DevicePlanExtension/DevicePlanExtension';
import IndoorBoxLocation from '@/src-containers/Subscription/SubscriptionTabs/IndoorBox/IndoorBoxLocation/IndoorBoxLocation';
import IndoorBoxNumbers from '@/src-containers/Subscription/SubscriptionTabs/IndoorBox/IndoorBoxNumbers/IndoorBoxNumbers';
import OrderAccessChange, {
  OrderAccessChangeProps,
} from '@/src-containers/Subscription/SubscriptionTabs/LineSpeed/OrderAccessChange/OrderAccessChange';
import EditOptions, {
  EditOptionsProps,
} from '@/src-containers/Subscription/SubscriptionTabs/Options/EditOptions/EditOptions';
import ManageRoamingSettings from '@/src-containers/Subscription/SubscriptionTabs/RoamingSettings/ManageRoamingSettings/ManageRoamingSettings';
import ExtraSim from '@/src-containers/Subscription/SubscriptionTabs/Sim/ExtraSim/ExtraSim';
import MobileId from '@/src-containers/Subscription/SubscriptionTabs/Sim/MobileId/MobileId';
import SimRelink from '@/src-containers/Subscription/SubscriptionTabs/Sim/SimRelink/SimRelink';
import { SimRoutes } from '@/src-containers/Subscription/SubscriptionTabs/Sim/SimRoutes.enum';
import TvLogin, {
  TvLoginProps,
} from '@/src-containers/Subscription/SubscriptionTabs/TvLoginPassword/TvLogin/TvLogin';
import TvPassword, {
  TvPasswordProps,
} from '@/src-containers/Subscription/SubscriptionTabs/TvLoginPassword/TvPassword/TvPassword';
import WirelineDeviceUpgrade, {
  WirelineDeviceUpgradeProps,
} from '@/src-containers/Subscription/SubscriptionTabs/WirelineDevice/WirelineDeviceUpgrade/WirelineDeviceUpgrade';
import dynamic from 'next/dynamic';
import { getSlugname } from '@/utils/Utils';
import { HardwareManual, SubscriptionPageData } from '@/src-model/client/SubscriptionPageData';
import { TeaserItemProps } from '@/utils/mysunrise-utils-types';
import { MultiLink } from '@/utils/storyblok-types';
import { DashboardFallbackResponse } from '@/src-model/client/DashboardFallbackResponse';
import MigrationPendingOrder, { MigrationPendingOrderProps } from '@/src-components/MigrationPendingOrder/MigrationPendingOrder';
import OttMigration, { OttMigrationProps } from '@/src-containers/Subscription/SubscriptionTabs/Contract/OttMigration/OttMigration';

const ESimQr = dynamic(
  () => import('@/src-containers/Subscription/SubscriptionTabs/Sim/ESimQr/ESimQr'),
  {
    ssr: false,
  }
);

interface PageDataProps extends SubscriptionPageData {
  imageScanApp: string;
}

interface SubscriptionDetailProps extends GenericSBProps {
  dashboardFallback: DashboardFallbackResponse;
  pageData: PageDataProps;
}

interface HardwareLinks {
  path: MultiLink;
  title: string;
}

const SubscriptionDetail = (dataProps: SubscriptionDetailProps): JSX.Element => {
  const { content } = dataProps;
  const [aboDetailsData, setAboDetailsData] = useState<SubscriptionDetailProps | null>(null);
  const [loadComponent, setLoadComponent] = useState<boolean>(false);
  let teaserItem: TeaserItemProps;
  let pageData: PageDataProps;
  const dashboardFallback: TeaserItemProps[] = [];
  const params = getSlugname();
  let hardwareLinks: HardwareManual[] = [];
  useEffect(() => {
    dataProps.pageConfig.hardwareManualLinks.map((links: HardwareLinks) => {
      hardwareLinks.push({
        path: links.path.cached_url,
        code: links.title,
      });
    });
    pageData = {
      deviceHelpUrl: dataProps.pageConfig.deviceHelpUrl.url,
      voiceMailHelpUrl: dataProps.pageConfig.voiceMailHelpUrl.cached_url,
      contractCancellationUrl: dataProps.pageConfig.contractCancellationUrl.cached_url,
      mailBoxUrl: dataProps.pageConfig.urlMailBox.cached_url,
      includePromo: dataProps.pageConfig.includePromo,
      optionsPage: dataProps.pageConfig.optionsPage.cached_url,
      showPrivacy: dataProps.pageConfig.showPrivacy,
      privacyUrl: dataProps.pageConfig.privacyUrl.cached_url,
      indoorBoxHelpUrl: dataProps.pageConfig.indoorBoxHelpUrl.cached_url,
      imageScanApp: dataProps.pageConfig.imageScanApp.filename,
      hardwareManualLinks: {
        hardwareManuals: hardwareLinks,
      },
      imgRoamingCockpit: dataProps.pageConfig.roamingCockpitImage.filename,
      imgChangeUser: dataProps.pageConfig.changeUserImage.filename,
      imgLineSpeedFiber: dataProps.pageConfig.lineSpeedFiberImage.filename,
      imgChangePartner: dataProps.pageConfig.changePartnerImage.filename,
      imgHardwarePromotion: dataProps.pageConfig.hardwarePromotionImage.filename,
      imgAdditionalTv: dataProps.pageConfig.additionalTvImage.filename,
      imageForNoTv: dataProps.pageConfig.imageForNotTv.filename,
      imgLineSpeed: dataProps.pageConfig.lineSpeedImage.filename,
      accessChangeInformation: dataProps.pageConfig.accessChangeInformation,
    };
    (async () => {
      const response = await storyblokInstance.getPageContent(params);
      response.data.story.content.pageProperties.map((item: any) => {
        pageData.swapDeviceImage= item.swapDeviceImage
      })
      response.data.story.content.body.map((item: any) => {
        if (item.component === content.component) {
          {
            item.fallbackTeaserList &&
              item.fallbackTeaserList.map((item: any) => {
                teaserItem = {
                  productType: item.producttype,
                  title: item.title,
                  subtitle: item.subtitle,
                  text: item.text,
                  callToAction: item.callToAction,
                  linkPath: item.linkPath.cached_url,
                  target: item.target,
                  image: item.imageTeaser.filename,
                  imageAlt: item.imagealt,
                };
                dashboardFallback.push(teaserItem);
              });
          }
        }
        if (item.deviceConditionList) {
          pageData.deviceConditionList = item.deviceConditionList;
        }
        setAboDetailsData({
          ...item,
          dashboardFallback: dashboardFallback,
          pageData: pageData,
        });
        setLoadComponent(true);
      });
    })();
  }, []);

  return (
    <>
      <SbEditable content={content}>
        <div data-component='SubscriptionDetail'>
          {process.browser && loadComponent && (
            <Router>
              <Switch>
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/OrderAccessChange'
                  component={(props: OrderAccessChangeProps) => (
                    <OrderAccessChange {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/securityStatistics/:serviceId'
                  component={(props: SecurityStatisticsProps) => (
                    <SecurityStatistics {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/ConnectionTest'
                  component={(props: ConnectionTestProps) => (
                    <ConnectionTest {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/ConnectionTest/:processDefinitionId?'
                  component={(props: ConnectionTestProcessProps) => (
                    <ConnectionTestProcess {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/ViewRunningCosts'
                  component={(props: CostsViewProps) => (
                    <CostsView {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/eofOverlay/:parentSiteId/:discountPercentage/:contractPeriod?'
                  component={(props: SubscriptionProps) => (
                    <Subscription {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/UpgradeWirelineDevice/:code'
                  component={(props: WirelineDeviceUpgradeProps) => (
                    <WirelineDeviceUpgrade {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/SecurityStatistics/:serviceId'
                  component={(props: SecurityStatisticsProps) => (
                    <SecurityStatistics {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName'
                  component={(props: SubscriptionProps) => (
                    <Subscription {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/ManageBlockingSettings'
                  component={ManageBlockingSettings}
                />
                <Route
                  exact
                  path={`/:serviceId/:ratePlanName/${'(EditOptions|BuyOption)/:data?'}`}
                  component={(props: EditOptionsProps) => (
                    <EditOptions {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/SwitchSubscription/win'
                  component={(props: WireLineMigrationProps) => (
                    <WireLineMigration {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/SwitchSubscription/OttMigration/update'
                  component={(props: OttMigrationProps) => (
                    <OttMigration {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path={`/:serviceId/:ratePlanName/SwitchSubscription/${'(MobilePack|MobileYoungMigration)'}`}
                  component={(props: MobileMigrationsProps) => (
                    <MobileMigrations {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path={`/:serviceId/:ratePlanName/SwitchSubscription/SingleSubscription/${'(MobileMigration|MobileYoungMigration)'}`}
                  component={(props: SingleSwitchSubscriptionProps) => (
                    <SingleSwitchSubscription {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path={`/:serviceId/:ratePlanName/SwitchSubscription/SingleSubscription/${'(MobileMigration|MobileYoungMigration)/PendingOrder'}`}
                  component={(props: MigrationPendingOrderProps) => (
                    <MigrationPendingOrder {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/SwitchSubscription/SingleSubscription'
                  component={(props: SingleSwitchSubscriptionProps) => (
                    <SingleSwitchSubscription {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/SwitchSubscription/:data'
                  component={(props: SubscriptionConverterProps) => (
                    <SubscriptionConverter {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/ManageCostControl'
                  component={OverlayCostControl}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/ManageRoamingSettings'
                  component={ManageRoamingSettings}
                />
                <Route
                  exact
                  path={`/:serviceId/:ratePlanName/${SimRoutes.SIM_MOBILE_ID}`}
                  component={MobileId}
                />
                <Route
                  exact
                  path={`/:serviceId/:ratePlanName/${SimRoutes.SIM_RELINK}/:linkedServiceId`}
                  component={SimRelink}
                />
                <Route
                  exact
                  path={`/:serviceId/:ratePlanName/${SimRoutes.EXTRA_SIM}`}
                  component={ExtraSim}
                />
                <Route
                  exact
                  path={`/:serviceId/:ratePlanName/${SimRoutes.SIM_QR_CODE}`}
                  component={ESimQr}
                />
                <Route
                  exact
                  path={`/:serviceId/:ratePlanName/${SimRoutes.SIM_QR_CODE}/:overlayServiceId`}
                  component={ESimQr}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/ChangeOwner'
                  component={(props: ChangeOwnerProps) => (
                    <ChangeOwner {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/ChangeOwner/:caseId/:siteIdTo/:validationKey'
                  component={(props: ChangeOwnerRCtoBCProps) => (
                    <ChangeOwnerRCtoBC {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/ChangeUser'
                  component={(props: ChangeUserProps) => (
                    <ChangeUser {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/ChangeLoginId'
                  component={(props: TvLoginProps) => <TvLogin {...props} {...aboDetailsData} />}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/ChangePassword'
                  component={(props: TvPasswordProps) => (
                    <TvPassword {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/ManageIndoorBoxNumbers'
                  component={IndoorBoxNumbers}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/ManageIndoorBoxLocation'
                  component={IndoorBoxLocation}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/AddInsuranceOption'
                  component={AddInsuranceOption}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/BuyHardware/:deviceType'
                  component={BuyHardwareFlow}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/BuyAccessories'
                  component={BuyHardwareFlow}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/BuyWinAccesory'
                  component={BuyHardwareFlow}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/BuyOttAccessories'
                  component={BuyHardwareFlow}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/ReservationStatus'
                  component={BuyHardwareReservationStatus}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/:tabName/:popup'
                  component={(props: SubscriptionProps) => (
                    <Subscription {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/:tabName'
                  component={(props: SubscriptionProps) => (
                    <Subscription {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName/ExtendDevicePlan/:hardwareType/:contractId'
                  component={(props: DevicePlanExtensionProps) => (
                    <DevicePlanExtension {...props} {...aboDetailsData} />
                  )}
                />
                <Route
                  exact
                  path='/:serviceId/:ratePlanName'
                  component={(props: SubscriptionProps) => (
                    <Subscription {...props} {...aboDetailsData} />
                  )}
                />
                <Route path='*' component={NotFound} />
              </Switch>
            </Router>
          )}
        </div>
      </SbEditable>
    </>
  );
};

export default SubscriptionDetail;
