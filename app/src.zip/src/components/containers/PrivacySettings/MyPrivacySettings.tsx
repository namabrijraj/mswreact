import React, { useEffect, useState } from 'react';
import SbEditable from 'storyblok-react';
import { GenericSBProps } from '@/components/index';
import { getSlugname } from '@/utils/Utils';
import { Settings } from '@/src-model/client/PrivacySettings';
import { StoryStaticType } from '@/utils/mysunrise-utils-types';
import storyblokInstance from '@/utils/StoryblokService';
import StaticWrapperComponent, { StaticSectionProps } from '@/components/general/StaticWrapper';
import OptOutSms, { OptOutSmsProps } from '@/src-components/UnSubscribePrivacySetting/OptOutSms/OptOutSms';

interface MyPrivacySettingsProps extends GenericSBProps, Settings, StoryStaticType, OptOutSmsProps {
  loadComponent: boolean
}

const MyPrivacySettings = (props: MyPrivacySettingsProps) => {
  const { content } = props;
  const [privacySettings, setprivacySettings] = useState<MyPrivacySettingsProps | null>(null);
  const params = getSlugname();

  useEffect(() => {
    (async () => {
      const response = await storyblokInstance.getPageContent(params);
      response.data.story.content.body.map((item: MyPrivacySettingsProps) => {
        if (item.component === content.component) {
          setprivacySettings({
            ...item,
            staticSection: item.staticSection,
            loadComponent: true
          });
        }
      });
    })();
  }, []);

  return (
    <>
      <SbEditable content={content}>
        <div data-component="PrivacySettings">
          {process.browser && privacySettings && privacySettings.loadComponent &&
            <>
              {privacySettings.staticSection &&
                privacySettings.staticSection.map((staticContent: StaticSectionProps) => (
                  <StaticWrapperComponent content={staticContent} key={staticContent._uid} />
                ))}
              <OptOutSms {...props} />
            </>}
        </div>
      </SbEditable>
    </>

  )
}

export default MyPrivacySettings
