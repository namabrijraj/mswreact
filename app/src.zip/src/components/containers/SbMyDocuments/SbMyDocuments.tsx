import { GenericSBProps } from "@/components/index";
import React, { useEffect, useState } from "react";
import SbEditable from "storyblok-react";
import storyblokInstance from "@/utils/StoryblokService";
import MyDocument, {
  MyDocumentsProps,
} from "src/containers/Overview/MyDocuments/MyDocuments";
import StaticWrapperComponent, {
  StaticSectionProps,
} from "@/components/general/StaticWrapper";
import { getSlugname } from "@/utils/Utils";
import { StoryStaticType } from "@/utils/mysunrise-utils-types";

interface MyDocuments extends GenericSBProps, MyDocumentsProps {
  myDocuments: MyDocuments;
}

const SbMyDocuments = (props: MyDocuments): JSX.Element => {
  const { content } = props;
  const [myDocumentsHelpUrl, setMyDocumentsHelpUrl] = useState<string>("");
  const [myDocumentsData, setMyDocumentsData] = useState<StoryStaticType | null>({
    staticSection: [],
    loadComponent: false
  });
  const params = getSlugname();
  useEffect(() => {
    setMyDocumentsHelpUrl(
      props.pageConfig.myDocumentsHelpUrl.cached_url
    );
    (async () => {
      const response = await storyblokInstance.getPageContent(params);
      response.data.story.content.body.map((item: StoryStaticType) => {
        setMyDocumentsData({
          ...item,
          staticSection: item.staticSection,
          loadComponent: true,
        });
      });
    })();
  }, []);
  return (
    <>
      <SbEditable content={content}>
        <div data-component="MyDocuments">
          {myDocumentsData && myDocumentsData.loadComponent && (
            <>
              <MyDocument {...{ ...props, myDocumentsHelpUrl }} />
              {myDocumentsData.staticSection &&
                myDocumentsData.staticSection.map(
                  (staticContent: StaticSectionProps) => (
                    <StaticWrapperComponent content={staticContent} />
                  )
                )}
            </>
          )}
        </div>
      </SbEditable>
    </>
  );
};

export default SbMyDocuments;
