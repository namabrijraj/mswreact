import React from "react";
import { GenericSBProps } from "@/components/index";
import SbEditable from "storyblok-react";
import AddNewSubscriptionContainer from "../AddNewSubscriptionContainer/AddNewSubscriptionContainer";
import {DataLayerConstants} from 'src/utils/DataLayer/DataLayerConstants';
import DataLayerService from 'src/utils/DataLayer/DataLayerService';

interface AddSubscriptionWrapperSchema extends GenericSBProps {
  AddNewSubscriptionContainer: AddNewSubscriptionContainerSchema[];
}

interface AddNewSubscriptionContainerSchema extends GenericSBProps {
  title: string;
  backgroundColor: string;
}

const AddSubscriptionWrapper = (
  props: AddSubscriptionWrapperSchema
): JSX.Element => {
  let { content } = props;
  DataLayerService.addEventData([{eventName: DataLayerConstants.event.ADD_NEW_PRODUCT, eventType: DataLayerConstants.event.VIEW, eventValue: DataLayerConstants.event.EVENT_DEFAULT_VALUE}], true);
  return (
    <>
      <SbEditable content={props.content}>
        <AddNewSubscriptionContainer content={content?.cards} />
      </SbEditable>
    </>
  );
};
export default AddSubscriptionWrapper;
