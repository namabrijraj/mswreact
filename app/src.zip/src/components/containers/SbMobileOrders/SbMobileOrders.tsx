import { GenericSBProps } from '@/components/index';
import React, { useEffect, useState } from 'react'
import MobileOrders, { MobileOrdersProps } from 'src/containers/Overview/MobileOrders/MobileOrders';
import SbEditable from 'storyblok-react'

interface MobilePorps extends GenericSBProps, MobileOrdersProps {}

interface MobileOrderState {
  trackShippingUrl: string,
  signNScanApiUrl: string
}

const SbMobileOrders = (props: MobilePorps) => {
  const { content } = props;
  const [mobileOrder, setMobileOrder] = useState<MobileOrderState | null>(null)
  useEffect(() => {
    setMobileOrder({
      trackShippingUrl: props.content.trackShippingUrl.cached_url,
      signNScanApiUrl: window.ReactApp.Env.urlSignNScanApi,
    })
  },[])

  return (
    <>
      <SbEditable content={content}>
        <div data-component="MobileOrders">
          <MobileOrders {...{ ...props, ...mobileOrder }} />
        </div>
      </SbEditable>
    </>
  )
}

export default SbMobileOrders
