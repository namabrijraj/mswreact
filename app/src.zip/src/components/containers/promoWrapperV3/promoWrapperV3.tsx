import React from "react";
import { GenericSBProps } from "@/components/index";
import SbEditable from "storyblok-react";
import PromoTeaserV3 from "../promoTeaserV3/promoTeaserV3";

interface PromoWrapperSchema extends GenericSBProps {
    PromoTeaserV3: promoTeaserV3Schema[];
  }
  interface promoTeaserV3Schema extends GenericSBProps {
    title: string;
    backgroundColor: string;
  }
  
const promoWrapperV3 = (
    props: PromoWrapperSchema
    ): JSX.Element => {
      let { content } = props;
      return (
        <>
          <SbEditable content={props.content}>
          <PromoTeaserV3 content={content}/>
          </SbEditable>
        </>
      );
    };



export default promoWrapperV3;
