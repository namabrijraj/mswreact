import React, { useEffect, useState } from "react";
import SbEditable from "storyblok-react";
import { GenericSBProps } from "@/components/index";
import Dashboards, {
  DashboardsProps,
} from "src/containers/Overview/Dashboards/Dashboards";
import storyblokInstance from "@/utils/StoryblokService";
import StaticWrapperComponent, {
  StaticSectionProps,
} from "@/components/general/StaticWrapper";
import { getSlugname } from "@/utils/Utils";
import { BigPromoTabProps, StoryStaticType, TeaserItemProps, BenefitTeaserInterface } from "@/utils/mysunrise-utils-types";
import { PromoTeaser } from "@/src-model/client/PromoTeaserType";
import { HashRouter as Router, Route, Switch } from 'react-router-dom';
import ProductSelectionPage, { ProductSelectionPageProps } from "@/src-containers/Overview/ProductSelectionPage/ProductSelectionPage";
import DashboardSelectSubscription, { DashboardSelectSubscriptionProps } from "@/src-containers/Overview/Dashboards/DashboardsSubscriptions/DashboardSelectSubscription";
import ConnectionTest, { ConnectionTestProps } from "@/src-containers/Subscription/ConnectionTest/ConnectionTest";
import ConnectionTestProcess, { ConnectionTestProcessProps } from "@/src-containers/Subscription/ConnectionTest/ConnectionTestProcess/ConnectionTestProcess";
import OngoingCostOverview, { OngoingCostOverviewProps } from "@/src-containers/Overview/Dashboards/DashboardsOngoingCosts/OngoingCostOverview";
import ContestLanding from "@/src-containers/Overview/Dashboards/ContestLandingPage/ContestLanding";

interface OverviewProps extends GenericSBProps, DashboardsProps { }

interface OverviewTypes {
  dashboardFallback?: TeaserItemProps[],
  bigPromoTeaser?: PromoTeaser,
  smallPromoTeaser?: PromoTeaser,
  disableSearch: boolean,
  searchPagePath: string,
  maxSearchResults: number,
  imgOrderEmptyRatePlan: string,
  pendingProductsImage: string,
  noInvoicesImage: string,
  imgPreSales: string,
  salesPage: string,
  enableSalesTeaser: boolean,
  imgScanApp: string,
  imgRoamingCockpit: string,
  billingAssistantPage: string,
  enableBenefitTeaser: boolean | undefined,
  benefitTeaserImage: string | undefined,
  crowdSourcingImage: string,
  communityImage: string,
  crowdSourcingLink: string,
  addNewSubscriptionPage:string,
  communityLink: string,
  salesBannerImage:string,
  mobileSalesBanner:string,
  recommendSunriseLink:string;
  ribbonImage: string;
  enableContestBanner: boolean;
  addressIcon?: string;
  relocationIcon?: string;
  roamingIcon?: string;
  prepaidIcon?: string;
  momentsBadge?: string;
  momentsFromDuration?: string;
  momentsImage?: string;
  momentsPromoBanner?: string;
  momentsToDuration?: string;
  momentsUrl?: string;
}

const Overview = (props: OverviewProps): JSX.Element => {
  const { content } = props;
  let bigPromoTeaser: PromoTeaser;
  let smallPromoTeaser: PromoTeaser;
  let teaserItem: TeaserItemProps;
  let dashboardFallback: TeaserItemProps[] = [];
  const [overviewState, setOverviewState] = useState<OverviewTypes | null>(null);
  let overviewProp: OverviewTypes;
  const [overviewStaticContent, setOverviewStaticContent] = useState<StoryStaticType | null>({
    staticSection: [],
    loadComponent: false
  });
  const params = getSlugname();
  useEffect(() => {
    overviewProp = {
      addNewSubscriptionPage:props.pageConfig.addNewSubscriptionPage.cached_url,
      disableSearch: props.pageConfig.disablesearch,
      searchPagePath: props.pageConfig.searchpagepath.cached_url,
      maxSearchResults: parseInt(props.pageConfig.maxsearchresults),
      imgOrderEmptyRatePlan:
        props.pageConfig.orderemptyrateplanimage.filename,
      pendingProductsImage:
        props.pageConfig.pendingproductsimage.filename,
      noInvoicesImage: props.pageConfig.noinvoicesimage.filename,
      imgPreSales: props.pageConfig.podTeaser.filename,
      salesPage: props.pageConfig.salesPage.cached_url,
      enableSalesTeaser: props.pageConfig.enablePodTeaser,
      imgScanApp: props.pageConfig.imageScanApp.filename,
      imgRoamingCockpit: props.pageConfig.roamingCockpitImage.filename,
      billingAssistantPage:
        props.pageConfig.billingAssistantPage.cached_url,
      enableBenefitTeaser: false,
      benefitTeaserImage: '',
      crowdSourcingImage: props.pageConfig.crowdSourcingImage?.filename,
      communityImage: props.pageConfig.communityImage?.filename,
      salesBannerImage:props.pageConfig.salesBannerImage?.filename,
      mobileSalesBanner:props.pageConfig.mobileSalesBanner?.filename,
      recommendSunriseLink:props.pageConfig.recommendSunriseLink?.cached_url,
      crowdSourcingLink: props.pageConfig.crowdSourcingLink?.cached_url,
      communityLink: props.pageConfig.communityLink?.cached_url,
      ribbonImage: props.property[0].ribbonImage?.filename,
      enableContestBanner: props.property[0].enableContestBanner,
      addressIcon: props.property[0].addressIcon?.filename,
      relocationIcon: props.property[0].relocationIcon?.filename,
      prepaidIcon: props.property[0].prepaidIcon?.filename,
      roamingIcon: props.property[0].roamingIcon?.filename,
      momentsBadge: props.pageConfig.momentsBadge?.filename,
      momentsFromDuration: props.pageConfig.momentsFromDuration,
      momentsImage: props.pageConfig.momentsImage?.filename,
      momentsPromoBanner: props.pageConfig.momentsPromoBanner?.filename,
      momentsToDuration: props.pageConfig.momentsToDuration,
      momentsUrl: props.pageConfig.momentsUrl?.cached_url
    };
    (async () => {
      const response = await storyblokInstance.getPageContent(params);
      response.data.story.content.body.map((sbContent: any) => {
        if (sbContent.component === content.component) {
          {
            sbContent &&
              sbContent.TeaserItem.map((teaserContent: any) => {
                teaserItem = {
                  productType: teaserContent && teaserContent.producttype,
                  title: teaserContent.title,
                  subtitle: teaserContent.subtitle,
                  text: teaserContent.text,
                  callToAction: teaserContent.callToAction,
                  linkPath: teaserContent.linkPath && teaserContent.linkPath.cached_url,
                  target: teaserContent.target,
                  image: teaserContent.imageTeaser && teaserContent.imageTeaser.filename,
                  imageAlt: teaserContent.imagealt
                }
                dashboardFallback.push(teaserItem);
              });
          }
          {
            sbContent &&
              sbContent.BigPromoTab.map((bigPromoContent: BigPromoTabProps) => {
                bigPromoTeaser = {
                  enableTeaser: bigPromoContent.enableTeaser,
                  bannerTitle: bigPromoContent.title,
                  bannerSubTitle: bigPromoContent.subtitle,
                  image: bigPromoContent.image && bigPromoContent.image.filename,
                  bannerDescription: bigPromoContent.description,
                  bannerCTAText: bigPromoContent.ctaText,
                  ctaLink:
                    bigPromoContent.ctaPath && bigPromoContent.ctaPath.cached_url,
                  target: bigPromoContent.target,
                  promoFlagText: bigPromoContent.promoFlagText,
                  promoFlagValue: bigPromoContent.promoFlagValue
                }
              });
          }

          {
            sbContent &&
              sbContent.SmallPromoTab.map((smallPromoContent: BigPromoTabProps) => {
                smallPromoTeaser = {
                  enableTeaser: smallPromoContent.enableTeaser,
                  bannerTitle: smallPromoContent.title,
                  bannerDescription: smallPromoContent.description,
                  bannerCTAText: smallPromoContent.ctaText,
                  ctaLink: smallPromoContent.ctaPath && smallPromoContent.ctaPath.cached_url,
                  target: smallPromoContent.target,
                  bannerSubTitle: smallPromoContent.subtitle,
                  image: smallPromoContent.image && smallPromoContent.image.filename,
                  promoFlagText: smallPromoContent.promoFlagText,
                  promoFlagValue: smallPromoContent.promoFlagValue
                }

              });
          }
          {
            sbContent &&
              sbContent.BenefitTeaserTab.map((benefitTeaserItem: BenefitTeaserInterface) => {
                if (benefitTeaserItem) {
                  overviewProp.enableBenefitTeaser = benefitTeaserItem.enableBenefitTeaser;
                  overviewProp.benefitTeaserImage = benefitTeaserItem.benefitTeaserImage
                    && benefitTeaserItem.benefitTeaserImage.filename;
                }
              })
          }

        }
        setOverviewState({
          ...overviewProp,
          dashboardFallback: dashboardFallback,
          bigPromoTeaser: bigPromoTeaser,
          smallPromoTeaser: smallPromoTeaser,
        });
        setOverviewStaticContent({
          staticSection: sbContent.staticSection,
          loadComponent: true,
        });
      });
    })();
  }, []);
  return (
    <>
      <SbEditable content={content}>
        <div data-component='Overview' id="overview-page">
          {overviewStaticContent && overviewStaticContent.loadComponent && (
            <>
              <Router>
                <Switch>
                  <Route exact path='/' component={(props: DashboardsProps) => <Dashboards {...props} {...overviewState} />} />
                  <Route path='/Contest' component={(props: DashboardsProps) => <ContestLanding {...props} {...overviewState} />} />
                  <Route path='/ProductSelectionPage' component={(props: ProductSelectionPageProps) => <ProductSelectionPage {...props} {...overviewState} />} />
                  <Route path='/SelectSubscription' component={(props: DashboardSelectSubscriptionProps) => <DashboardSelectSubscription {...props} {...overviewState} />} />
                  <Route exact path='/:serviceId/:ratePlanName/ConnectionTest' component={(props: ConnectionTestProps) => <ConnectionTest {...props} {...overviewState} />} />
                  <Route exact path='/:serviceId/:ratePlanName/ConnectionTest/:processDefinitionId?' component={(props: ConnectionTestProcessProps) => <ConnectionTestProcess {...props} {...overviewState} />} />
                  <Route exact path='/ongoingcosts' component={(props: OngoingCostOverviewProps) => <OngoingCostOverview {...props} {...overviewState}/>} />
                  <Route path='*' component={(props: DashboardsProps) => <Dashboards {...props} {...overviewState} />} />
                </Switch>
              </Router>
              {overviewStaticContent.staticSection && Array.isArray(overviewStaticContent.staticSection) && overviewStaticContent.staticSection.length > 0 ?
                overviewStaticContent.staticSection.map((staticContent: StaticSectionProps) => (
                  <StaticWrapperComponent content={staticContent} key={staticContent._uid} />
                )) : ''}
            </>
          )}
        </div>
      </SbEditable>
    </>
  );
};
export default Overview;
