import React from "react";
import { BlokProps } from "@/utils/StoryblokService";
import ReferenceComponent from "@/components/general/ReferenceComponent";
import MainNavigation from "../components/general/MainNavigation/MainNavigation";
import Overview from "./containers/Overview/Overview";
import StaticWrapperComponent from "./general/StaticWrapper";
import BuybackPopupComponent from "./general/BuybackPopup";
import Placeholder from "./general/Placeholder/Placeholder";
import MyOrders from "./containers/MyOrders/Myorders";
import RetentionOffer from "./containers/RetentionOffer/RetentionOffer";
import GridStandardTeaser from "./fixed/GridStandardTeaser/GridStandardTeaser";
import Inquiries from "./containers/Inquiries/Inquiries";
import MyVoucher from "./containers/MyVouchers/DiscountVouchers";
import PrepaidOverview from "./containers/PrepaidOverview/PrepaidOverview";
import Template from "./Templates/Template";
import PageTemplate from "./Templates/PageTemplate";
import MySunriseTemplate from "./Templates/MySunriseTemplate";
import MySunriseExternalLoginTemplate from "./Templates/MySunriseExternalLoginTemplate";
import Page from "./Templates/Page";
import EtfRefundForm from "./containers/EtfRefundForm/EtfRefundForm";
import EmployeeDiscount from "./containers/EmployeeDiscount/EmployeeDiscount";
import HtmlInclusion from "./fixed/HtmlInclusion/HtmlInclusion";
import MobilaboUpgrade from "./containers/MobilaboUpgrade/MobilaboUpgrade";
import CallbackComp from "./containers/Callback/Callback";
import ParsysCol from "./containers/ParsysCol/ParsysCol";
import AddSubscriptionWrapper from "./containers/AddSubscriptionWrapper/AddSubscriptionWrapper";
import AddNewSubscriptionContainer from "./containers/AddNewSubscriptionContainer/AddNewSubscriptionContainer";
import PromoTeaserV3 from "./containers/promoTeaserV3/promoTeaserV3";
import promoWrapperV3 from "./containers/promoTeaserV3/promoTeaserV3";
import MyBills from "./containers/Bills/MyBills";
import MyProfile from "./containers/Profile/MyProfile";
import MyProducts from "./containers/MyProducts/MyProducts";
import SubscriptionDetail from "./containers/SubscriptionDetail/SubscriptionDetail";
import AddNewProduct from "./containers/AddNewProduct/AddNewProduct";
import NewSubscriptionTeaser from "./fixed/NewSubscriptionTeaser/NewSubscriptionTeaser";
import ProductPromoTeaser from "./fixed/ProductPromoTeaser/ProductPromoTeaser";
import CarouselContainer from "./general/CarouselContainer/CarouselContainer";
import Cd1 from "./containers/Cd1/Cd1";
import WrapperContainer from "./general/WrapperContainer";
import MyLogin from "./containers/Login/MyLogin";
import CallToAction from "./fixed/CallToAction/CallToAction";
import TextParagraph from "./fixed/TextParagraph/TextParagraph";
import InvoiceAssistant from "./containers/InvoiceAssistant/InvoiceAssistant";
import WebsheetManageAccount from "./containers/WebsheetManageAccount/WebsheetManageAccount";
import WebsheetHeader from "./general/Websheet/WebsheetHeader";
import WebsheetTemplate from "./Templates/WebsheetTemplate";
import DeviceActivation from "./containers/DeviceActivation/DeviceActivation";
import { SbEditableContent } from "storyblok-react";
import QuickLinks from "./fixed/QuickLinks/QuickLink";
import QuickAccessContainer from "./fixed/QuickAccess/QuickAccess";
import DownloadLinkList from "./fixed/DownloadLinkList/DownloadLinkList";
import MyOnlineCompanion from "./containers/OnlineCompanion/MyOnlineCompanion";
import SbDeeplinks from "./containers/SbDeeplinks/SbDeepLinks";
import SbFmcBenefits from "./containers/SbFmcBenefits/SbFmcBenefits";
import SbMobileOrders from "./containers/SbMobileOrders/SbMobileOrders";
import MySunriseSectionTitle from "./fixed/MySunriseSectionTitle/MySunriseSectionTitle";
import SbMyDocuments from "./containers/SbMyDocuments/SbMyDocuments";
import SbMySmsSender from "./containers/SbSmsSender/SbSmsSender";
import SbUploadForm from "./containers/SbUploadForm/SbUploadForm";
import SbWebsheetSimTransfer from "./containers/SbWebsheetSimTransfer/SbWebsheetSimTransfer";
import SbWidgetBasketRecovery from "./containers/SbWidgetBasketRecovery/SbWidgetBasketRecovery";
import SbBigPromoTeaser from "./fixed/SbBigPromoTeaser/SbBigPromoTeaser";
import SbFooter from "./general/Footer/SbFooter";
import TestTeaser from "./containers/TestTeaser/TestTeaser";
import MySunriseHomeSecurityCheckout from "./containers/MySunriseHomeSecurityCheckout/MySunriseHomeSecurityCheckout";
import SbNotificationDetails from "./containers/SbNotificationDetails/SbNotificationDetails";
import MyPrivacySettings from "./containers/PrivacySettings/MyPrivacySettings";
import MySunriseDirectLoginTemplate from "./Templates/MySunriseDirectLoginTemplate";
import FalconTitle from "./containers/AddNewSubscriptionContainer/FalconTitle/FalconTitle";
import FalconButtons from "./containers/AddNewSubscriptionContainer/FalconButton/FalconButtons";
import FalconDescription from "./containers/AddNewSubscriptionContainer/FalconDescription/FalconDescription";
import ContactCard from "./containers/AddNewSubscriptionContainer/ContactCard/ContactCard";
import benefitsTypes from "./containers/MyBenefits/benefits";
import Breadcrumb from "./containers/MyBenefits/Breadcrumb";
import ContactFlyout from "./containers/AddNewSubscriptionContainer/contactFlyout/contactFlyout";
import topDealsWrapper from "./containers/topDealsWrapper/topDealsWrapper";
import salesBanner from "@/src-containers/Overview/Dashboards/salesBanner/salesBanner";
import MswMainNavigation from "./general/MainNavigation/MswMainNavigation";
import OverviewRedesign from "@/src-containers/Overview/Dashboards/NewMswContent/OverviewRedesign";

const Components: {
  [componentName: string]: (props: any) => JSX.Element;
} = {
  template: Template,
  mainNavigation: MainNavigation,
  mswMainNavigation: MswMainNavigation,
  pageTemplate: PageTemplate,
  referenceComponent: ReferenceComponent,
  mySunriseTemplate: MySunriseTemplate,
  mySunriseExternalLoginTemplate: MySunriseExternalLoginTemplate,
  page: Page,
  mySunriseHomeSecurityCheckout:MySunriseHomeSecurityCheckout,
  mysunriseSectionTitle: MySunriseSectionTitle,
  footer: SbFooter,
  quickLinks: QuickLinks,
  quickAccessContainer: QuickAccessContainer,
  Overview: Overview,
  OverviewRedesign: OverviewRedesign,
  staticWrapper: StaticWrapperComponent,
  buybackPopup: BuybackPopupComponent,
  downloadLinkList: DownloadLinkList,
  widgetBasketRecovery: SbWidgetBasketRecovery,
  importantDocuments: SbMyDocuments,
  myInquiries: Inquiries,
  discountVouchers: MyVoucher,
  smsSender: SbMySmsSender,
  prepaidOverview: PrepaidOverview,
  myOrder: MyOrders,
  gridStandardTeaser: GridStandardTeaser,
  retentionOffer: RetentionOffer,
  etfRefundForm: EtfRefundForm,
  eofOffers: EmployeeDiscount,
  htmlInclusion: HtmlInclusion,
  mobilaboUpgrade: MobilaboUpgrade,
  mobilaboUpgradeConfirmed: MobilaboUpgrade,
  callBack: CallbackComp,
  mobileOrders: SbMobileOrders,
  parsysCol: ParsysCol,
  addSubscriptionWrapper:AddSubscriptionWrapper,
  addNewSubscriptionContainer:AddNewSubscriptionContainer,
  falconTitle:FalconTitle,
  falconButton:FalconButtons,
  falconDescription:FalconDescription,
  contactCard:ContactCard,
  contactFlyout:ContactFlyout,
  PromoTeaserV3:PromoTeaserV3,
  promoWrapperV3:promoWrapperV3,
  uploadForm: SbUploadForm,
  bills: MyBills,
  invoiceAssistant: InvoiceAssistant,
  profile: MyProfile,
  myProducts: MyProducts,
  bigPromoTab: SbBigPromoTeaser,
  subscriptionDetail: SubscriptionDetail,
  deepLinks: SbDeeplinks,
  fmcBenefits: SbFmcBenefits,
  addNewProduct: AddNewProduct,
  salesBanner:salesBanner,
  subscriptionTeaser: NewSubscriptionTeaser,
  carouselContainer: CarouselContainer,
  productPromoTeaser: ProductPromoTeaser,
  cd1: Cd1,
  loginFailure: MyLogin,
  wrapperContainer: WrapperContainer,
  callToAction: CallToAction,
  textParagraph: TextParagraph,
  websheetSimTransfer: SbWebsheetSimTransfer,
  webSheetManageAccount: WebsheetManageAccount,
  webSheetHeader: WebsheetHeader,
  webSheetTemplate: WebsheetTemplate,
  webSheet: DeviceActivation,
  onlineCompanion: MyOnlineCompanion,
  testTeaser: TestTeaser,
  notificationDetails: SbNotificationDetails,
  privacySettings: MyPrivacySettings,
  mySunriseDirectLoginTemplate : MySunriseDirectLoginTemplate,
  breadcrumb: Breadcrumb,
  benefitsTypes:benefitsTypes,
  topDealsWrapper:topDealsWrapper
};

// Extend this interface for all SBeditable StoryBlok Components
export interface GenericSBProps {
  _uid: string;
  component: string;
  content: SbEditableContent;
  pageConfig?: any;
  property? : any;
}

//strictly enforces use of GenericSBProps
export interface ComponentWithContentProps<
  T extends GenericSBProps = GenericSBProps
  > {
  content: T;
  metadata?: any;
}

// Dynamic components will be rendered
const DynamicComponent = ({ content, metadata, pageConfig, property }: BlokProps): JSX.Element => {
  if (content) {
    if (content.component in Components) {
      return React.createElement(Components[content.component], {
        key: content._uid,
        content,
        metadata,
        pageConfig,
        property
      });
    }
    return (
      <div>
        <Placeholder placeHolderName={content.component}></Placeholder>
      </div>
    );
  }
  return <></>;
};
export default DynamicComponent;
