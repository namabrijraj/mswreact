import { CarouselContentProps } from '@/components/general/CarouselContainer/CarouselContainer';
import RichText from "@/components/general/Richtext";
import React from 'react';
import DateService from 'src/utils/DateService';
import I18n from 'src/utils/helper/I18n';
import SbEditable from 'storyblok-react';

interface ProductPromoTeaserProps extends CarouselContentProps {}

const ProductPromoTeaser = (props: ProductPromoTeaserProps): JSX.Element => {

  return (
    <>
      <SbEditable content={props.content}>
        {props.content.title && <li className={`l-col s20-carousel__slides-item s20-carousel__slides-item--offer-teaser${props.content.image.filename ? '-media' : ''}`}>
          <div className={`aem-s20-offer-teaser ${props.content.image.filename ? 'aem-s20-offer-teaser--media' : ''}`}>
            {props.content.linkPath.cached_url &&
              <a className="aem-s20-offer-teaser__anchor" target={props.content.target} href={props.content.linkPath.cached_url}></a>}
            {props.content.endTime &&
              <div className="aem-s20-offer-teaser__countdown">
                <div className="js-countdown s20-countdown s20-countdown--border-radius s20-countdown--small" data-countdown={DateService.formatDateTime(props.content.endTime)}
                  data-label={`<span className=&quot;s20-countdown__label&quot;>
               ${props.content.timeLeftLabel}</span>`} data-expired={`<span className=&quot;s20-countdown__expired&quot;>${props.content.expiredLabel}</span>`} data-plural={I18n.translate('countdown.days')} data-singular={I18n.translate('countdown.day')} data-variant="default" data-version="s20">
                  <div className="s20-countdown__icon"></div>
                  <div className="s20-countdown__content js-countdown--display"></div>
                </div>
              </div>}
            {props.content.image.filename && <div className="aem-s20-offer-teaser__media">
              <img className="aem-s20-offer-teaser__image" src={props.content.image.filename} />
            </div>}
            {props.content.title && <div className="aem-s20-offer-teaser__content">
              {props.content.title && <div className="aem-s20-offer-teaser__title">
                <h3 className="s20-teaser-title s20-teaser-title--large s20-teaser-title--promo">{props.content.title}</h3>
              </div>}
              {props.content.description && <div className="aem-s20-offer-teaser__features">
                {<RichText content={props.content.description} />}
                {/* {props.content.description} */}
              </div>}
              {props.content.linkText && <div className="aem-s20-offer-teaser__button">
                <a href={props.content.linkPath.cached_url} target={props.content.target} >
                  <button className="s20-button s20-button--full" type="button">
                    {props.content.linkText}
                  </button>
                </a>
              </div>}
            </div>}
          </div>
        </li>}
      </SbEditable>
    </>
  )
}

export default ProductPromoTeaser;
