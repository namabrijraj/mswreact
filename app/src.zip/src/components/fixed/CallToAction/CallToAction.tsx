import { MultiLink } from "@/utils/storyblok-types";
import React from "react";
import { GenericSBProps } from "@/components/index";
import SbEditable from "storyblok-react";

interface CallToActionProps extends GenericSBProps {
	text: string;
	link: MultiLink;
	target: string;
	style: string;
}

const CallToAction = (props: CallToActionProps): JSX.Element => {
	return (
		<>
		<SbEditable content={props.content}>
			{props.content &&
				<div className="l-center-m">
					<div className="centered-text">
						<a href={props.content.link.cached_url} target={props.content.target}>
							<button className={`s20-button ${props.content.style}`} >
								{props.content.text}
							</button>
						</a>
					</div>
				</div>
			}
			<div className="s20-spacer s20-spacer--x12"></div>
			</SbEditable>
		</>
	)
}

export default CallToAction;