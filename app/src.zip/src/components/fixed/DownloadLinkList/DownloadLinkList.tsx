import React from "react";
import { BlokProps } from "@/utils/StoryblokService";
import { MultiLink } from "@/utils/storyblok-types";
import SbEditable from "storyblok-react";

interface DownloadLinkListProp extends BlokProps {
  _uid: string;
  path: MultiLink;
  text: string;
  component: string;
  openTarget: string;
}
interface DownloadLinkListProps extends BlokProps {
  content: {
    _uid: string;
    component: string;
    downloadLinkItem: DownloadLinkListProp[];
  };
}

const DownloadLinkList = (props: DownloadLinkListProps): JSX.Element => {
  return (
    <>
      <SbEditable content={props.content}>
        <div className="l-center-xxl">
          <div className="xxl-grid">
            <div className="content-box">
              <div className="l-col l-1of1">
                <ul className="form-item">
                  {props.content.downloadLinkItem &&
                    props.content.downloadLinkItem.map(
                      (item: DownloadLinkListProp) => (
                        <li className="margin-bottom-8 form__label__text form__text_field-label" key={item._uid}>
                          <a
                            href={item.path.cached_url}
                            className="s20-link"
                            target={item.openTarget}
                          >
                            <i className="ico ico-list-document"></i>
                            <i className="ico ico-list-extern-link"></i>
                            <span>{item.text}</span>
                          </a>
                        </li>
                      )
                    )}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </SbEditable>
    </>
  );
};

export default DownloadLinkList;
