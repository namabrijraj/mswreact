import { BlokProps } from "@/utils/StoryblokService";
import QuickAccessItem, {
  QuickAccessItemProps,
} from "@/components/fixed/QuickAccess/QuickAccessItem";
import SbEditable from "storyblok-react";

interface QuickAccessContainerProps extends BlokProps {
  content: {
    _uid: string;
    component: string;
    quickAccessItems: QuickAccessItemProps[];
    isSingleContainer: boolean;
  };
}

const QuickAccessContainer = (props: QuickAccessContainerProps) => {
  return (
    <SbEditable content={props.content}>
      <div className="l-center-l">
        <div className="l-1of1">
          <nav
            className={`quick_links_nav quick_links_nav-no_margin ${props.content.isSingleContainer ? "content_box" : ""
              }`}
          >
            <ul className="quick_links_nav--list">
              {props.content.quickAccessItems.map(
                (items: QuickAccessItemProps) => (
                  <QuickAccessItem key={items._uid} content={items} />
                )
              )}
            </ul>
          </nav>
        </div>
      </div>
    </SbEditable>
  );
};
export default QuickAccessContainer;
