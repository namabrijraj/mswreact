import SbEditable from "storyblok-react";
import { ComponentWithContentProps } from "@/components/index";
import { Asset, MultiLink } from "@/utils/storyblok-types";
import { BlokProps } from "@/utils/StoryblokService";

interface LinkItemProps extends BlokProps {
  _uid: string;
  component: string;
  linkText: string;
  linkPath: MultiLink;
  linkTarget: string;
  hideArrow: boolean;
}

export interface QuickAccessItemProps extends BlokProps {
  _uid: string;
  component: string;
  title: string;
  iconPath: Asset;
  linkItems: LinkItemProps[];
  isSingleContainer: boolean;
}

const QuickAccessItem = ({
  content,
}: ComponentWithContentProps<QuickAccessItemProps>) => {
  return (
    <SbEditable content={content}>
      <li className="js-collapsible" role="presentation">
        <span className="quick_links_nav--link quick_links_nav--link-inactive js-collapsible--toggle">
          <span
            className="quick_links_nav--link--icon"
            style={{ backgroundImage: `url(${content.iconPath.filename}` }}
          >
            &nbsp;
          </span>
          <span
            className={`quick_links_nav--link--text ${content.isSingleContainer || !content.iconPath.filename
                ? "quick_links_nav--link--text-left"
                : ""
              }`}
          >
            {content.title}
          </span>
        </span>
        <ul className="link_list js-collapsible--container">
          {content.linkItems.length > 0 &&
            content.linkItems.map((links: LinkItemProps) => (
              <li key={links._uid}>
                <a
                  className="link"
                  href={links.linkPath.url ? links.linkPath.url : ""}
                  target={links.linkTarget}
                >
                  {links.linkText}
                  {links.hideArrow && <span className="link_list--cta" ></span>}
                </a>
              </li>
            ))}
        </ul>
      </li>
    </SbEditable>
  );
};
export default QuickAccessItem;
