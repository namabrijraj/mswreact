import React from 'react';
import SbEditable from 'storyblok-react';
import { BlokProps } from '@/utils/StoryblokService';
import { Asset, MultiLink } from '@/utils/storyblok-types';
import DataLayerService from 'src/utils/DataLayer/DataLayerService';
import { DataLayerConstants } from 'src/utils/DataLayer/DataLayerConstants';

interface NewSubscriptionTeaserProps extends BlokProps {
  content: {
    _uid: string;
    icon: Asset;
    text: string;
    color: string;
    title: string;
    target: string;
    linkPath: MultiLink;
    component: string;
    callToAction: string;
  }
}

const NewSubscriptionTeaser = (props: NewSubscriptionTeaserProps): JSX.Element => {
  const  onHandleCard= (props:any): void => {
    window.location.href=props.content.linkPath.cached_url;
    DataLayerService.addEventData(
      [
        {
          eventName: DataLayerConstants.event.OLD_PRODUCT_PAGE,
          eventType: DataLayerConstants.event.CLICK,
          eventValue: `${props.content.title}`,
        },
      ],
      true)
  
    }
  let bgClass;
  switch (props.content.color) {
    case 'blue':
      bgClass = 'bg-promo'
      break;
    case 'darkred':
      bgClass = 'bg-red-dark'
      break;
    case 'red':
      bgClass = 'bg-red'
      break;
    case 'orange':
      bgClass = 'bg-warn'
      break;
    case 'yellow':
      bgClass = 'bg-warn'
      break;
    case 'darkgrey':
      bgClass = 'bg-grey-500'
      break;
    default:
      bgClass = 'bg-red'
  }
  return (
    <>

      <SbEditable content={props.content}>
        <div className={`content-box content_box--padding-x20 ${bgClass}`}>
          <a onClick={() => onHandleCard(props)} target={props.content.target} data-newsubscriptionteaser="newsubscriptionteaser">
            <div className="content-box__add-product-container--small">
              {props.content.icon &&
                <div className="subscription__img_placeholder--right">
                  <img src={props.content.icon.filename} />
                </div>}
              <div className="p-flex-no-wrap">
                <div className="font-s-40px c-white margin-top-65 t-strong mobile-fs-28">
                  {props.content.title}
                </div>
              </div>
              {props.content.text &&
                <div className="text-s-14px t-w-500 c-white">
                  {props.content.text}
                </div>}
              <div className="content-box__button-container">
                {props.content.callToAction &&
                  <button className="button cta-button  extra_wide inline">
                    {props.content.callToAction}
                  </button>}
              </div>
            </div>
          </a>
        </div>
      </SbEditable>
    </>
  )
}

export default NewSubscriptionTeaser
