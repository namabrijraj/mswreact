import { Asset, MultiLink } from "@/utils/storyblok-types"
import SbEditable from "storyblok-react"
import { GenericSBProps } from "@/components/index"

interface BigPromoTeaserInterface extends GenericSBProps {
  enableTeaser: boolean;
  title: string;
  subtitle: string;
  image: Asset;
  descripition: string;
  ctaText: string;
  ctaPath: MultiLink;
  target: string;
  promoFlagText: string;
  promoFlagValue: string
}

const SbBigPromoTeaser = (props: BigPromoTeaserInterface): JSX.Element => {
  return (
    <>
      <SbEditable content={props.content}>
        <div className="l-center-l">
          {props.content.enableTeaser &&
            <div>
              <div className="promo-bar promo-bar--white promo-bar--targeted">
                <div className="promo-bar__media">
                  <div className="promo-bar__media-content">
                    {props.content.image && <img className="promo-bar__image" src={props.content.image.filename} />}
                    {props.content.promoFlagText &&
                      <div className="promo-bar__image-flag">
                        <div className="s20-promo-flag s20-promo-flag--circle s20-promo-flag--circle-s">
                          {props.content.promoFlagText}
                          <strong>{props.content.promoFlagValue}</strong>
                        </div>
                      </div>}
                  </div>
                </div>
                <div className="promo-bar__content">
                  <div className="promo-bar__content-inner">
                    {props.content.subtitle &&
                      <div className="promo-bar__text promo-bar__text--important">
                        {props.content.subtitle}
                      </div>}
                    {props.content.title && <div className="promo-bar__title">
                      {props.content.title}
                    </div>}
                    {props.content.ctaText &&
                <div className="promo-bar__text promo-bar__text--info">
                  {props.content.ctaText}
                </div>
              }
                    <a href={props.content.ctaPath.cached_url} target={props.content.target}
                      className="s20-button promo-bar__button" type="button">{props.content.ctaText}</a>
                  </div>
                </div>
              </div>
            </div>
          }
        </div>
    </SbEditable>
    </>
  )
}
export default SbBigPromoTeaser