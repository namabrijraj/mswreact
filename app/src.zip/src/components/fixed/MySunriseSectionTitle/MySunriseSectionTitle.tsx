import React from 'react'
import SbEditable from 'storyblok-react'
import { BlokProps } from '@/utils/StoryblokService'

interface SectionTitleProps extends BlokProps {
  content: {
    _uid: string;
    component: string;
    title: string;
    subtitle: string;
    color: string;
    isBackgroundWhite: boolean;
    isLeftAligned: boolean;
  };
}

const MySunriseSectionTitle = (props: SectionTitleProps): JSX.Element => {

  return (
    <>
      {props.content &&
        <SbEditable content={props.content}>
          <div className={`${(props.content.isBackgroundWhite || props.content.isLeftAligned) ? 'l-center-l' : ''}`}>
            <div className={`${(props.content.isBackgroundWhite || props.content.isLeftAligned) ? "l-grid" : ''}`}>
              <div className={`${(props.content.isBackgroundWhite || props.content.isLeftAligned) ? "l-col l-1of1" : ''}`}>

                <div className={`${props.content.isLeftAligned ? 's20-spacer s20-spacer--x40 is-hidden-desktop' : ''}`}></div>
                <div className={`${props.content.isLeftAligned ? 's20-spacer s20-spacer--x60 is-hidden-mobile' : ''}`}></div>

                <div className={`${props.content.isBackgroundWhite ? 'content-box content_box--padding-x48-y32' :
                  (props.content.isLeftAligned ? 's20-section-title width-100perc s20-section-title--align-left'
                    : 'l-center-l l-center-l--extra-wide')}`}>
                  {props.content.title &&
                    <div className={`${props.content.color === 'red' ? 's20-teaser-title' : 'c-grey-500'}
                  ${props.content.isBackgroundWhite ? 'pg-title font-s-32px centered-text margin-bottom-8' :
                        (props.content.isLeftAligned ? 's20-section-title__heading' : 'pg-title font-s-24px centered-text')}`}>
                      {props.content.title}
                    </div>
                  }
                  {props.content.subtitle &&
                    <div className={`${props.content.isBackgroundWhite ? 'text-s-16px centered-text c-grey-500' :
                      (props.content.isLeftAligned ? 's20-section-title__description' : 'text-s-18px centered-text c-grey-400')}`}>
                      {props.content.subtitle}
                    </div>
                  }
                </div>
              </div>
            </div>
          </div>
          {typeof window !== 'undefined' && !window.location.href.includes('login') ? (
            <div className='s20-spacer s20-spacer--x12'></div>
          ) : null}
        </SbEditable>
      }
    </>
  )
}
export default MySunriseSectionTitle
