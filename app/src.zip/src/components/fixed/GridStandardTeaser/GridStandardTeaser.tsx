import React from 'react';
import { BlokProps } from '@/utils/StoryblokService';
import SbEditable from 'storyblok-react';
import { Asset, MultiLink } from '@/utils/storyblok-types';
import { DataLayerConstants } from 'src/utils/DataLayer/DataLayerConstants';
import DataLayerService from 'src/utils/DataLayer/DataLayerService';

export interface GridStandardTeaserProp extends BlokProps {
	content: {
		_uid: string;
		icon: Asset;
		text: string;
		title: string;
		target: string;
		linkPath: MultiLink;
		component: string;
		tutorialId: string;
		callToAction: string;
	}
}

const GridStandardTeaser = (props: GridStandardTeaserProp): JSX.Element => {

	return (
		<>
			<SbEditable content={props.content}>
				<div id={props.content.tutorialId} className="l-col-flexbox l-col-flexbox-even">
					<a href={props.content.linkPath && props.content.linkPath.cached_url} target={props.content.target} data-gridstandardteaser="gridstandardteaser">
						<div className="content-box content-box--image-icon">
							<div className="l-flexbox-row l-flexbox--no-gutters">
								<div className="l-col-flexbox-2_3 l-flexbox--no-gutters">
									<div className="text-s-28px t-bold c-red">
										{props.content.title}
									</div>
									<div className="vertical_spacer x8"></div>
									<div className="text-s-14px c-grey-500">
										{props.content.text}
									</div>
									<div className="vertical_spacer x24"></div>
									<button className="button cta-button  extra_wide" onClick={() => props.content.title.includes('Internet') ? DataLayerService.addEventData([{ eventName: DataLayerConstants.event.ORDER_VIEW, eventType: DataLayerConstants.event.CLICK, eventValue: props.content.title}], true) : ''}>
										{props.content.callToAction}
									</button>
								</div>
								<div className="l-col-flexbox l-col-flexbox-1_3 l-flexbox--no-gutters">
									<img className="img-object-fit-none mobile-position-absolute" src={props.content.icon.filename} />
								</div>
							</div>
						</div>
					</a>
				</div>
			</SbEditable>
		</>
	)
}

export default GridStandardTeaser
