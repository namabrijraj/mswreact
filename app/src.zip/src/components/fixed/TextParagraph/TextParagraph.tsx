import RichText from "@/components/general/Richtext";
import React from "react";
import { Richtext } from "storyblok-js-client";
import { GenericSBProps } from "@/components/index";
import SbEditable from "storyblok-react";

interface TextParagraphProps extends GenericSBProps {
	textParagraph: Richtext
}

const TextParagraph = (props: TextParagraphProps) => {
	let { content } = props;
	return (
		<>
			<SbEditable content={content} >
				<div className="centered-text text-s-14px no-bottom-margin richtext-links-red" >
					{content && <RichText content={content.textParagraph} />}
				</div>
				<div className="s20-spacer s20-spacer--x16"></div>
			</SbEditable>
		</>
	)
}

export default TextParagraph;