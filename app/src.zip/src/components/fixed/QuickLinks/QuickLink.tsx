import { GenericSBProps } from "@/components/index";
import React, { useEffect, useState } from "react";
import SbEditable from "storyblok-react";
import QuickLinkItem, { QuickLinkComponent } from "./QuickLinkItem";

interface QuickLinksProps extends GenericSBProps {
  links: QuickLinkComponent[];
}

const QuickLinks = (props: QuickLinksProps): JSX.Element => {
  const [hideNavigation, setHideNavigation] = useState<any>([]);
  useEffect(() => {
    window.ReactApp.Env.hideNavigation && setHideNavigation(JSON.parse(window.ReactApp.Env.hideNavigation))
  }, []);
  return (
    <>
      <SbEditable content={props.content}>
        <nav className="version-s20 quick_links_nav quick_links_nav-no_margin">
          <div className="l-center-l">
            <div className="l-grid">
              <div className="l-col l-1of1">
                <ul className="quick_links_nav--list">
                  {hideNavigation.length > 0 ?
                    (props.content.links &&
                      props.content.links.map((quickLink: QuickLinkComponent) => (
                        hideNavigation.map((item: any) => (
                          (item.hideNav === 'true' || item.hideNav === true || item.hideNav === '') ?
                            ((item.hideNavUrl !== quickLink.url.cached_url) &&
                              <QuickLinkItem key={quickLink._uid} content={quickLink} />)
                            :
                            <QuickLinkItem key={quickLink._uid} content={quickLink} />)
                        ))
                      ))
                    :
                    (props.content.links &&
                      props.content.links.map((quickLink: QuickLinkComponent) => (
                        <QuickLinkItem key={quickLink._uid} content={quickLink} />
                      )))
                  }
                </ul>
              </div>
            </div>
          </div>
        </nav>
        <div className="s20-spacer s20-spacer--x40"></div>
      </SbEditable>
    </>
  );
};

export default QuickLinks;
