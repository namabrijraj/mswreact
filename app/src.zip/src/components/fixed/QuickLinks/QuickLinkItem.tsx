import { ComponentWithContentProps, GenericSBProps } from "@/components/index";
import React from "react";
import SbEditable from "storyblok-react";
import { MultiLink } from "@/utils/storyblok-types";

export interface QuickLinkComponent extends GenericSBProps {
  title: string;
  url: MultiLink;
}

const QuickLinkItem: React.FunctionComponent<
  ComponentWithContentProps<QuickLinkComponent>
> = ({
  content,
}: ComponentWithContentProps<QuickLinkComponent>): JSX.Element => {
    return (
      <SbEditable content={content}>
        <li role="presentation">
          <a
            href={content.url.cached_url ? content.url.cached_url : ""}
            className="quick_links_nav--link"
            style={{ textDecoration: "none" }}
          >
            {/* <span className="quick_links_nav--link--icon"></span> */}
            <span className="quick_links_nav--link--text">{content.title}</span>
          </a>
        </li>
      </SbEditable>
    );
  };

export default QuickLinkItem;
