import { GenericSBProps } from "@/components/index"
import React from "react"
import SbEditable from "storyblok-react"

interface HtmlInclusionProps extends GenericSBProps {
  title: string,
  htmlContent: HTMLElement
}

const HtmlInclusion = (props: HtmlInclusionProps) => {
  return (
    <>
      <SbEditable content={props.content}>
        <div>
          <div className='html-inclusion' 
            dangerouslySetInnerHTML={{ __html: props.content.htmlContent.html }} />
        </div>
      </SbEditable>
    </>
  )
}
export default HtmlInclusion